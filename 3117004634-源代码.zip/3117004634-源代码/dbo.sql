/*
Navicat SQL Server Data Transfer

Source Server         : KS_4634
Source Server Version : 120000
Source Host           : :1433
Source Database       : KS_4634
Source Schema         : dbo

Target Server Type    : SQL Server
Target Server Version : 120000
File Encoding         : 65001

Date: 2020-01-06 14:22:05
*/


-- ----------------------------
-- Table structure for admin
-- ----------------------------
DROP TABLE [dbo].[admin]
GO
CREATE TABLE [dbo].[admin] (
[ad_id] varchar(6) NOT NULL ,
[ad_name] varchar(10) NULL ,
[ad_sex] varchar(1) NULL ,
[ad_password] varchar(8) NULL 
)


GO

-- ----------------------------
-- Records of admin
-- ----------------------------
INSERT INTO [dbo].[admin] ([ad_id], [ad_name], [ad_sex], [ad_password]) VALUES (N'11', N'1111', N'0', N'1111')
GO
GO
INSERT INTO [dbo].[admin] ([ad_id], [ad_name], [ad_sex], [ad_password]) VALUES (N'4634', N'闫浩宇', N'0', N'4634')
GO
GO
INSERT INTO [dbo].[admin] ([ad_id], [ad_name], [ad_sex], [ad_password]) VALUES (N'闫浩宇', N'111122', N'0', N'123')
GO
GO

-- ----------------------------
-- Table structure for book
-- ----------------------------
DROP TABLE [dbo].[book]
GO
CREATE TABLE [dbo].[book] (
[b_borrow] varchar(1) NULL ,
[b_location] varchar(30) NULL ,
[b_author] varchar(20) NULL ,
[b_name] varchar(30) NULL ,
[b_id] varchar(6) NOT NULL ,
[b_tid] varchar(6) NULL ,
[b_desc] varchar(100) NULL ,
[b_typeName] varchar(10) NULL 
)


GO
IF ((SELECT COUNT(*) from fn_listextendedproperty('MS_Description', 
'SCHEMA', N'dbo', 
'TABLE', N'book', 
'COLUMN', N'b_borrow')) > 0) 
EXEC sp_updateextendedproperty @name = N'MS_Description', @value = N'0被借 1还在'
, @level0type = 'SCHEMA', @level0name = N'dbo'
, @level1type = 'TABLE', @level1name = N'book'
, @level2type = 'COLUMN', @level2name = N'b_borrow'
ELSE
EXEC sp_addextendedproperty @name = N'MS_Description', @value = N'0被借 1还在'
, @level0type = 'SCHEMA', @level0name = N'dbo'
, @level1type = 'TABLE', @level1name = N'book'
, @level2type = 'COLUMN', @level2name = N'b_borrow'
GO

-- ----------------------------
-- Records of book
-- ----------------------------
INSERT INTO [dbo].[book] ([b_borrow], [b_location], [b_author], [b_name], [b_id], [b_tid], [b_desc], [b_typeName]) VALUES (N'0', N'四层19排22架', N'牛牧风', N'古今商贾智慧谋略', N'100017', N'200001', N'好好', N'哲学类')
GO
GO
INSERT INTO [dbo].[book] ([b_borrow], [b_location], [b_author], [b_name], [b_id], [b_tid], [b_desc], [b_typeName]) VALUES (N'0', N'四层19排23架', N'牛牧风', N'古今商贾智慧谋略', N'100018', N'200001', N'好好', N'哲学类')
GO
GO
INSERT INTO [dbo].[book] ([b_borrow], [b_location], [b_author], [b_name], [b_id], [b_tid], [b_desc], [b_typeName]) VALUES (N'0', N'四层19排25架', N'萨特', N'萨特论快乐的自我', N'100020', N'200001', N'好好', N'哲学类')
GO
GO
INSERT INTO [dbo].[book] ([b_borrow], [b_location], [b_author], [b_name], [b_id], [b_tid], [b_desc], [b_typeName]) VALUES (N'0', N'四层19排26架', N'萨特', N'萨特论快乐的自我', N'100021', N'200001', N'好好', N'哲学类')
GO
GO
INSERT INTO [dbo].[book] ([b_borrow], [b_location], [b_author], [b_name], [b_id], [b_tid], [b_desc], [b_typeName]) VALUES (N'0', N'四层19排27架', N'萨特', N'萨特论快乐的自我', N'100022', N'200001', N'好好', N'哲学类')
GO
GO
INSERT INTO [dbo].[book] ([b_borrow], [b_location], [b_author], [b_name], [b_id], [b_tid], [b_desc], [b_typeName]) VALUES (N'1', N'四层19排28架', N'萨特', N'萨特论快乐的自我', N'100023', N'200001', N'23412412', N'哲学类')
GO
GO
INSERT INTO [dbo].[book] ([b_borrow], [b_location], [b_author], [b_name], [b_id], [b_tid], [b_desc], [b_typeName]) VALUES (N'0', N'四层19排30架', N'安东尼·罗宾', N'安东尼·罗宾五项修炼成功学', N'100025', N'200001', N'好好', N'哲学类')
GO
GO
INSERT INTO [dbo].[book] ([b_borrow], [b_location], [b_author], [b_name], [b_id], [b_tid], [b_desc], [b_typeName]) VALUES (N'0', N'四层19排32架', N'安东尼·罗宾', N'安东尼·罗宾五项修炼成功学', N'100027', N'200001', N'好好', N'哲学类')
GO
GO
INSERT INTO [dbo].[book] ([b_borrow], [b_location], [b_author], [b_name], [b_id], [b_tid], [b_desc], [b_typeName]) VALUES (N'0', N'四层19排33架', N'安东尼·罗宾', N'安东尼·罗宾五项修炼成功学', N'100028', N'200001', N'好好', N'哲学类')
GO
GO
INSERT INTO [dbo].[book] ([b_borrow], [b_location], [b_author], [b_name], [b_id], [b_tid], [b_desc], [b_typeName]) VALUES (N'0', N'四层19排36架', N'蒙田', N'蒙田谈才能与命运', N'100031', N'200001', N'好好', N'哲学类')
GO
GO
INSERT INTO [dbo].[book] ([b_borrow], [b_location], [b_author], [b_name], [b_id], [b_tid], [b_desc], [b_typeName]) VALUES (N'0', N'四层19排38架', N'卢梭', N'卢梭谈生活品质', N'100033', N'200001', N'好好', N'哲学类')
GO
GO
INSERT INTO [dbo].[book] ([b_borrow], [b_location], [b_author], [b_name], [b_id], [b_tid], [b_desc], [b_typeName]) VALUES (N'0', N'四层19排39架', N'卢梭', N'卢梭谈生活品质', N'100034', N'200001', N'好好', N'哲学类')
GO
GO
INSERT INTO [dbo].[book] ([b_borrow], [b_location], [b_author], [b_name], [b_id], [b_tid], [b_desc], [b_typeName]) VALUES (N'0', N'四层19排40架', N'卢梭', N'卢梭谈生活品质', N'100035', N'200001', N'好好', N'哲学类')
GO
GO
INSERT INTO [dbo].[book] ([b_borrow], [b_location], [b_author], [b_name], [b_id], [b_tid], [b_desc], [b_typeName]) VALUES (N'0', N'四层19排41架', N'卢梭', N'卢梭谈生活品质', N'100036', N'200001', N'好好', N'哲学类')
GO
GO
INSERT INTO [dbo].[book] ([b_borrow], [b_location], [b_author], [b_name], [b_id], [b_tid], [b_desc], [b_typeName]) VALUES (N'0', N'四层19排42架', N'卢梭', N'卢梭谈生活品质', N'100037', N'200001', N'好好', N'哲学类')
GO
GO
INSERT INTO [dbo].[book] ([b_borrow], [b_location], [b_author], [b_name], [b_id], [b_tid], [b_desc], [b_typeName]) VALUES (N'0', N'四层19排43架', N'拿破仑·希尔', N'拿破仑·希尔财富成功学', N'100038', N'200001', N'好好', N'哲学类')
GO
GO
INSERT INTO [dbo].[book] ([b_borrow], [b_location], [b_author], [b_name], [b_id], [b_tid], [b_desc], [b_typeName]) VALUES (N'0', N'四层19排44架', N'拿破仑·希尔', N'拿破仑·希尔财富成功学', N'100039', N'200001', N'好好', N'哲学类')
GO
GO
INSERT INTO [dbo].[book] ([b_borrow], [b_location], [b_author], [b_name], [b_id], [b_tid], [b_desc], [b_typeName]) VALUES (N'0', N'四层19排45架', N'拿破仑·希尔', N'拿破仑·希尔财富成功学', N'100040', N'200001', N'好好', N'哲学类')
GO
GO
INSERT INTO [dbo].[book] ([b_borrow], [b_location], [b_author], [b_name], [b_id], [b_tid], [b_desc], [b_typeName]) VALUES (N'0', N'四层19排46架', N'拿破仑·希尔', N'拿破仑·希尔财富成功学', N'100041', N'200001', N'好好', N'哲学类')
GO
GO
INSERT INTO [dbo].[book] ([b_borrow], [b_location], [b_author], [b_name], [b_id], [b_tid], [b_desc], [b_typeName]) VALUES (N'0', N'四层19排47架', N'拿破仑·希尔', N'拿破仑·希尔财富成功学', N'100042', N'200001', N'好好', N'哲学类')
GO
GO
INSERT INTO [dbo].[book] ([b_borrow], [b_location], [b_author], [b_name], [b_id], [b_tid], [b_desc], [b_typeName]) VALUES (N'0', N'四层19排48架', N'托尔斯泰', N'人生大师哲理随笔', N'100043', N'200001', N'好好', N'哲学类')
GO
GO
INSERT INTO [dbo].[book] ([b_borrow], [b_location], [b_author], [b_name], [b_id], [b_tid], [b_desc], [b_typeName]) VALUES (N'0', N'四层19排49架', N'托尔斯泰', N'人生大师哲理随笔', N'100044', N'200001', N'好好', N'哲学类')
GO
GO
INSERT INTO [dbo].[book] ([b_borrow], [b_location], [b_author], [b_name], [b_id], [b_tid], [b_desc], [b_typeName]) VALUES (N'0', N'四层19排50架', N'罗素', N'罗素论两性价值互动', N'100045', N'200001', N'好好', N'哲学类')
GO
GO
INSERT INTO [dbo].[book] ([b_borrow], [b_location], [b_author], [b_name], [b_id], [b_tid], [b_desc], [b_typeName]) VALUES (N'0', N'四层19排51架', N'罗素', N'罗素论两性价值互动', N'100046', N'200001', N'好好', N'哲学类')
GO
GO
INSERT INTO [dbo].[book] ([b_borrow], [b_location], [b_author], [b_name], [b_id], [b_tid], [b_desc], [b_typeName]) VALUES (N'0', N'四层19排52架', N'戴明', N'戴明人性管理学', N'100047', N'200001', N'好好', N'哲学类')
GO
GO
INSERT INTO [dbo].[book] ([b_borrow], [b_location], [b_author], [b_name], [b_id], [b_tid], [b_desc], [b_typeName]) VALUES (N'0', N'四层19排53架', N'戴明', N'戴明人性管理学', N'100048', N'200001', N'好好', N'哲学类')
GO
GO
INSERT INTO [dbo].[book] ([b_borrow], [b_location], [b_author], [b_name], [b_id], [b_tid], [b_desc], [b_typeName]) VALUES (N'0', N'四层19排54架', N'叔本华', N'叔本华超级成功学', N'100049', N'200001', N'好好', N'哲学类')
GO
GO
INSERT INTO [dbo].[book] ([b_borrow], [b_location], [b_author], [b_name], [b_id], [b_tid], [b_desc], [b_typeName]) VALUES (N'0', N'四层19排55架', N'叔本华', N'叔本华超级成功学', N'100050', N'200001', N'好好', N'哲学类')
GO
GO
INSERT INTO [dbo].[book] ([b_borrow], [b_location], [b_author], [b_name], [b_id], [b_tid], [b_desc], [b_typeName]) VALUES (N'0', N'四层19排56架', N'马斯洛', N'马斯洛成功人格学', N'100051', N'200001', N'好好', N'哲学类')
GO
GO
INSERT INTO [dbo].[book] ([b_borrow], [b_location], [b_author], [b_name], [b_id], [b_tid], [b_desc], [b_typeName]) VALUES (N'0', N'四层19排57架', N'马斯洛', N'马斯洛成功人格学', N'100052', N'200001', N'好好', N'哲学类')
GO
GO
INSERT INTO [dbo].[book] ([b_borrow], [b_location], [b_author], [b_name], [b_id], [b_tid], [b_desc], [b_typeName]) VALUES (N'0', N'四层19排58架', N'弗洛伊德', N'弗洛伊德本能成功学', N'100053', N'200001', N'好好', N'哲学类')
GO
GO
INSERT INTO [dbo].[book] ([b_borrow], [b_location], [b_author], [b_name], [b_id], [b_tid], [b_desc], [b_typeName]) VALUES (N'0', N'四层19排59架', N'弗洛伊德', N'弗洛伊德本能成功学', N'100054', N'200001', N'好好', N'哲学类')
GO
GO
INSERT INTO [dbo].[book] ([b_borrow], [b_location], [b_author], [b_name], [b_id], [b_tid], [b_desc], [b_typeName]) VALUES (N'0', N'四层19排60架', N'罗素', N'罗素论人类理想境界', N'100055', N'200001', N'好好', N'哲学类')
GO
GO
INSERT INTO [dbo].[book] ([b_borrow], [b_location], [b_author], [b_name], [b_id], [b_tid], [b_desc], [b_typeName]) VALUES (N'0', N'四层19排61架', N'罗素', N'罗素论人类理想境界', N'100056', N'200001', N'好好', N'哲学类')
GO
GO
INSERT INTO [dbo].[book] ([b_borrow], [b_location], [b_author], [b_name], [b_id], [b_tid], [b_desc], [b_typeName]) VALUES (N'0', N'四层19排62架', N'弗洛姆', N'弗洛姆行为研究讲稿', N'100057', N'200001', N'好好', N'哲学类')
GO
GO
INSERT INTO [dbo].[book] ([b_borrow], [b_location], [b_author], [b_name], [b_id], [b_tid], [b_desc], [b_typeName]) VALUES (N'0', N'四层19排63架', N'弗洛姆', N'弗洛姆行为研究讲稿', N'100058', N'200001', N'好好', N'哲学类')
GO
GO
INSERT INTO [dbo].[book] ([b_borrow], [b_location], [b_author], [b_name], [b_id], [b_tid], [b_desc], [b_typeName]) VALUES (N'0', N'四层19排64架', N'伏尔泰.马克·吐温', N'世界大师侃幽默人生', N'100059', N'200001', N'好好', N'哲学类')
GO
GO
INSERT INTO [dbo].[book] ([b_borrow], [b_location], [b_author], [b_name], [b_id], [b_tid], [b_desc], [b_typeName]) VALUES (N'0', N'四层19排65架', N'伏尔泰.马克·吐温', N'世界大师侃幽默人生', N'100060', N'200001', N'好好', N'哲学类')
GO
GO
INSERT INTO [dbo].[book] ([b_borrow], [b_location], [b_author], [b_name], [b_id], [b_tid], [b_desc], [b_typeName]) VALUES (N'0', N'四层19排66架', N'泰戈尔.托尔斯泰', N'思想大师谈天才的激情', N'100061', N'200001', N'好好', N'哲学类')
GO
GO
INSERT INTO [dbo].[book] ([b_borrow], [b_location], [b_author], [b_name], [b_id], [b_tid], [b_desc], [b_typeName]) VALUES (N'0', N'四层19排67架', N'泰戈尔.托尔斯泰', N'思想大师谈天才的激情', N'100062', N'200001', N'好好', N'哲学类')
GO
GO
INSERT INTO [dbo].[book] ([b_borrow], [b_location], [b_author], [b_name], [b_id], [b_tid], [b_desc], [b_typeName]) VALUES (N'0', N'四层19排68架', N'培根', N'培根论理想人生', N'100063', N'200001', N'好好', N'哲学类')
GO
GO
INSERT INTO [dbo].[book] ([b_borrow], [b_location], [b_author], [b_name], [b_id], [b_tid], [b_desc], [b_typeName]) VALUES (N'0', N'四层19排69架', N'培根', N'培根论理想人生', N'100064', N'200001', N'好好', N'哲学类')
GO
GO
INSERT INTO [dbo].[book] ([b_borrow], [b_location], [b_author], [b_name], [b_id], [b_tid], [b_desc], [b_typeName]) VALUES (N'0', N'四层19排70架', N'叔本华', N'叔本华论生命悲剧哲学', N'100065', N'200001', N'好好', N'哲学类')
GO
GO
INSERT INTO [dbo].[book] ([b_borrow], [b_location], [b_author], [b_name], [b_id], [b_tid], [b_desc], [b_typeName]) VALUES (N'0', N'四层19排71架', N'叔本华', N'叔本华论生命悲剧哲学', N'100066', N'200001', N'好好', N'哲学类')
GO
GO
INSERT INTO [dbo].[book] ([b_borrow], [b_location], [b_author], [b_name], [b_id], [b_tid], [b_desc], [b_typeName]) VALUES (N'0', N'四层19排72架', N'叔本华', N'叔本华论生命悲剧哲学', N'100067', N'200001', N'好好', N'哲学类')
GO
GO
INSERT INTO [dbo].[book] ([b_borrow], [b_location], [b_author], [b_name], [b_id], [b_tid], [b_desc], [b_typeName]) VALUES (N'0', N'四层19排73架', N'泰戈尔.卢梭', N'人生大师论哲理智慧', N'100068', N'200001', N'好好', N'哲学类')
GO
GO
INSERT INTO [dbo].[book] ([b_borrow], [b_location], [b_author], [b_name], [b_id], [b_tid], [b_desc], [b_typeName]) VALUES (N'0', N'四层19排74架', N'泰戈尔.卢梭', N'人生大师论哲理智慧', N'100069', N'200001', N'好好', N'哲学类')
GO
GO
INSERT INTO [dbo].[book] ([b_borrow], [b_location], [b_author], [b_name], [b_id], [b_tid], [b_desc], [b_typeName]) VALUES (N'0', N'四层19排75架', N'泰戈尔.卢梭', N'人生大师论哲理智慧', N'100070', N'200001', N'好好', N'哲学类')
GO
GO
INSERT INTO [dbo].[book] ([b_borrow], [b_location], [b_author], [b_name], [b_id], [b_tid], [b_desc], [b_typeName]) VALUES (N'1', N'四层19排123架', N'石磊', N'安珂的故事', N'100118', N'200002', N'好好', N'小说类')
GO
GO
INSERT INTO [dbo].[book] ([b_borrow], [b_location], [b_author], [b_name], [b_id], [b_tid], [b_desc], [b_typeName]) VALUES (N'0', N'四层19排124架', N'高连营.李金凤', N'爱你，不久，就一生', N'100119', N'200002', N'测试修改', N'小说类')
GO
GO
INSERT INTO [dbo].[book] ([b_borrow], [b_location], [b_author], [b_name], [b_id], [b_tid], [b_desc], [b_typeName]) VALUES (N'0', N'四层19排125架', N'沈建平.谭征', N'走进蓝色文明海洋学探秘上', N'100120', N'200003', N'好好', N'科普类')
GO
GO
INSERT INTO [dbo].[book] ([b_borrow], [b_location], [b_author], [b_name], [b_id], [b_tid], [b_desc], [b_typeName]) VALUES (N'0', N'四层19排126架', N'沈建平.谭征', N'走进蓝色文明海洋学探秘下', N'100121', N'200003', N'好好', N'科普类')
GO
GO
INSERT INTO [dbo].[book] ([b_borrow], [b_location], [b_author], [b_name], [b_id], [b_tid], [b_desc], [b_typeName]) VALUES (N'0', N'四层19排127架', N'严姍琴等', N'我心中的家园环境科学漫步', N'100122', N'200003', N'好好', N'科普类')
GO
GO
INSERT INTO [dbo].[book] ([b_borrow], [b_location], [b_author], [b_name], [b_id], [b_tid], [b_desc], [b_typeName]) VALUES (N'0', N'四层19排128架', N'崔金泰等', N'和平的杠杆军事科学追踪上', N'100123', N'200003', N'好好', N'科普类')
GO
GO
INSERT INTO [dbo].[book] ([b_borrow], [b_location], [b_author], [b_name], [b_id], [b_tid], [b_desc], [b_typeName]) VALUES (N'0', N'四层19排129架', N'崔金泰等', N'和平的杠杆军事科学追踪下', N'100124', N'200003', N'好好', N'科普类')
GO
GO
INSERT INTO [dbo].[book] ([b_borrow], [b_location], [b_author], [b_name], [b_id], [b_tid], [b_desc], [b_typeName]) VALUES (N'0', N'四层19排130架', N'刘兴良等', N'跨越海陆空现代交通科学趣说', N'100125', N'200003', N'好好', N'科普类')
GO
GO
INSERT INTO [dbo].[book] ([b_borrow], [b_location], [b_author], [b_name], [b_id], [b_tid], [b_desc], [b_typeName]) VALUES (N'0', N'四层19排131架', N'刘兴良等', N'跨越海陆空现代交通科学趣说', N'100126', N'200003', N'好好', N'科普类')
GO
GO
INSERT INTO [dbo].[book] ([b_borrow], [b_location], [b_author], [b_name], [b_id], [b_tid], [b_desc], [b_typeName]) VALUES (N'0', N'四层19排132架', N'王洪等', N'奇特的能源家族能源学巡礼', N'100127', N'200003', N'好好', N'科普类')
GO
GO
INSERT INTO [dbo].[book] ([b_borrow], [b_location], [b_author], [b_name], [b_id], [b_tid], [b_desc], [b_typeName]) VALUES (N'0', N'四层19排133架', N'沈以淡等', N'赶超人脑的电脑计算机科学大观', N'100128', N'200003', N'好好', N'科普类')
GO
GO
INSERT INTO [dbo].[book] ([b_borrow], [b_location], [b_author], [b_name], [b_id], [b_tid], [b_desc], [b_typeName]) VALUES (N'0', N'四层19排134架', N'刘先曙等', N'创造明天的魔方新材料科学展望上', N'100129', N'200003', N'好好', N'科普类')
GO
GO
INSERT INTO [dbo].[book] ([b_borrow], [b_location], [b_author], [b_name], [b_id], [b_tid], [b_desc], [b_typeName]) VALUES (N'0', N'四层19排135架', N'刘先曙等', N'创造明天的魔方新材料科学展望下', N'100130', N'200003', N'好好', N'科普类')
GO
GO
INSERT INTO [dbo].[book] ([b_borrow], [b_location], [b_author], [b_name], [b_id], [b_tid], [b_desc], [b_typeName]) VALUES (N'0', N'四层19排136架', N'曹福成等', N'大自然的启迪仿生学揽胜上', N'100131', N'200003', N'好好', N'科普类')
GO
GO
INSERT INTO [dbo].[book] ([b_borrow], [b_location], [b_author], [b_name], [b_id], [b_tid], [b_desc], [b_typeName]) VALUES (N'0', N'四层19排137架', N'曹福成等', N'大自然的启迪仿生学揽胜下', N'100132', N'200003', N'好好', N'科普类')
GO
GO
INSERT INTO [dbo].[book] ([b_borrow], [b_location], [b_author], [b_name], [b_id], [b_tid], [b_desc], [b_typeName]) VALUES (N'0', N'四层19排138架', N'崔金泰等', N'和平的杠杆军事科学追踪上', N'100133', N'200003', N'好好', N'科普类')
GO
GO
INSERT INTO [dbo].[book] ([b_borrow], [b_location], [b_author], [b_name], [b_id], [b_tid], [b_desc], [b_typeName]) VALUES (N'0', N'四层19排139架', N'李龙臣等', N'万里蓝天任我游航空航天纵览上', N'100134', N'200003', N'好好', N'科普类')
GO
GO
INSERT INTO [dbo].[book] ([b_borrow], [b_location], [b_author], [b_name], [b_id], [b_tid], [b_desc], [b_typeName]) VALUES (N'0', N'四层19排140架', N'李龙臣等', N'万里蓝天任我游航空航天纵览下', N'100135', N'200003', N'好好', N'科普类')
GO
GO
INSERT INTO [dbo].[book] ([b_borrow], [b_location], [b_author], [b_name], [b_id], [b_tid], [b_desc], [b_typeName]) VALUES (N'0', N'四层19排141架', N'张书衍等', N'影响你一生的50个感慨', N'100136', N'200003', N'好好', N'科普类')
GO
GO
INSERT INTO [dbo].[book] ([b_borrow], [b_location], [b_author], [b_name], [b_id], [b_tid], [b_desc], [b_typeName]) VALUES (N'0', N'四层19排142架', N'张书衍等', N'影响你一生的50个感慨', N'100137', N'200003', N'好好', N'科普类')
GO
GO
INSERT INTO [dbo].[book] ([b_borrow], [b_location], [b_author], [b_name], [b_id], [b_tid], [b_desc], [b_typeName]) VALUES (N'0', N'四层19排143架', N'黎静', N'彭大将军1', N'100138', N'200004', N'好好', N'人物传记')
GO
GO
INSERT INTO [dbo].[book] ([b_borrow], [b_location], [b_author], [b_name], [b_id], [b_tid], [b_desc], [b_typeName]) VALUES (N'0', N'四层19排144架', N'黎静', N'彭大将军2', N'100139', N'200004', N'好好', N'人物传记')
GO
GO
INSERT INTO [dbo].[book] ([b_borrow], [b_location], [b_author], [b_name], [b_id], [b_tid], [b_desc], [b_typeName]) VALUES (N'0', N'四层19排145架', N'黎静', N'彭大将军2', N'100140', N'200004', N'好好', N'人物传记')
GO
GO
INSERT INTO [dbo].[book] ([b_borrow], [b_location], [b_author], [b_name], [b_id], [b_tid], [b_desc], [b_typeName]) VALUES (N'0', N'四层19排146架', N'黎静', N'彭大将军3', N'100141', N'200004', N'好好', N'人物传记')
GO
GO
INSERT INTO [dbo].[book] ([b_borrow], [b_location], [b_author], [b_name], [b_id], [b_tid], [b_desc], [b_typeName]) VALUES (N'0', N'四层19排147架', N'黎静', N'彭大将军3', N'100142', N'200004', N'好好', N'人物传记')
GO
GO
INSERT INTO [dbo].[book] ([b_borrow], [b_location], [b_author], [b_name], [b_id], [b_tid], [b_desc], [b_typeName]) VALUES (N'0', N'四层19排148架', N'黎静', N'彭大将军3', N'100143', N'200004', N'好好', N'人物传记')
GO
GO
INSERT INTO [dbo].[book] ([b_borrow], [b_location], [b_author], [b_name], [b_id], [b_tid], [b_desc], [b_typeName]) VALUES (N'0', N'四层19排149架', N'黎静', N'彭大将军4', N'100144', N'200004', N'好好', N'人物传记')
GO
GO
INSERT INTO [dbo].[book] ([b_borrow], [b_location], [b_author], [b_name], [b_id], [b_tid], [b_desc], [b_typeName]) VALUES (N'0', N'四层19排150架', N'黎静', N'彭大将军4', N'100145', N'200004', N'好好', N'人物传记')
GO
GO
INSERT INTO [dbo].[book] ([b_borrow], [b_location], [b_author], [b_name], [b_id], [b_tid], [b_desc], [b_typeName]) VALUES (N'0', N'四层19排151架', N'黎静', N'彭大将军4', N'100146', N'200004', N'好好', N'人物传记')
GO
GO
INSERT INTO [dbo].[book] ([b_borrow], [b_location], [b_author], [b_name], [b_id], [b_tid], [b_desc], [b_typeName]) VALUES (N'0', N'四层19排152架', N'黎静', N'彭大将军5', N'100147', N'200004', N'好好', N'人物传记')
GO
GO
INSERT INTO [dbo].[book] ([b_borrow], [b_location], [b_author], [b_name], [b_id], [b_tid], [b_desc], [b_typeName]) VALUES (N'0', N'四层19排153架', N'黎静', N'彭大将军5', N'100148', N'200004', N'好好', N'人物传记')
GO
GO
INSERT INTO [dbo].[book] ([b_borrow], [b_location], [b_author], [b_name], [b_id], [b_tid], [b_desc], [b_typeName]) VALUES (N'0', N'四层19排154架', N'黎静', N'彭大将军5', N'100149', N'200004', N'好好', N'人物传记')
GO
GO
INSERT INTO [dbo].[book] ([b_borrow], [b_location], [b_author], [b_name], [b_id], [b_tid], [b_desc], [b_typeName]) VALUES (N'0', N'四层19排155架', N'黎静', N'彭大将军6', N'100150', N'200004', N'好好', N'人物传记')
GO
GO
INSERT INTO [dbo].[book] ([b_borrow], [b_location], [b_author], [b_name], [b_id], [b_tid], [b_desc], [b_typeName]) VALUES (N'0', N'四层19排156架', N'黎静', N'彭大将军6', N'100151', N'200004', N'好好', N'人物传记')
GO
GO
INSERT INTO [dbo].[book] ([b_borrow], [b_location], [b_author], [b_name], [b_id], [b_tid], [b_desc], [b_typeName]) VALUES (N'0', N'四层19排157架', N'黎静', N'彭大将军6', N'100152', N'200004', N'好好', N'人物传记')
GO
GO
INSERT INTO [dbo].[book] ([b_borrow], [b_location], [b_author], [b_name], [b_id], [b_tid], [b_desc], [b_typeName]) VALUES (N'0', N'四层19排158架', N'寒风', N'中国夺鹿·淮海大战1', N'100153', N'200004', N'好好', N'人物传记')
GO
GO
INSERT INTO [dbo].[book] ([b_borrow], [b_location], [b_author], [b_name], [b_id], [b_tid], [b_desc], [b_typeName]) VALUES (N'0', N'四层19排159架', N'寒风', N'中国夺鹿·淮海大战1', N'100154', N'200004', N'好好', N'人物传记')
GO
GO
INSERT INTO [dbo].[book] ([b_borrow], [b_location], [b_author], [b_name], [b_id], [b_tid], [b_desc], [b_typeName]) VALUES (N'0', N'四层19排160架', N'寒风', N'中国夺鹿·淮海大战1', N'100155', N'200004', N'好好', N'人物传记')
GO
GO
INSERT INTO [dbo].[book] ([b_borrow], [b_location], [b_author], [b_name], [b_id], [b_tid], [b_desc], [b_typeName]) VALUES (N'0', N'四层19排161架', N'寒风', N'中国夺鹿·淮海大战2', N'100156', N'200004', N'好好', N'人物传记')
GO
GO
INSERT INTO [dbo].[book] ([b_borrow], [b_location], [b_author], [b_name], [b_id], [b_tid], [b_desc], [b_typeName]) VALUES (N'1', N'四层19排162架', N'寒风', N'中国夺鹿·淮海大战2', N'100157', N'200004', N'好好', N'人物传记')
GO
GO
INSERT INTO [dbo].[book] ([b_borrow], [b_location], [b_author], [b_name], [b_id], [b_tid], [b_desc], [b_typeName]) VALUES (N'0', N'四层19排163架', N'寒风', N'中国夺鹿·淮海大战3', N'100158', N'200004', N'好好', N'人物传记')
GO
GO
INSERT INTO [dbo].[book] ([b_borrow], [b_location], [b_author], [b_name], [b_id], [b_tid], [b_desc], [b_typeName]) VALUES (N'0', N'四层19排164架', N'寒风', N'中国夺鹿·淮海大战3', N'100159', N'200004', N'好好', N'人物传记')
GO
GO
INSERT INTO [dbo].[book] ([b_borrow], [b_location], [b_author], [b_name], [b_id], [b_tid], [b_desc], [b_typeName]) VALUES (N'0', N'四层19排165架', N'寒风', N'中国夺鹿·淮海大战4', N'100160', N'200004', N'好好', N'人物传记')
GO
GO
INSERT INTO [dbo].[book] ([b_borrow], [b_location], [b_author], [b_name], [b_id], [b_tid], [b_desc], [b_typeName]) VALUES (N'0', N'四层19排166架', N'寒风', N'中国夺鹿·淮海大战4', N'100161', N'200004', N'好好', N'人物传记')
GO
GO
INSERT INTO [dbo].[book] ([b_borrow], [b_location], [b_author], [b_name], [b_id], [b_tid], [b_desc], [b_typeName]) VALUES (N'0', N'四层19排167架', N'柳桤', N'战争奇观', N'100162', N'200004', N'好好', N'人物传记')
GO
GO
INSERT INTO [dbo].[book] ([b_borrow], [b_location], [b_author], [b_name], [b_id], [b_tid], [b_desc], [b_typeName]) VALUES (N'0', N'四层19排168架', N'蔡磊', N'世界全史速度读1', N'100163', N'200004', N'好好', N'人物传记')
GO
GO
INSERT INTO [dbo].[book] ([b_borrow], [b_location], [b_author], [b_name], [b_id], [b_tid], [b_desc], [b_typeName]) VALUES (N'0', N'四层19排169架', N'蔡磊', N'世界全史速度读2', N'100164', N'200004', N'好好', N'人物传记')
GO
GO
INSERT INTO [dbo].[book] ([b_borrow], [b_location], [b_author], [b_name], [b_id], [b_tid], [b_desc], [b_typeName]) VALUES (N'0', N'四层19排170架', N'蔡磊', N'世界全史速度读3', N'100165', N'200004', N'好好', N'人物传记')
GO
GO
INSERT INTO [dbo].[book] ([b_borrow], [b_location], [b_author], [b_name], [b_id], [b_tid], [b_desc], [b_typeName]) VALUES (N'0', N'四层19排171架', N'蔡磊', N'世界全史速度读4', N'100166', N'200004', N'好好', N'人物传记')
GO
GO
INSERT INTO [dbo].[book] ([b_borrow], [b_location], [b_author], [b_name], [b_id], [b_tid], [b_desc], [b_typeName]) VALUES (N'0', N'四层19排172架', N'蔡磊', N'世界全史速度读5', N'100167', N'200004', N'好好', N'人物传记')
GO
GO
INSERT INTO [dbo].[book] ([b_borrow], [b_location], [b_author], [b_name], [b_id], [b_tid], [b_desc], [b_typeName]) VALUES (N'0', N'四层19排173架', N'蔡磊', N'世界全史速度读6', N'100168', N'200004', N'好好', N'人物传记')
GO
GO
INSERT INTO [dbo].[book] ([b_borrow], [b_location], [b_author], [b_name], [b_id], [b_tid], [b_desc], [b_typeName]) VALUES (N'0', N'四层19排174架', N'蔡磊', N'世界全史速度读7', N'100169', N'200004', N'好好', N'人物传记')
GO
GO
INSERT INTO [dbo].[book] ([b_borrow], [b_location], [b_author], [b_name], [b_id], [b_tid], [b_desc], [b_typeName]) VALUES (N'0', N'四层19排175架', N'蔡磊', N'世界全史速度读8', N'100170', N'200004', N'好好', N'人物传记')
GO
GO
INSERT INTO [dbo].[book] ([b_borrow], [b_location], [b_author], [b_name], [b_id], [b_tid], [b_desc], [b_typeName]) VALUES (N'0', N'四层19排176架', N'蔡磊', N'世界全史速度读9', N'100171', N'200004', N'好好', N'人物传记')
GO
GO
INSERT INTO [dbo].[book] ([b_borrow], [b_location], [b_author], [b_name], [b_id], [b_tid], [b_desc], [b_typeName]) VALUES (N'0', N'四层19排177架', N'蔡磊', N'世界全史速度读10', N'100172', N'200004', N'好好', N'人物传记')
GO
GO
INSERT INTO [dbo].[book] ([b_borrow], [b_location], [b_author], [b_name], [b_id], [b_tid], [b_desc], [b_typeName]) VALUES (N'0', N'四层19排178架', N'蔡磊', N'世界全史速度读11', N'100173', N'200004', N'好好', N'人物传记')
GO
GO
INSERT INTO [dbo].[book] ([b_borrow], [b_location], [b_author], [b_name], [b_id], [b_tid], [b_desc], [b_typeName]) VALUES (N'0', N'四层19排179架', N'蔡磊', N'世界全史速度阅读15', N'100174', N'200004', N'好好', N'人物传记')
GO
GO
INSERT INTO [dbo].[book] ([b_borrow], [b_location], [b_author], [b_name], [b_id], [b_tid], [b_desc], [b_typeName]) VALUES (N'0', N'四层19排180架', N'蔡磊', N'世界全史速度阅读16', N'100175', N'200004', N'好好', N'人物传记')
GO
GO
INSERT INTO [dbo].[book] ([b_borrow], [b_location], [b_author], [b_name], [b_id], [b_tid], [b_desc], [b_typeName]) VALUES (N'0', N'四层19排181架', N'蔡磊', N'世界全史速度阅读17', N'100176', N'200004', N'好好', N'人物传记')
GO
GO
INSERT INTO [dbo].[book] ([b_borrow], [b_location], [b_author], [b_name], [b_id], [b_tid], [b_desc], [b_typeName]) VALUES (N'0', N'四层19排182架', N'蔡磊', N'世界全史速度阅读18', N'100177', N'200004', N'好好', N'人物传记')
GO
GO
INSERT INTO [dbo].[book] ([b_borrow], [b_location], [b_author], [b_name], [b_id], [b_tid], [b_desc], [b_typeName]) VALUES (N'0', N'四层19排183架', N'蔡磊', N'世界全史速度阅读21', N'100178', N'200004', N'好好', N'人物传记')
GO
GO
INSERT INTO [dbo].[book] ([b_borrow], [b_location], [b_author], [b_name], [b_id], [b_tid], [b_desc], [b_typeName]) VALUES (N'0', N'四层19排184架', N'蔡磊', N'世界全史速度阅读22', N'100179', N'200004', N'好好', N'人物传记')
GO
GO
INSERT INTO [dbo].[book] ([b_borrow], [b_location], [b_author], [b_name], [b_id], [b_tid], [b_desc], [b_typeName]) VALUES (N'0', N'四层19排185架', N'蔡磊', N'世界全史速度阅读23', N'100180', N'200004', N'好好', N'人物传记')
GO
GO
INSERT INTO [dbo].[book] ([b_borrow], [b_location], [b_author], [b_name], [b_id], [b_tid], [b_desc], [b_typeName]) VALUES (N'0', N'四层19排186架', N'蔡磊', N'世界全史速度阅读24', N'100181', N'200004', N'好好', N'人物传记')
GO
GO
INSERT INTO [dbo].[book] ([b_borrow], [b_location], [b_author], [b_name], [b_id], [b_tid], [b_desc], [b_typeName]) VALUES (N'0', N'四层19排187架', N'刘国琴等', N'神秘的生命世界遗传工程学揭秘', N'100182', N'200004', N'好好', N'人物传记')
GO
GO
INSERT INTO [dbo].[book] ([b_borrow], [b_location], [b_author], [b_name], [b_id], [b_tid], [b_desc], [b_typeName]) VALUES (N'0', N'四层19排188架', N'刘国琴等', N'神秘的生命世界遗传工程学揭秘', N'100183', N'200004', N'好好', N'人物传记')
GO
GO
INSERT INTO [dbo].[book] ([b_borrow], [b_location], [b_author], [b_name], [b_id], [b_tid], [b_desc], [b_typeName]) VALUES (N'0', N'四层19排189架', N'王洪等', N'奇特的能源家族能源学巡礼', N'100184', N'200004', N'好好', N'人物传记')
GO
GO
INSERT INTO [dbo].[book] ([b_borrow], [b_location], [b_author], [b_name], [b_id], [b_tid], [b_desc], [b_typeName]) VALUES (N'0', N'四层19排190架', N'沈以淡等', N'计算机科学大观', N'100185', N'200004', N'好好', N'人物传记')
GO
GO
INSERT INTO [dbo].[book] ([b_borrow], [b_location], [b_author], [b_name], [b_id], [b_tid], [b_desc], [b_typeName]) VALUES (N'0', N'四层19排191架', N'刘先曙等', N'新材料科学展望上', N'100186', N'200004', N'好好', N'人物传记')
GO
GO
INSERT INTO [dbo].[book] ([b_borrow], [b_location], [b_author], [b_name], [b_id], [b_tid], [b_desc], [b_typeName]) VALUES (N'0', N'四层19排192架', N'刘先曙等', N'新材料科学展望下', N'100187', N'200004', N'好好', N'人物传记')
GO
GO
INSERT INTO [dbo].[book] ([b_borrow], [b_location], [b_author], [b_name], [b_id], [b_tid], [b_desc], [b_typeName]) VALUES (N'0', N'四层19排193架', N'曹福成等', N'仿生学揽胜上', N'100188', N'200004', N'好好', N'人物传记')
GO
GO
INSERT INTO [dbo].[book] ([b_borrow], [b_location], [b_author], [b_name], [b_id], [b_tid], [b_desc], [b_typeName]) VALUES (N'0', N'四层19排194架', N'曹福成等', N'仿生学揽胜下', N'100189', N'200004', N'好好', N'人物传记')
GO
GO
INSERT INTO [dbo].[book] ([b_borrow], [b_location], [b_author], [b_name], [b_id], [b_tid], [b_desc], [b_typeName]) VALUES (N'0', N'四层19排195架', N'崔金泰等', N'军事科学追踪', N'100190', N'200004', N'好好', N'人物传记')
GO
GO
INSERT INTO [dbo].[book] ([b_borrow], [b_location], [b_author], [b_name], [b_id], [b_tid], [b_desc], [b_typeName]) VALUES (N'0', N'四层19排196架', N'许仲琳', N'封神演义一', N'100191', N'200004', N'好好', N'人物传记')
GO
GO
INSERT INTO [dbo].[book] ([b_borrow], [b_location], [b_author], [b_name], [b_id], [b_tid], [b_desc], [b_typeName]) VALUES (N'0', N'四层19排197架', N'许仲琳', N'封神演义一', N'100192', N'200004', N'好好', N'人物传记')
GO
GO
INSERT INTO [dbo].[book] ([b_borrow], [b_location], [b_author], [b_name], [b_id], [b_tid], [b_desc], [b_typeName]) VALUES (N'0', N'四层19排198架', N'许仲琳', N'封神演义二', N'100193', N'200004', N'好好', N'人物传记')
GO
GO
INSERT INTO [dbo].[book] ([b_borrow], [b_location], [b_author], [b_name], [b_id], [b_tid], [b_desc], [b_typeName]) VALUES (N'0', N'四层19排199架', N'许仲琳', N'封神演义二', N'100194', N'200004', N'好好', N'人物传记')
GO
GO
INSERT INTO [dbo].[book] ([b_borrow], [b_location], [b_author], [b_name], [b_id], [b_tid], [b_desc], [b_typeName]) VALUES (N'0', N'四层19排200架', N'许仲琳', N'封神演义三', N'100195', N'200004', N'好好', N'人物传记')
GO
GO
INSERT INTO [dbo].[book] ([b_borrow], [b_location], [b_author], [b_name], [b_id], [b_tid], [b_desc], [b_typeName]) VALUES (N'0', N'四层19排201架', N'许仲琳', N'封神演义三', N'100196', N'200004', N'好好', N'人物传记')
GO
GO
INSERT INTO [dbo].[book] ([b_borrow], [b_location], [b_author], [b_name], [b_id], [b_tid], [b_desc], [b_typeName]) VALUES (N'0', N'四层19排202架', N'许仲琳', N'封神演义四', N'100197', N'200004', N'好好', N'人物传记')
GO
GO
INSERT INTO [dbo].[book] ([b_borrow], [b_location], [b_author], [b_name], [b_id], [b_tid], [b_desc], [b_typeName]) VALUES (N'0', N'四层19排203架', N'许仲琳', N'封神演义四', N'100198', N'200004', N'好好', N'人物传记')
GO
GO
INSERT INTO [dbo].[book] ([b_borrow], [b_location], [b_author], [b_name], [b_id], [b_tid], [b_desc], [b_typeName]) VALUES (N'0', N'四层19排204架', N'许仲琳', N'封神演义五', N'100199', N'200004', N'好好', N'人物传记')
GO
GO
INSERT INTO [dbo].[book] ([b_borrow], [b_location], [b_author], [b_name], [b_id], [b_tid], [b_desc], [b_typeName]) VALUES (N'0', N'四层19排205架', N'许仲琳', N'封神演义五', N'100200', N'200004', N'好好', N'人物传记')
GO
GO
INSERT INTO [dbo].[book] ([b_borrow], [b_location], [b_author], [b_name], [b_id], [b_tid], [b_desc], [b_typeName]) VALUES (N'0', N'四层19排206架', N'冯梦龙', N'东周列国表二', N'100201', N'200004', N'好好', N'人物传记')
GO
GO
INSERT INTO [dbo].[book] ([b_borrow], [b_location], [b_author], [b_name], [b_id], [b_tid], [b_desc], [b_typeName]) VALUES (N'0', N'四层19排207架', N'冯梦龙', N'东周列国表三', N'100202', N'200004', N'好好', N'人物传记')
GO
GO
INSERT INTO [dbo].[book] ([b_borrow], [b_location], [b_author], [b_name], [b_id], [b_tid], [b_desc], [b_typeName]) VALUES (N'0', N'四层19排208架', N'冯梦龙', N'东周列国表四', N'100203', N'200004', N'好好', N'人物传记')
GO
GO
INSERT INTO [dbo].[book] ([b_borrow], [b_location], [b_author], [b_name], [b_id], [b_tid], [b_desc], [b_typeName]) VALUES (N'0', N'四层19排209架', N'冯梦龙', N'东周列国表五', N'100204', N'200004', N'好好', N'人物传记')
GO
GO
INSERT INTO [dbo].[book] ([b_borrow], [b_location], [b_author], [b_name], [b_id], [b_tid], [b_desc], [b_typeName]) VALUES (N'0', N'四层19排210架', N'冯梦龙', N'东周列国表六', N'100205', N'200004', N'好好', N'人物传记')
GO
GO
INSERT INTO [dbo].[book] ([b_borrow], [b_location], [b_author], [b_name], [b_id], [b_tid], [b_desc], [b_typeName]) VALUES (N'0', N'四层19排211架', N'北青', N'美国911', N'100206', N'200004', N'好好', N'人物传记')
GO
GO
INSERT INTO [dbo].[book] ([b_borrow], [b_location], [b_author], [b_name], [b_id], [b_tid], [b_desc], [b_typeName]) VALUES (N'0', N'四层19排212架', N'北青', N'美国911', N'100207', N'200004', N'好好', N'人物传记')
GO
GO
INSERT INTO [dbo].[book] ([b_borrow], [b_location], [b_author], [b_name], [b_id], [b_tid], [b_desc], [b_typeName]) VALUES (N'0', N'四层19排213架', N'北青', N'美国911', N'100208', N'200004', N'好好', N'人物传记')
GO
GO
INSERT INTO [dbo].[book] ([b_borrow], [b_location], [b_author], [b_name], [b_id], [b_tid], [b_desc], [b_typeName]) VALUES (N'0', N'四层19排214架', N'李丽君译', N' 20世纪世界领导人传记百科1', N'100209', N'200004', N'好好', N'人物传记')
GO
GO
INSERT INTO [dbo].[book] ([b_borrow], [b_location], [b_author], [b_name], [b_id], [b_tid], [b_desc], [b_typeName]) VALUES (N'0', N'四层19排215架', N'李丽君译', N' 20世纪世界领导人传记百科2', N'100210', N'200004', N'好好', N'人物传记')
GO
GO
INSERT INTO [dbo].[book] ([b_borrow], [b_location], [b_author], [b_name], [b_id], [b_tid], [b_desc], [b_typeName]) VALUES (N'0', N'四层19排216架', N'李丽君译', N' 20世纪世界领导人传记百科3', N'100211', N'200004', N'好好', N'人物传记')
GO
GO
INSERT INTO [dbo].[book] ([b_borrow], [b_location], [b_author], [b_name], [b_id], [b_tid], [b_desc], [b_typeName]) VALUES (N'0', N'四层19排217架', N'李丽君译', N' 20世纪世界领导人传记百科4', N'100212', N'200004', N'好好', N'人物传记')
GO
GO
INSERT INTO [dbo].[book] ([b_borrow], [b_location], [b_author], [b_name], [b_id], [b_tid], [b_desc], [b_typeName]) VALUES (N'0', N'四层19排218架', N'李丽君译', N' 20世纪世界领导人传记百科5', N'100213', N'200004', N'好好', N'人物传记')
GO
GO
INSERT INTO [dbo].[book] ([b_borrow], [b_location], [b_author], [b_name], [b_id], [b_tid], [b_desc], [b_typeName]) VALUES (N'0', N'四层19排219架', N'李丽君译', N' 20世纪世界领导人传记百科6', N'100214', N'200004', N'好好', N'人物传记')
GO
GO
INSERT INTO [dbo].[book] ([b_borrow], [b_location], [b_author], [b_name], [b_id], [b_tid], [b_desc], [b_typeName]) VALUES (N'0', N'四层19排220架', N'李丽君译', N' 20世纪世界领导人传记百科7', N'100215', N'200004', N'好好', N'人物传记')
GO
GO
INSERT INTO [dbo].[book] ([b_borrow], [b_location], [b_author], [b_name], [b_id], [b_tid], [b_desc], [b_typeName]) VALUES (N'0', N'四层19排221架', N'李丽君译', N' 20世纪世界领导人传记百科8', N'100216', N'200004', N'好好', N'人物传记')
GO
GO
INSERT INTO [dbo].[book] ([b_borrow], [b_location], [b_author], [b_name], [b_id], [b_tid], [b_desc], [b_typeName]) VALUES (N'0', N'四层19排222架', N'李丽君译', N' 20世纪世界领导人传记百科9', N'100217', N'200004', N'好好', N'人物传记')
GO
GO
INSERT INTO [dbo].[book] ([b_borrow], [b_location], [b_author], [b_name], [b_id], [b_tid], [b_desc], [b_typeName]) VALUES (N'0', N'四层19排223架', N'李丽君译', N' 20世纪世界领导人传记百科10', N'100218', N'200004', N'好好', N'人物传记')
GO
GO
INSERT INTO [dbo].[book] ([b_borrow], [b_location], [b_author], [b_name], [b_id], [b_tid], [b_desc], [b_typeName]) VALUES (N'0', N'四层19排224架', N'李丽君译', N' 20世纪世界领导人传记百科11', N'100219', N'200004', N'好好', N'人物传记')
GO
GO
INSERT INTO [dbo].[book] ([b_borrow], [b_location], [b_author], [b_name], [b_id], [b_tid], [b_desc], [b_typeName]) VALUES (N'0', N'四层19排225架', N'李丽君译', N' 20世纪世界领导人传记百科12', N'100220', N'200004', N'好好', N'人物传记')
GO
GO
INSERT INTO [dbo].[book] ([b_borrow], [b_location], [b_author], [b_name], [b_id], [b_tid], [b_desc], [b_typeName]) VALUES (N'0', N'四层19排226架', N'李丽君译', N' 20世纪世界领导人传记百科13', N'100221', N'200004', N'好好', N'人物传记')
GO
GO
INSERT INTO [dbo].[book] ([b_borrow], [b_location], [b_author], [b_name], [b_id], [b_tid], [b_desc], [b_typeName]) VALUES (N'0', N'四层19排227架', N'李丽君译', N' 20世纪世界领导人传记百科14', N'100222', N'200004', N'好好', N'人物传记')
GO
GO
INSERT INTO [dbo].[book] ([b_borrow], [b_location], [b_author], [b_name], [b_id], [b_tid], [b_desc], [b_typeName]) VALUES (N'0', N'四层19排228架', N'李丽君译', N' 20世纪世界领导人传记百科15', N'100223', N'200004', N'好好', N'人物传记')
GO
GO
INSERT INTO [dbo].[book] ([b_borrow], [b_location], [b_author], [b_name], [b_id], [b_tid], [b_desc], [b_typeName]) VALUES (N'0', N'四层19排229架', N'李丽君译', N' 20世纪世界领导人传记百科16', N'100224', N'200004', N'好好', N'人物传记')
GO
GO
INSERT INTO [dbo].[book] ([b_borrow], [b_location], [b_author], [b_name], [b_id], [b_tid], [b_desc], [b_typeName]) VALUES (N'0', N'四层19排230架', N'万高潮等', N'蒋介石与他的家族一', N'100225', N'200004', N'好好', N'人物传记')
GO
GO
INSERT INTO [dbo].[book] ([b_borrow], [b_location], [b_author], [b_name], [b_id], [b_tid], [b_desc], [b_typeName]) VALUES (N'0', N'四层19排231架', N'万高潮等', N'蒋介石与他的家族二', N'100226', N'200004', N'好好', N'人物传记')
GO
GO
INSERT INTO [dbo].[book] ([b_borrow], [b_location], [b_author], [b_name], [b_id], [b_tid], [b_desc], [b_typeName]) VALUES (N'0', N'四层19排232架', N'万高潮等', N'蒋介石与他的爱将一', N'100227', N'200004', N'好好', N'人物传记')
GO
GO
INSERT INTO [dbo].[book] ([b_borrow], [b_location], [b_author], [b_name], [b_id], [b_tid], [b_desc], [b_typeName]) VALUES (N'0', N'四层19排233架', N'万高潮等', N'蒋介石与他的爱将一', N'100228', N'200004', N'好好', N'人物传记')
GO
GO
INSERT INTO [dbo].[book] ([b_borrow], [b_location], [b_author], [b_name], [b_id], [b_tid], [b_desc], [b_typeName]) VALUES (N'0', N'四层19排234架', N'万高潮等', N'蒋介石与他的爱将二', N'100229', N'200004', N'好好', N'人物传记')
GO
GO
INSERT INTO [dbo].[book] ([b_borrow], [b_location], [b_author], [b_name], [b_id], [b_tid], [b_desc], [b_typeName]) VALUES (N'0', N'四层19排235架', N'万高潮等', N'蒋介石与他的爱将三', N'100230', N'200004', N'好好', N'人物传记')
GO
GO
INSERT INTO [dbo].[book] ([b_borrow], [b_location], [b_author], [b_name], [b_id], [b_tid], [b_desc], [b_typeName]) VALUES (N'0', N'四层19排236架', N'万高潮等', N'蒋介石与他的智囊一', N'100231', N'200004', N'好好', N'人物传记')
GO
GO
INSERT INTO [dbo].[book] ([b_borrow], [b_location], [b_author], [b_name], [b_id], [b_tid], [b_desc], [b_typeName]) VALUES (N'0', N'四层19排237架', N'万高潮等', N'蒋介石与他的智囊二', N'100232', N'200004', N'好好', N'人物传记')
GO
GO
INSERT INTO [dbo].[book] ([b_borrow], [b_location], [b_author], [b_name], [b_id], [b_tid], [b_desc], [b_typeName]) VALUES (N'0', N'四层19排238架', N'万高潮等', N'蒋介石与他的智囊三', N'100233', N'200004', N'好好', N'人物传记')
GO
GO

-- ----------------------------
-- Table structure for bookType
-- ----------------------------
DROP TABLE [dbo].[bookType]
GO
CREATE TABLE [dbo].[bookType] (
[bookTypeDesc] varchar(100) NULL ,
[bookTypeName] varchar(10) NULL ,
[t_bookid] varchar(6) NOT NULL 
)


GO

-- ----------------------------
-- Records of bookType
-- ----------------------------
INSERT INTO [dbo].[bookType] ([bookTypeDesc], [bookTypeName], [t_bookid]) VALUES (N'', N'哲学类', N'200001')
GO
GO
INSERT INTO [dbo].[bookType] ([bookTypeDesc], [bookTypeName], [t_bookid]) VALUES (null, N'小说类', N'200002')
GO
GO
INSERT INTO [dbo].[bookType] ([bookTypeDesc], [bookTypeName], [t_bookid]) VALUES (N'', N'科普类', N'200003')
GO
GO
INSERT INTO [dbo].[bookType] ([bookTypeDesc], [bookTypeName], [t_bookid]) VALUES (null, N'人物传记', N'200004')
GO
GO

-- ----------------------------
-- Table structure for jsrecord
-- ----------------------------
DROP TABLE [dbo].[jsrecord]
GO
CREATE TABLE [dbo].[jsrecord] (
[js_sj] datetime NULL ,
[js_s_id] varchar(6) NOT NULL ,
[js_b_id] varchar(6) NOT NULL ,
[js_s_name] varchar(10) NULL ,
[js_b_name] varchar(100) NULL 
)


GO

-- ----------------------------
-- Records of jsrecord
-- ----------------------------
INSERT INTO [dbo].[jsrecord] ([js_sj], [js_s_id], [js_b_id], [js_s_name], [js_b_name]) VALUES (N'2020-01-06 11:25:00.000', N'4634', N'100118', N'闫浩宇', N'安珂的故事')
GO
GO

-- ----------------------------
-- Table structure for student
-- ----------------------------
DROP TABLE [dbo].[student]
GO
CREATE TABLE [dbo].[student] (
[s_id] varchar(6) NOT NULL ,
[s_name] varchar(10) NULL ,
[s_sex] varchar(1) NULL ,
[s_specil] varchar(20) NULL ,
[s_jnum] int NULL ,
[s_password] varchar(8) NULL 
)


GO

-- ----------------------------
-- Records of student
-- ----------------------------
INSERT INTO [dbo].[student] ([s_id], [s_name], [s_sex], [s_specil], [s_jnum], [s_password]) VALUES (N'300001', N'吕茂林', N'0', N'软件工程', N'0', N'300001')
GO
GO
INSERT INTO [dbo].[student] ([s_id], [s_name], [s_sex], [s_specil], [s_jnum], [s_password]) VALUES (N'300002', N'李廷涛', N'0', N'软件工程', N'0', N'300002')
GO
GO
INSERT INTO [dbo].[student] ([s_id], [s_name], [s_sex], [s_specil], [s_jnum], [s_password]) VALUES (N'300003', N'戚志贤', N'0', N'软件工程', N'0', N'300003')
GO
GO
INSERT INTO [dbo].[student] ([s_id], [s_name], [s_sex], [s_specil], [s_jnum], [s_password]) VALUES (N'300004', N'尤福', N'0', N'网络工程', N'0', N'300004')
GO
GO
INSERT INTO [dbo].[student] ([s_id], [s_name], [s_sex], [s_specil], [s_jnum], [s_password]) VALUES (N'300008', N'周火英', N'1', N'计算机科学与技术', N'0', N'300008')
GO
GO
INSERT INTO [dbo].[student] ([s_id], [s_name], [s_sex], [s_specil], [s_jnum], [s_password]) VALUES (N'300009', N'张幻', N'0', N'计算机科学与技术', N'0', N'300009')
GO
GO
INSERT INTO [dbo].[student] ([s_id], [s_name], [s_sex], [s_specil], [s_jnum], [s_password]) VALUES (N'300011', N'曹丹珍', N'1', N'计算机科学与技术', N'0', N'300011')
GO
GO
INSERT INTO [dbo].[student] ([s_id], [s_name], [s_sex], [s_specil], [s_jnum], [s_password]) VALUES (N'300012', N'何馨语', N'1', N'数学', N'0', N'300012')
GO
GO
INSERT INTO [dbo].[student] ([s_id], [s_name], [s_sex], [s_specil], [s_jnum], [s_password]) VALUES (N'300013', N'韩艺', N'1', N'美术', N'0', N'300013')
GO
GO
INSERT INTO [dbo].[student] ([s_id], [s_name], [s_sex], [s_specil], [s_jnum], [s_password]) VALUES (N'300014', N'杨灵竹', N'1', N'数学', N'0', N'300014')
GO
GO
INSERT INTO [dbo].[student] ([s_id], [s_name], [s_sex], [s_specil], [s_jnum], [s_password]) VALUES (N'300015', N'沈月珍', N'1', N'数学', N'0', N'300015')
GO
GO
INSERT INTO [dbo].[student] ([s_id], [s_name], [s_sex], [s_specil], [s_jnum], [s_password]) VALUES (N'300016', N'卫莉', N'1', N'数学', N'0', N'300016')
GO
GO
INSERT INTO [dbo].[student] ([s_id], [s_name], [s_sex], [s_specil], [s_jnum], [s_password]) VALUES (N'300022', N'张幻', N'1', N'计算机科学与技术', N'0', N'300022')
GO
GO
INSERT INTO [dbo].[student] ([s_id], [s_name], [s_sex], [s_specil], [s_jnum], [s_password]) VALUES (N'300032', N'张幻波', N'1', N'计算机科学与技术', N'0', N'300032')
GO
GO
INSERT INTO [dbo].[student] ([s_id], [s_name], [s_sex], [s_specil], [s_jnum], [s_password]) VALUES (N'300033', N'曹建军', N'0', N'网络工程', N'0', N'300033')
GO
GO
INSERT INTO [dbo].[student] ([s_id], [s_name], [s_sex], [s_specil], [s_jnum], [s_password]) VALUES (N'300045', N'周火英', N'1', N'计算机科学与技术', N'0', N'300045')
GO
GO
INSERT INTO [dbo].[student] ([s_id], [s_name], [s_sex], [s_specil], [s_jnum], [s_password]) VALUES (N'300066', N'曹建军', N'0', N'网络工程', N'0', N'300066')
GO
GO
INSERT INTO [dbo].[student] ([s_id], [s_name], [s_sex], [s_specil], [s_jnum], [s_password]) VALUES (N'300221', N'吴', N'0', N'网络工程', N'0', N'300221')
GO
GO
INSERT INTO [dbo].[student] ([s_id], [s_name], [s_sex], [s_specil], [s_jnum], [s_password]) VALUES (N'300222', N'吴昌', N'0', N'网络工程', N'0', N'300222')
GO
GO
INSERT INTO [dbo].[student] ([s_id], [s_name], [s_sex], [s_specil], [s_jnum], [s_password]) VALUES (N'300456', N'吕茂林', N'0', N'软件工程', N'0', N'300456')
GO
GO
INSERT INTO [dbo].[student] ([s_id], [s_name], [s_sex], [s_specil], [s_jnum], [s_password]) VALUES (N'305465', N'吴昌', N'0', N'网络工程', N'0', N'305465')
GO
GO
INSERT INTO [dbo].[student] ([s_id], [s_name], [s_sex], [s_specil], [s_jnum], [s_password]) VALUES (N'4634', N'闫浩宇', N'0', N'计算机科学与技术', N'5', N'1234')
GO
GO

-- ----------------------------
-- Indexes structure for table admin
-- ----------------------------

-- ----------------------------
-- Primary Key structure for table admin
-- ----------------------------
ALTER TABLE [dbo].[admin] ADD PRIMARY KEY ([ad_id])
GO

-- ----------------------------
-- Indexes structure for table book
-- ----------------------------

-- ----------------------------
-- Primary Key structure for table book
-- ----------------------------
ALTER TABLE [dbo].[book] ADD PRIMARY KEY ([b_id])
GO

-- ----------------------------
-- Indexes structure for table bookType
-- ----------------------------

-- ----------------------------
-- Primary Key structure for table bookType
-- ----------------------------
ALTER TABLE [dbo].[bookType] ADD PRIMARY KEY ([t_bookid])
GO

-- ----------------------------
-- Indexes structure for table jsrecord
-- ----------------------------

-- ----------------------------
-- Primary Key structure for table jsrecord
-- ----------------------------
ALTER TABLE [dbo].[jsrecord] ADD PRIMARY KEY ([js_s_id], [js_b_id])
GO

-- ----------------------------
-- Indexes structure for table student
-- ----------------------------

-- ----------------------------
-- Primary Key structure for table student
-- ----------------------------
ALTER TABLE [dbo].[student] ADD PRIMARY KEY ([s_id])
GO

-- ----------------------------
-- Foreign Key structure for table [dbo].[book]
-- ----------------------------
ALTER TABLE [dbo].[book] ADD FOREIGN KEY ([b_tid]) REFERENCES [dbo].[bookType] ([t_bookid]) ON DELETE NO ACTION ON UPDATE NO ACTION
GO

-- ----------------------------
-- Foreign Key structure for table [dbo].[jsrecord]
-- ----------------------------
ALTER TABLE [dbo].[jsrecord] ADD FOREIGN KEY ([js_b_id]) REFERENCES [dbo].[book] ([b_id]) ON DELETE NO ACTION ON UPDATE NO ACTION
GO
ALTER TABLE [dbo].[jsrecord] ADD FOREIGN KEY ([js_s_id]) REFERENCES [dbo].[student] ([s_id]) ON DELETE NO ACTION ON UPDATE NO ACTION
GO
