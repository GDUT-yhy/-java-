package com.java.model;

public class Book {
	
	private String bookid;
	private String bookName;
	private String author;

	private String bookTyprId;
	private String bookTypeName;
	private String bookDesc;
	private String booklocation;
	private String bookborrow;
	

	public Book() {
		super();
		// TODO �Զ����ɵĹ��캯�����
	}
/**
 * 
 * ����ʱʹ��id���鼮״̬�Ĺ��캯��
 * 
 * @param bookid
 * @param bookborrow
 */
	public Book(String bookid, String bookborrow) {
		super();
		this.bookid = bookid;
		this.bookborrow = bookborrow;
	}
	public Book(String bookid, String bookName, String author, String bookTypeId, String booklocation,
			String bookborrow,String bookTypeName,String bookDesc) {
		super();
		this.bookid = bookid;
		this.bookName = bookName;
		this.author = author;
		this.bookTyprId = bookTypeId;
		this.booklocation = booklocation;
		this.bookborrow = bookborrow;
		this.bookTypeName=bookTypeName;
		this.bookDesc=bookDesc;
	}
	
	
	
	public Book(String bookName, String author, String bookTyprId) {
		super();
		this.bookName = bookName;
		this.author = author;
		this.bookTyprId = bookTyprId;
	}

	public String getBookid() {
		return bookid;
	}
	public void setBookid(String bookid) {
		this.bookid = bookid;
	}
	public String getBooklocation() {
		return booklocation;
	}
	public void setBooklocation(String booklocation) {
		this.booklocation = booklocation;
	}
	public String getBookborrow() {
		return bookborrow;
	}
	public void setBookborrow(String bookborrow) {
		this.bookborrow = bookborrow;
	}
	public String getId() {
		return bookid;
	}
	public void setId(String id) {
		this.bookid = id;
	}
	public String getBookName() {
		return bookName;
	}
	public void setBookName(String bookName) {
		this.bookName = bookName;
	}
	public String getAuthor() {
		return author;
	}
	public void setAuthor(String author) {
		this.author = author;
	}
	
	
	public String getBookTyprId() {
		return bookTyprId;
	}
	public void setBookTyprId(String bookTyprId) {
		this.bookTyprId = bookTyprId;
	}
	public String getBookTypeName() {
		return bookTypeName;
	}
	public void setBookTypeName(String bookTypeName) {
		this.bookTypeName = bookTypeName;
	}
	public String getBookDesc() {
		return bookDesc;
	}
	public void setBookDesc(String bookDesc) {
		this.bookDesc = bookDesc;
	}
	
	

	
	
	
	
	
	

}
