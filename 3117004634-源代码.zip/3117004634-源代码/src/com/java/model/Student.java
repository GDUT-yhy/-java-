package com.java.model;

import org.omg.CORBA.PRIVATE_MEMBER;

import com.sun.scenario.effect.impl.prism.PrImage;

import sun.print.resources.serviceui;

public class Student {
	private  String StuName;
	private  String StuPassword;
	private  String StuSpecil;
	private  String StuSex;
	private  int StujNum;
	private  String StuId;
	
	
	public Student() {
		super();
		// TODO �Զ����ɵĹ��캯�����
	}
	
	public Student(String stuName, String stuSpecil, String stuSex, String stuId) {
		super();
		StuName = stuName;
		StuSpecil = stuSpecil;
		StuSex = stuSex;
		StuId = stuId;
	}

	/**
	 * ��¼�Ĺ��췽��
	 * 
	 * @param stuId
	 * @param stuPassword
	 */
	public Student(String stuId, String stuPassword) {
		super();
		StuPassword = stuPassword;
		StuId = stuId;
	}


	public Student(String stuName, String stuPassword, String stuSpecil, String stuSex, int stujNum, String stuId) {
		super();
		StuName = stuName;
		StuPassword = stuPassword;
		StuSpecil = stuSpecil;
		StuSex = stuSex;
		StujNum = stujNum;
		StuId = stuId;
	}


	public String getStuName() {
		return StuName;
	}
	public void setStuName(String stuName) {
		StuName = stuName;
	}
	public String getStuPassword() {
		return StuPassword;
	}
	public void setStuPassword(String stuPassword) {
		StuPassword = stuPassword;
	}
	public String getStuSpecil() {
		return StuSpecil;
	}
	public void setStuSpecil(String stuSpecil) {
		StuSpecil = stuSpecil;
	}
	public String getStuSex() {
		return StuSex;
	}
	public void setStuSex(String stuSex) {
		StuSex = stuSex;
	}
	public int getStujNum() {
		return StujNum;
	}
	public void setStujNum(int stujNum) {
		StujNum = stujNum;
	}
	public String getStuId() {
		return StuId;
	}
	public void setStuId(String stuId) {
		StuId = stuId;
	}
	
	
	

}
