package com.java.model;

import java.text.SimpleDateFormat;
import java.util.Date;

public class JsRecord {

	   
        String NowTime;
	    String stuId;
	    String bookId;
	    String stuName;
	    String bookName;
	    
		public JsRecord() {
			super();
			// TODO �Զ����ɵĹ��캯�����
		}
		
		public String getNowTime() {
			return NowTime;
		}
		
		/**
		 * ����ʱ���췽��
		 * @param nowTime
		 * @param stuId
		 * @param bookId
		 * @param stuName
		 * @param bookName
		 */
		public JsRecord(String nowTime, String stuId, String bookId, String stuName, String bookName) {
			super();
			NowTime = nowTime;
			this.stuId = stuId;
			this.bookId = bookId;
			this.stuName = stuName;
			this.bookName = bookName;
		}

		
		
		public void setNowTime(String nowTime) {
			NowTime = nowTime;
		}
		public String getStuId() {
			return stuId;
		}
		public void setStuId(String stuId) {
			this.stuId = stuId;
		}
		public String getBookId() {
			return bookId;
		}
		public void setBookId(String bookId) {
			this.bookId = bookId;
		}
		public String getStuName() {
			return stuName;
		}
		public void setStuName(String stuName) {
			this.stuName = stuName;
		}
		public String getBookName() {
			return bookName;
		}
		public void setBookName(String bookName) {
			this.bookName = bookName;
		}
		
		public String toString() {
			return bookName;
		}
	 
  
}
