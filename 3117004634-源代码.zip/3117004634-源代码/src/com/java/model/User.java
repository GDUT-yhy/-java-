package com.java.model;
/**
 * �û�ʵ��
 * @author 14352
 *
 */
public class User {
	private String id;
	private String userName;//�û���
	private String password;//����
	private String sex;
	public User() {
		super();
		// TODO �Զ����ɵĹ��캯�����
	}
	
	public String getSex() {
		return sex;
	}

	public void setSex(String sex) {
		this.sex = sex;
	}

	public User(String id, String password) {
		super();
		this.id = id;
		this.password = password;
	}

	public User(String id, String userName, String password, String sex) {
		super();
		this.id = id;
		this.userName = userName;
		this.password = password;
		this.sex = sex;
	}

	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserNamel(String userNamel) {
		this.userName = userNamel;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	
}
