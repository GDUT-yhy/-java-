package com.java.view;

import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.sql.Connection;

import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import javax.swing.LayoutStyle.ComponentPlacement;
import javax.swing.border.EmptyBorder;

import com.java.dao.StudentDao;
import com.java.dao.UserDao;
import com.java.model.Student;
import com.java.model.User;
import com.java.util.DbUtil;
import com.java.util.StringUtil;
import com.java.util.TxtUtil;

public class LogOnFrm extends JFrame {
TxtUtil txtUtil=new TxtUtil();
	private JPanel contentPane;
	private JTextField UserIDtxt;
	private JPasswordField passwordtxt;
	private DbUtil dbUtil= new DbUtil();
	private UserDao userDao = new UserDao();
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					LogOnFrm frame = new LogOnFrm();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * ��������
	 * 
	 */
	public LogOnFrm() {
		setTitle("\u7BA1\u7406\u5458\u767B\u9646");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 552, 321);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		
		JLabel lblNewLabel = new JLabel("\u56FE\u4E66\u7BA1\u7406\u7CFB\u7EDF");
		lblNewLabel.setFont(new Font("΢���ź�", Font.BOLD, 19));
		lblNewLabel.setIcon(new ImageIcon("C:\\Users\\14352\\Pictures\\logo-2.png"));
		
		JLabel lblNewLabel_1 = new JLabel("\u5DE5\u53F7\u6216\u5B66\u53F7\uFF1A");
		lblNewLabel_1.setIcon(new ImageIcon("C:\\Users\\14352\\Desktop\\user_24px_1211510_easyicon.net.png"));
		
		JLabel lblNewLabel_2 = new JLabel("\u5BC6  \u7801\uFF1A");
		lblNewLabel_2.setIcon(new ImageIcon("C:\\Users\\14352\\Desktop\\\u56FE\u6807\\Password_24px_1178344_easyicon.net.png"));
		
		UserIDtxt = new JTextField();
		UserIDtxt.addKeyListener(new KeyAdapter() {
			  /**
			   	* �����ı�������ĳ��Ⱥ����ͺ�Ĭ����ʾ
			 *		
			 */
					public void keyTyped(KeyEvent e) {
						txtUtil.limtLong(e, UserIDtxt);
						txtUtil.limtNum(e);
					}
				});
		UserIDtxt.setColumns(10);
		
		passwordtxt = new JPasswordField();
		passwordtxt.addKeyListener(new KeyAdapter() {
			  /**
			   	* �����ı�������ĳ��Ⱥ����ͺ�Ĭ����ʾ
			 *		
			 */
					public void keyTyped(KeyEvent e) {
						txtUtil.limtLong8(e, passwordtxt);
						
					}
				});
		/**
		 * ����Ա��¼��ť
		 */
		JButton btnNewButton = new JButton("\u7BA1\u7406\u5458\u767B\u5F55");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				 loginActionPerformed(e);
			}
		});
		/**
		 * ���ð�ť
		 */
		JButton btnNewButton_1 = new JButton("\u91CD\u7F6E");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				resetValueActionPerformd(e);
			}
		});
		
		JButton btnNewButton_2 = new JButton("\u5B66\u751F\u767B\u5F55 ");
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e )  {
				 studentLogoActionPeform(e);
			}
		});
		
		JButton btnNewButton_3 = new JButton("\u6CE8  \u518C");
		btnNewButton_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				addnewuserActionPeform(e);
			}
		});
		GroupLayout gl_contentPane = new GroupLayout(contentPane);
		gl_contentPane.setHorizontalGroup(
			gl_contentPane.createParallelGroup(Alignment.TRAILING)
				.addGroup(gl_contentPane.createSequentialGroup()
					.addGroup(gl_contentPane.createParallelGroup(Alignment.TRAILING)
						.addGroup(gl_contentPane.createSequentialGroup()
							.addGap(53)
							.addComponent(btnNewButton_3)
							.addGap(31)
							.addComponent(btnNewButton)
							.addGap(26)
							.addComponent(btnNewButton_2, GroupLayout.PREFERRED_SIZE, 117, GroupLayout.PREFERRED_SIZE))
						.addComponent(lblNewLabel)
						.addGroup(gl_contentPane.createSequentialGroup()
							.addContainerGap()
							.addGroup(gl_contentPane.createParallelGroup(Alignment.TRAILING)
								.addComponent(lblNewLabel_1)
								.addComponent(lblNewLabel_2))
							.addGroup(gl_contentPane.createParallelGroup(Alignment.TRAILING)
								.addComponent(passwordtxt, GroupLayout.DEFAULT_SIZE, 334, Short.MAX_VALUE)
								.addComponent(UserIDtxt, GroupLayout.DEFAULT_SIZE, 334, Short.MAX_VALUE))))
					.addPreferredGap(ComponentPlacement.RELATED)
					.addComponent(btnNewButton_1)
					.addGap(41))
		);
		gl_contentPane.setVerticalGroup(
			gl_contentPane.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_contentPane.createSequentialGroup()
					.addComponent(lblNewLabel)
					.addGap(39)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
						.addComponent(UserIDtxt, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
						.addComponent(lblNewLabel_1))
					.addPreferredGap(ComponentPlacement.RELATED)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
						.addGroup(gl_contentPane.createSequentialGroup()
							.addComponent(passwordtxt, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
							.addGap(18)
							.addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
								.addComponent(btnNewButton_2)
								.addComponent(btnNewButton_3)
								.addComponent(btnNewButton))
							.addPreferredGap(ComponentPlacement.RELATED)
							.addComponent(btnNewButton_1))
						.addComponent(lblNewLabel_2))
					.addContainerGap(15, Short.MAX_VALUE))
		);
		contentPane.setLayout(gl_contentPane);
		this.setLocationRelativeTo(null);//����jrem����  Ĭ��nullΪ����
	}
	
	/**
	 * ע���û�����
	 * @param e
	 */
	protected void addnewuserActionPeform(ActionEvent e) {
		AddNewUser addNewUser=new AddNewUser();
		addNewUser.setVisible(true);
	}

	/**
	 * ѧ����¼
	 * @param e
	 */
	
	protected void studentLogoActionPeform(ActionEvent evt) {
		String userid=this.UserIDtxt.getText();//��ȡ�û���������   
		String password=new String(this.passwordtxt.getPassword());
		/**
		 *�ж��Ƿ�Ϊ�գ��жϵķ�����stringutil���Ѿ����壡
		 */
		if (StringUtil.isEmpty(userid))
		{
			JOptionPane.showMessageDialog(null, "�û�������Ϊ��");
			return;
		}
		
		if (StringUtil.isEmpty(password))
		{
			JOptionPane.showMessageDialog(null, "���벻��Ϊ��");
			return;
		}
	 	Student yhy = new Student(userid,password);//          ����������û��������룬ʵ��һ��user
		
		Connection con =null;
		try {
			con=dbUtil.getCon();
			Student currentUser=StudentDao.login(con, yhy);      //����������������Ӻ�user����ʽ����userDao���е�¼��֤ 
			if (currentUser!=null) {
			
				
				JOptionPane.showMessageDialog(this, "��ӭ�㣡"+currentUser.getStuName());
												//ɾ��ԭ����
				StudentUserFrm studentUserFrm=new StudentUserFrm(currentUser);
				studentUserFrm.setVisible(true);				//���������ڲ����ӻ�1
				dispose();	
			}else {
				JOptionPane.showMessageDialog(null, "�û������������");
			}
			
		} catch (Exception e1) {
			// TODO �Զ����ɵ� catch ��
			e1.printStackTrace();
		}finally {
			try {
				dbUtil.closeCon(con);
			} catch (Exception e) {
				// TODO �Զ����ɵ� catch ��
				e.printStackTrace();
			}
		}
		
	}

	/**
	 * ����Ա��¼
	 * 
	 * @param evt
	 */
	private void loginActionPerformed(ActionEvent evt) {
	
		String userid=this.UserIDtxt.getText();//��ȡ�û���������   
		String password=new String(this.passwordtxt.getPassword());
		
		/**
		 *�ж��Ƿ�Ϊ�գ��жϵķ�����stringutil���Ѿ����壡
		 */
		if (StringUtil.isEmpty(userid))
		{
			JOptionPane.showMessageDialog(null, "�û�������Ϊ��");
			return;
		}
		
		if (StringUtil.isEmpty(password))
		{
			JOptionPane.showMessageDialog(null, "���벻��Ϊ��");
			return;
		}
		
		User yhy = new User(userid,password);//          ����������û��������룬ʵ��һ��user
		Connection con =null;
		try {
			con=dbUtil.getCon();
			User currentUser=userDao.login(con, yhy);      //����������������Ӻ�user����ʽ����userDao���е�¼��֤ 
			if (currentUser!=null) {
				JOptionPane.showMessageDialog(null, "��¼�ɹ�");
				/**
				 * 
				 */
				dispose();									//ɾ��ԭ����
				new MainFrm().setVisible(true);				//���������ڲ����ӻ�1
				
			}else {
				JOptionPane.showMessageDialog(null, "�û������������");
			}
			
		} catch (Exception e1) {
			// TODO �Զ����ɵ� catch ��
			e1.printStackTrace();
		}finally {
			try {
				dbUtil.closeCon(con);
			} catch (Exception e) {
				// TODO �Զ����ɵ� catch ��
				e.printStackTrace();
			}
		}
		
		
		
	}

/**
 * ���� �¼�����
 */
	private void resetValueActionPerformd(ActionEvent evt) {
		
		this.UserIDtxt.setText("");
		this.passwordtxt.setText("");
		
	}
}
