package com.java.view;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import com.java.dao.UserDao;
import com.java.model.Student;
import com.java.model.User;
import com.java.util.DbUtil;
import com.java.util.TxtUtil;

import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.ImageIcon;
import javax.swing.JTextField;
import javax.swing.LayoutStyle.ComponentPlacement;
import javax.swing.JRadioButton;
import javax.swing.ButtonGroup;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.sql.Connection;
import java.awt.event.ActionEvent;
import javax.swing.JPasswordField;

public class AddNewUser extends JFrame {
	private DbUtil dbUtil=new DbUtil();
	private JPanel contentPane;
	private JTextField name_1;
	private JTextField id;
	private final ButtonGroup buttonGroup = new ButtonGroup();
	private JPasswordField passwordField;
	private JPasswordField passwordField_1;
	JRadioButton nan =null;
	JRadioButton nv =null;
	UserDao userDao=new UserDao();
	TxtUtil txtUtil=new TxtUtil();

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					AddNewUser frame = new AddNewUser();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public AddNewUser() {
		setTitle("\u7528\u6237\u6CE8\u518C");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 590, 326);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		
		JLabel lblNewLabel = new JLabel("");
		lblNewLabel.setIcon(new ImageIcon("C:\\Users\\14352\\Pictures\\logo-2.png"));
		
		name_1 = new JTextField();
		name_1.addKeyListener(new KeyAdapter() {
			  /**
			   	* �����ı�������ĳ��Ⱥ����ͺ�Ĭ����ʾ
			 *		
			 */
					public void keyTyped(KeyEvent e) {
						txtUtil.limtLong10(e, name_1);
						
					}
				});
	
		name_1.setColumns(10);
		
		JLabel name = new JLabel(" \u59D3  \u540D \uFF1A");
		
		JLabel lblNewLabel_2 = new JLabel(" \u5BC6  \u7801 \uFF1A");
		
		JLabel lblNewLabel_3 = new JLabel("\u786E\u8BA4\u5BC6\u7801\uFF1A");
		
		JLabel lblNewLabel_4 = new JLabel("ID\uFF1A");
		
		id = new JTextField();
		id.addKeyListener(new KeyAdapter() {
			  /**
			   	* �����ı�������ĳ��Ⱥ����ͺ�Ĭ����ʾ
			 *		
			 */
					public void keyTyped(KeyEvent e) {
						txtUtil.limtLong(e, id);
						txtUtil.limtNum(e);
					}
				});
	
		id.setColumns(10);
		
		 nan = new JRadioButton("\u7537");
		buttonGroup.add(nan);
		nan.setSelected(true);
		
		 nv = new JRadioButton("\u5973");
		buttonGroup.add(nv);
		
		JButton btnNewButton = new JButton("\u6CE8\u518C");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			zhuceuser(e);
			
			}
		});
		
		passwordField = new JPasswordField();
		passwordField.addKeyListener(new KeyAdapter() {
			  /**
			   	* �����ı�������ĳ��Ⱥ����ͺ�Ĭ����ʾ
			 *		
			 */
					public void keyTyped(KeyEvent e) {
						txtUtil.limtLong8(e, passwordField);
						
					}
				});
		passwordField_1 = new JPasswordField();
		passwordField_1.addKeyListener(new KeyAdapter() {
			  /**
			   	* �����ı�������ĳ��Ⱥ����ͺ�Ĭ����ʾ
			 *		
			 */
					public void keyTyped(KeyEvent e) {
						txtUtil.limtLong8(e, passwordField_1);
						
					}
				});
		GroupLayout gl_contentPane = new GroupLayout(contentPane);
		gl_contentPane.setHorizontalGroup(
			gl_contentPane.createParallelGroup(Alignment.TRAILING)
				.addGroup(gl_contentPane.createSequentialGroup()
					.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING, false)
						.addComponent(lblNewLabel)
						.addGroup(gl_contentPane.createSequentialGroup()
							.addGap(76)
							.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING, false)
								.addComponent(name, Alignment.TRAILING, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
								.addComponent(lblNewLabel_2, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
								.addComponent(lblNewLabel_3, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
							.addPreferredGap(ComponentPlacement.RELATED)
							.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
								.addGroup(gl_contentPane.createSequentialGroup()
									.addGroup(gl_contentPane.createParallelGroup(Alignment.TRAILING, false)
										.addComponent(passwordField, Alignment.LEADING)
										.addComponent(name_1, Alignment.LEADING))
									.addGap(33)
									.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
										.addGroup(gl_contentPane.createSequentialGroup()
											.addComponent(nan)
											.addPreferredGap(ComponentPlacement.RELATED)
											.addComponent(nv))
										.addComponent(lblNewLabel_4, GroupLayout.PREFERRED_SIZE, 53, GroupLayout.PREFERRED_SIZE)))
								.addComponent(passwordField_1, GroupLayout.PREFERRED_SIZE, 86, GroupLayout.PREFERRED_SIZE))))
					.addPreferredGap(ComponentPlacement.RELATED)
					.addComponent(id, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
					.addContainerGap(104, Short.MAX_VALUE))
				.addGroup(gl_contentPane.createSequentialGroup()
					.addContainerGap(380, Short.MAX_VALUE)
					.addComponent(btnNewButton, GroupLayout.PREFERRED_SIZE, 84, GroupLayout.PREFERRED_SIZE)
					.addGap(96))
		);
		gl_contentPane.setVerticalGroup(
			gl_contentPane.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_contentPane.createSequentialGroup()
					.addComponent(lblNewLabel)
					.addGap(18)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
						.addComponent(name)
						.addComponent(name_1, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
						.addComponent(lblNewLabel_4)
						.addComponent(id, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
					.addGap(18)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
						.addComponent(lblNewLabel_2)
						.addComponent(passwordField, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
						.addComponent(nan)
						.addComponent(nv))
					.addGap(18)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
						.addComponent(lblNewLabel_3)
						.addComponent(passwordField_1, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
					.addGap(18)
					.addComponent(btnNewButton)
					.addContainerGap(133, Short.MAX_VALUE))
		);
		contentPane.setLayout(gl_contentPane);
	}

	/***
	 * ע�����Ա
	 * @param e
	 */
	protected void zhuceuser(ActionEvent e) {
	

		
		String id=this.id.getText();
		String name=this.name_1.getText();
		if ("".equals(id)||"".equals(name)) {
			JOptionPane.showMessageDialog(this, "id����������Ϊ��");
			return;
		}
		
		String password=new String(this.passwordField.getPassword());
		
		String newpassword2=new String(this.passwordField_1.getPassword());
		if (password.equals(newpassword2)==false) {
			JOptionPane.showMessageDialog(null, "�������벻һ�£����������룡");
			resetvalue();
			return;
		}
		String Sex="0";//Ĭ��Ϊ��
		
		if (nv.isSelected()) {
			Sex="1";//ѡŮ��Ů
		}
		
		
	
		User user=new User(name, id,  password, Sex);
		
		Connection con=null;
		try {
			con=dbUtil.getCon();
		
			
			int n=userDao.adduser(con, user);;
			if (n==1) {
				JOptionPane.showMessageDialog(this, "ע��ɹ�����ӭ�¹���Ա��");
				dispose();		
			}else {
				JOptionPane.showMessageDialog(this, "ע��ʧ�ܣ�");
			}
		} catch (Exception e1) {
			JOptionPane.showMessageDialog(this, "ע��ʧ�ܣ�");
			e1.printStackTrace();
		}finally {
			try {
				dbUtil.closeCon(con);
			} catch (Exception e1) {
				
				e1.printStackTrace();
			}
		}
		
	}
	
	private void resetvalue() {
		this.passwordField.setText("");
		this.passwordField_1.setText("");
		
	}
	
}
