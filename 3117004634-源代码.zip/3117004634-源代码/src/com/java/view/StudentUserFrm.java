package com.java.view;
import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.Connection;
import java.sql.ResultSet;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Vector;

import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JDesktopPane;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.LayoutStyle.ComponentPlacement;
import javax.swing.UIManager;
import javax.swing.border.EmptyBorder;
import javax.swing.border.LineBorder;
import javax.swing.border.TitledBorder;
import javax.swing.table.DefaultTableModel;

import com.java.dao.BookDao;
import com.java.dao.BookTypeDao;
import com.java.dao.JsDao;
import com.java.dao.StudentDao;
import com.java.model.Book;
import com.java.model.BookType;
import com.java.model.JsRecord;
import com.java.model.Student;
import com.java.util.DbUtil;
import com.java.util.TxtUtil;

public class StudentUserFrm extends JFrame {
	TxtUtil txtUtil=new TxtUtil();
	private JPanel contentPane;
	private JDesktopPane table1=null;
	private JTextField s_authortxt;
	private JTextField s_bookNametxt;
	private DbUtil dbUtil=new DbUtil();
	private BookTypeDao bookTypeDao=new BookTypeDao();
	private BookType bookType =new BookType();
	private JComboBox s_bookTypeJcb;
	private JTable Booktable;
	JLabel lblNewLabel_2;
	private JTable table;
    static Student studentuser;
    private JTextField Studentmessage;
    private JLabel lblNewLabel;
    JLabel lblNewLabel_3;
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					StudentUserFrm frame = new StudentUserFrm(studentuser);
					frame.setVisible(true);
					
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 * @param studentuser2 
	 */
	public StudentUserFrm(Student studentuser2) {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 1153, 935);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		
		JPanel panel = new JPanel();
		panel.setBorder(new TitledBorder(UIManager.getBorder("TitledBorder.border"), "\u56FE\u4E66\u68C0\u7D22", TitledBorder.LEADING, TitledBorder.TOP, null, new Color(0, 0, 0)));
		
		JLabel label = new JLabel("\u56FE\u4E66\u540D\u79F0\uFF1A");
		
		s_bookNametxt = new JTextField();
		s_bookNametxt.addKeyListener(new KeyAdapter() {
			  /**
			   	* �����ı�������ĳ��Ⱥ����ͺ�Ĭ����ʾ
			 *		
			 */
					public void keyTyped(KeyEvent e) {
						txtUtil.limtLong20(e, s_bookNametxt);
						
					}
				});
		s_bookNametxt.setColumns(10);
		
		JLabel label_1 = new JLabel("\u4F5C  \u8005\uFF1A");
		
		s_authortxt = new JTextField();
		s_authortxt.addKeyListener(new KeyAdapter() {
			  /**
			   	* �����ı�������ĳ��Ⱥ����ͺ�Ĭ����ʾ
			 *		
			 */
					public void keyTyped(KeyEvent e) {
						txtUtil.limtLong10(e, s_authortxt);
						
					}
				});
		s_authortxt.setColumns(10);
		
		JLabel label_2 = new JLabel("\u56FE\u4E66\u7C7B\u522B\uFF1A");
		
		 s_bookTypeJcb = new JComboBox();
		
		JButton button = new JButton("\u67E5   \u8BE2");
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				bookSearchActinonPerformed(e);
				
			}
		});
		GroupLayout gl_panel = new GroupLayout(panel);
		gl_panel.setHorizontalGroup(
			gl_panel.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_panel.createSequentialGroup()
					.addContainerGap()
					.addComponent(label)
					.addPreferredGap(ComponentPlacement.RELATED)
					.addComponent(s_bookNametxt, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
					.addGap(18)
					.addComponent(label_1)
					.addGap(18)
					.addComponent(s_authortxt, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
					.addPreferredGap(ComponentPlacement.UNRELATED)
					.addComponent(label_2)
					.addGap(18)
					.addComponent(s_bookTypeJcb, GroupLayout.PREFERRED_SIZE, 128, GroupLayout.PREFERRED_SIZE)
					.addPreferredGap(ComponentPlacement.RELATED, 350, Short.MAX_VALUE)
					.addComponent(button, GroupLayout.PREFERRED_SIZE, 119, GroupLayout.PREFERRED_SIZE)
					.addContainerGap())
		);
		gl_panel.setVerticalGroup(
			gl_panel.createParallelGroup(Alignment.TRAILING)
				.addGroup(gl_panel.createSequentialGroup()
					.addGroup(gl_panel.createParallelGroup(Alignment.BASELINE)
						.addComponent(label)
						.addComponent(s_bookNametxt, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
						.addComponent(label_1)
						.addComponent(s_authortxt, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
						.addComponent(label_2)
						.addComponent(s_bookTypeJcb, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
						.addComponent(button))
					.addContainerGap(19, Short.MAX_VALUE))
		);
		panel.setLayout(gl_panel);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setViewportBorder(new LineBorder(Color.YELLOW));
		scrollPane.setToolTipText("");
		
		JScrollPane scrollPane_1 = new JScrollPane();
		scrollPane_1.setViewportBorder(new TitledBorder(UIManager.getBorder("TitledBorder.border"), "", TitledBorder.LEADING, TitledBorder.TOP, null, new Color(0, 0, 0)));
		scrollPane_1.setToolTipText("");
		
		JButton button_1 = new JButton("\u8FD8  \u4E66");
		button_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				returnbookActionPeform(e, studentuser2);
				int borrownum=countborrowednum();
				  lblNewLabel_2.setText("����ͼ��"+Booktable.getRowCount()+"��"+"    �ڹ�ͼ�鹲��"+borrownum+"��"+"    ���ͼ�鹲��"+(Booktable.getRowCount()-borrownum)+"��");

			}
		});
		
		
		// ���鰴ť
		JButton button_2 = new JButton("\u501F  \u4E66");
		button_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				borrowbookActionPeform( e, studentuser2);
				int borrownum=countborrowednum();
				  lblNewLabel_2.setText("����ͼ��"+Booktable.getRowCount()+"��"+"    �ڹ�ͼ�鹲��"+borrownum+"��"+"    ���ͼ�鹲��"+(Booktable.getRowCount()-borrownum)+"��");

			}
		});
		
		 lblNewLabel = new JLabel("\u501F\u4E66\u8BB0\u5F55\uFF1A");
		lblNewLabel.setText("��ǰ����ͼ��"+studentuser2.getStujNum()+"��");
		
		JLabel lblNewLabel_1 = new JLabel("\u56FE\u4E66\u7BA1\u7406\u7CFB\u7EDF\u2014\u2014\u5B66\u751F\u7AEF");
		lblNewLabel_1.setFont(new Font("΢���ź� Light", Font.BOLD, 27));
		lblNewLabel_1.setIcon(new ImageIcon("C:\\Users\\14352\\Pictures\\logo-2.png"));
		
		JButton btnNewButton = new JButton("");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				flashtable(e,studentuser2);
				int borrownum=countborrowednum();
				  lblNewLabel_2.setText("����ͼ��"+Booktable.getRowCount()+"��"+"    �ڹ�ͼ�鹲��"+borrownum+"��"+"    ���ͼ�鹲��"+(Booktable.getRowCount()-borrownum)+"��");
				  lblNewLabel_3.setText("");
			}
		});
		btnNewButton.setBorder(null);
		btnNewButton.setContentAreaFilled(false);
		btnNewButton.setIcon(new ImageIcon("C:\\Users\\14352\\Desktop\\\u8BFE\u8BBE\u5B66\u4E60\\\u56FE\u6807\\refresh_reload_repeat_rotate_sync_16px_1225490_easyicon.net.png"));
		
		Studentmessage = new JTextField();
		Studentmessage.setFont(new Font("΢���ź� Light", Font.BOLD, 19));
		Studentmessage.setEditable(false);
		Studentmessage.setBorder(null);
		Studentmessage.setText(studentuser2.getStuId()+studentuser2.getStuName());
		Studentmessage.setColumns(10);
		
		JButton btnNewButton_1 = new JButton("\u4FEE\u6539\u5BC6\u7801");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				jDGmethod(e,studentuser2);
				
		     
			}
		});
		
	 lblNewLabel_2 = new JLabel("New label");
		
		 lblNewLabel_3 = new JLabel("");
		lblNewLabel_3.setBorder(null);
		GroupLayout gl_contentPane = new GroupLayout(contentPane);
		gl_contentPane.setHorizontalGroup(
			gl_contentPane.createParallelGroup(Alignment.LEADING)
				.addGroup(Alignment.TRAILING, gl_contentPane.createSequentialGroup()
					.addContainerGap(805, Short.MAX_VALUE)
					.addComponent(btnNewButton_1)
					.addPreferredGap(ComponentPlacement.UNRELATED)
					.addComponent(button_1, GroupLayout.PREFERRED_SIZE, 91, GroupLayout.PREFERRED_SIZE)
					.addPreferredGap(ComponentPlacement.RELATED)
					.addComponent(button_2, GroupLayout.PREFERRED_SIZE, 100, GroupLayout.PREFERRED_SIZE)
					.addContainerGap())
				.addGroup(gl_contentPane.createSequentialGroup()
					.addGap(17)
					.addComponent(panel, GroupLayout.DEFAULT_SIZE, 1094, Short.MAX_VALUE)
					.addContainerGap())
				.addGroup(gl_contentPane.createSequentialGroup()
					.addContainerGap()
					.addComponent(lblNewLabel)
					.addPreferredGap(ComponentPlacement.RELATED, 952, Short.MAX_VALUE)
					.addComponent(btnNewButton)
					.addGap(29))
				.addGroup(gl_contentPane.createSequentialGroup()
					.addContainerGap()
					.addComponent(scrollPane_1, GroupLayout.DEFAULT_SIZE, 1097, Short.MAX_VALUE)
					.addContainerGap())
				.addGroup(gl_contentPane.createSequentialGroup()
					.addContainerGap()
					.addComponent(lblNewLabel_1)
					.addPreferredGap(ComponentPlacement.RELATED, 258, Short.MAX_VALUE)
					.addComponent(Studentmessage, GroupLayout.PREFERRED_SIZE, 230, GroupLayout.PREFERRED_SIZE)
					.addContainerGap())
				.addGroup(gl_contentPane.createSequentialGroup()
					.addGap(16)
					.addComponent(scrollPane, GroupLayout.DEFAULT_SIZE, 1095, Short.MAX_VALUE)
					.addContainerGap())
				.addGroup(gl_contentPane.createSequentialGroup()
					.addContainerGap()
					.addComponent(lblNewLabel_2)
					.addPreferredGap(ComponentPlacement.RELATED, 702, Short.MAX_VALUE)
					.addComponent(lblNewLabel_3)
					.addGap(36))
		);
		gl_contentPane.setVerticalGroup(
			gl_contentPane.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_contentPane.createSequentialGroup()
					.addContainerGap()
					.addGroup(gl_contentPane.createParallelGroup(Alignment.TRAILING)
						.addComponent(lblNewLabel_1)
						.addComponent(Studentmessage, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
					.addPreferredGap(ComponentPlacement.RELATED)
					.addComponent(panel, GroupLayout.PREFERRED_SIZE, 73, GroupLayout.PREFERRED_SIZE)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
						.addGroup(gl_contentPane.createSequentialGroup()
							.addGap(2)
							.addComponent(lblNewLabel_2))
						.addGroup(gl_contentPane.createSequentialGroup()
							.addPreferredGap(ComponentPlacement.RELATED)
							.addComponent(lblNewLabel_3)))
					.addPreferredGap(ComponentPlacement.RELATED)
					.addComponent(scrollPane, GroupLayout.PREFERRED_SIZE, 281, GroupLayout.PREFERRED_SIZE)
					.addGap(25)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
						.addComponent(lblNewLabel)
						.addComponent(btnNewButton, GroupLayout.PREFERRED_SIZE, 17, GroupLayout.PREFERRED_SIZE))
					.addPreferredGap(ComponentPlacement.RELATED)
					.addComponent(scrollPane_1, GroupLayout.PREFERRED_SIZE, 211, GroupLayout.PREFERRED_SIZE)
					.addGap(60)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
						.addComponent(button_2)
						.addComponent(button_1)
						.addComponent(btnNewButton_1)))
		);
		
		table = new JTable();
		table.getTableHeader().setReorderingAllowed(false);
		table.setModel(new DefaultTableModel(
			new Object[][] {
			},
			new String[] {
				"\u56FE\u4E66\u7F16\u53F7", "\u56FE\u4E66\u540D\u79F0", "\u501F\u4E66\u4EBA", "\u501F\u4E66\u65F6\u95F4"
			}
		) {
			boolean[] columnEditables = new boolean[] {
				false, false, false, false
			};
			public boolean isCellEditable(int row, int column) {
				return columnEditables[column];
			}
		});
		table.getColumnModel().getColumn(2).setPreferredWidth(67);
		scrollPane_1.setViewportView(table);
		
		Booktable = new JTable();
	    Booktable.getTableHeader().setReorderingAllowed(false);
		Booktable.addMouseListener(new MouseAdapter() {
			@Override
			public void mousePressed(MouseEvent e) {
				bookTableMousePressd(e);
			}
		});
		Booktable.setModel(new DefaultTableModel(
			new Object[][] {
			},
			new String[] {
				"\u56FE\u4E66\u7F16\u53F7", "\u56FE\u4E66\u540D\u79F0", "\u4F5C\u8005", "\u56FE\u4E66\u7B80\u4ECB", "\u56FE\u4E66\u4F4D\u7F6E", "\u56FE\u4E66\u7C7B\u522B", "\u662F\u5426\u5728\u9986"
			}
		) {
			boolean[] columnEditables = new boolean[] {
				false, false, false, false, false, false, false
			};
			public boolean isCellEditable(int row, int column) {
				return columnEditables[column];
			}
		});
		scrollPane.setViewportView(Booktable);
		contentPane.setLayout(gl_contentPane);
		fillTable(new Book());
		fillBookType("search");
		
		fillJSTable(studentuser2) ;
		  int borrownum=countborrowednum();
		  lblNewLabel_2.setText("����ͼ��"+Booktable.getRowCount()+"��"+"    �ڹ�ͼ�鹲��"+borrownum+"��"+"    ���ͼ�鹲��"+(Booktable.getRowCount()-borrownum)+"��");

	
	}
	
	
	
	private int countborrowednum() {
		int num=Booktable.getRowCount();
		int i = 0;int n=0;
		for (; n < num; n++) {
			
			if (Booktable.getValueAt(n,6).equals("�ڹ�")) {
				i++;
			}
			
		}
	  return i;
	}
	
	
	
	
	/**
	 * ����ʱ�䴦�����޸�ͼ����Ϣ����¼��Ϣ���޸�ѧ��������Ŀ
	 * 
	 * @param evt
	 * @param jsStudent
	 */

	private void borrowbookActionPeform(ActionEvent evt, Student jsStudent) {
		
		Book book2=new Book();
		int row=this.Booktable.getSelectedRow();
		if (row==-1) {
			JOptionPane.showMessageDialog(this, "��ѡ��Ҫ���ͼ��");
		}
		String borrow=(String) Booktable.getValueAt(row,6);
		
		if ("�ڹ�".equals(borrow)) {
			book2.setBookborrow("1");
			
		}else if("�����".equals(borrow)) {
			JOptionPane.showMessageDialog(this, "��ǰͼ�鲻�ڹݣ�����ʧ��");
			return;}
		book2.setBookid((String) Booktable.getValueAt(row, 0));
		book2.setBookName((String)Booktable.getValueAt(row, 1));
		book2.setAuthor((String)Booktable.getValueAt(row,2 ));
		book2.setBookDesc((String)Booktable.getValueAt(row, 3));
		book2.setBooklocation((String)Booktable.getValueAt(row, 4));
		book2.setBookTypeName((String) Booktable.getValueAt(row,5));
		
		BookType bookType=(BookType)this.s_bookTypeJcb.getSelectedItem();
		String  booktypeId=bookType.getId();
		book2.setBookTyprId(booktypeId);
		//���������¼����
		JsRecord jsRecord2=new JsRecord();
		jsRecord2.setBookId((String) Booktable.getValueAt(row, 0));
		jsRecord2.setBookName((String)Booktable.getValueAt(row, 1));
		jsRecord2.setStuId(jsStudent.getStuId());
		jsRecord2.setStuName(jsStudent.getStuName());
		int jsNum=jsStudent.getStujNum();
		jsNum++;
		jsStudent.setStujNum(jsNum);
		SimpleDateFormat df2 = new SimpleDateFormat("yyyy-MM-dd HH:mm");//�������ڸ�ʽ
        Date now = new Date();
        String NowTime= df2.format(now);  //��ȡ����ʱ��
        
        jsRecord2.setNowTime(NowTime);
		/**
		 * ���ݿ����
		 */
        Connection con=null;
		try {
			con=dbUtil.getCon();
			BookDao bookDao=new BookDao();
			JsDao  jsDao=new JsDao();
			StudentDao studentDao=new StudentDao();
			int daoNum=bookDao.update(con, book2);//����ͼ��� ���õ����շ���ֵ
			int jsdaoNum=jsDao.AddjsRecord(con, jsRecord2);//����������������ܷ���ֵ
			int studentjsNum=studentDao.Studentborrw(con, jsStudent);//��ѧ��������Ŀ+1
			
			if (daoNum==1&&jsdaoNum==1&&studentjsNum==1) {
				JOptionPane.showMessageDialog(this, "����ɹ�");
				lblNewLabel.setText("��ǰ����ͼ��"+jsStudent.getStujNum()+"��");
			      table.removeAll();             //���ɹ����±���
				this.fillJSTable(jsStudent);   //���뵱ǰ�û����������Ľ����¼��
				fillTable(new Book());
			}
			
			
		} catch (Exception e) {
			JOptionPane.showMessageDialog(this, "��¼ʧ��");
			e.printStackTrace();
		}finally {
			try {
				dbUtil.closeCon(con);
			} catch (Exception e) {
				
				e.printStackTrace();
			}
		}
		
	
	
	
	}



	/**
	 * ������¼�����
	 * @param met
	 */
	private void bookTableMousePressd(MouseEvent met)
	{   
		Book book1=new Book();
		int row=this.Booktable.getSelectedRow();
		book1.setBookid((String) Booktable.getValueAt(row, 0));
		book1.setBookName((String)Booktable.getValueAt(row, 1));
		book1.setAuthor((String)Booktable.getValueAt(row,2 ));
		book1.setBookDesc((String)Booktable.getValueAt(row, 3));
		book1.setBooklocation((String)Booktable.getValueAt(row, 4));
		book1.setBookTypeName((String) Booktable.getValueAt(row,5));
		String borrow=(String) Booktable.getValueAt(row,6);
	
		if ("�ڹ�".equals(borrow)) {
			book1.setBookborrow("0");
		}else if("�����".equals(borrow)) {
			book1.setBookborrow("1");
		}
		BookType bookType=(BookType)this.s_bookTypeJcb.getSelectedItem();
		String  booktypeId=bookType.getId();
		book1.setBookTyprId(booktypeId);
		/**
		 *���������� ֱ���鵽����һ���������� 
		 */
	  String booktypename= (String)this.Booktable.getValueAt(row, 5);
	  
	    int n=this.s_bookTypeJcb.getItemCount();
	    
	    
	  for(int i=0;i<n;i++) {
		  BookType item=(BookType)this.s_bookTypeJcb.getItemAt(i);
		
		  if (item.getBookTypeName().equals(booktypename)) {
			 
			this.s_bookTypeJcb.setSelectedIndex(i);
		}
		  
	  }
	}

	/**
	 * ͼ���ѯ�¼�����
	 * @param e
	 */
	protected void bookSearchActinonPerformed(ActionEvent evt) {
		String bookName=this.s_bookNametxt.getText();
		String author=this.s_authortxt.getText();
		BookType bookType=(BookType)this.s_bookTypeJcb.getSelectedItem();
		String  booktypeId=bookType.getId();
		
		
			Book book=new Book(bookName,author,booktypeId);
		
		
		this.fillTable(book);
		
		 	 lblNewLabel_3.setText("���鵽"+Booktable.getRowCount()+"����¼");
		
		
	}

	
	
	/**
	 * ��ʼ�������� 
	 * @param type
	 */
	private void fillBookType(String type) {
		Connection con=null;
		try {
				con=dbUtil.getCon();
				BookType bookType=null;
				ResultSet rs= bookTypeDao.List(con, new BookType());
				
				if ("search".equals(type)) {
					bookType=new BookType();
					
					bookType.setBookTypeName("��ѡ��...");
					bookType.setId("-1");
					this.s_bookTypeJcb.addItem(bookType);
					
				}
				
				while (rs.next())
				{
					bookType=new BookType();
					bookType.setBookTypeName(rs.getString("bookTypeName"));
					bookType.setId(rs.getString("t_bookid"));
					if ("search".equals(type)) {
						
						this.s_bookTypeJcb.addItem(bookType);
						
					}else if ("modify".equals(type)) {
					
						//equals�������ж�ֵ�Ƿ���ȵ�
					}
				
				}
			
		} catch (Exception e) {e.printStackTrace();}finally 
		{
			try {dbUtil.closeCon(con);}
			catch (Exception e) {e.printStackTrace();}
		}
	}
	
	/**
	 * �����ʼ��
	 * @param book
	 */
	
	public void fillTable(Book book) 
	{

		DefaultTableModel dtm=(DefaultTableModel) Booktable.getModel();
		dtm.setRowCount(0);//�������
		Connection con = null;
		try {
				con=dbUtil.getCon();
				ResultSet rs= BookDao.list(con,book);//��ͼ�����Ͳ�����ȡ�Ľ�� ����
				while (rs.next())
					{Vector v=new Vector();
					v.add(rs.getString("b_id"));
					v.add(rs.getString("b_name"));
					v.add(rs.getString("b_author"));
					v.add(rs.getString("b_desc"));
					v.add(rs.getString("b_location"));
					v.add(rs.getString("b_typeName"));
				if ("0".equals(rs.getString("b_borrow"))) {
					v.add("�ڹ�");
					
				}else if ("1".equals(rs.getString("b_borrow"))) {
					v.add("�����");
				}
					dtm.addRow(v);}
			} 
		catch   (Exception e) {e.printStackTrace();}
		finally {try {dbUtil.closeCon(con);} 
				catch (Exception e){e.printStackTrace();}}
				
	} 
	

	/**
	 * �����¼����ʼ��
	 * @throws Exception 
	 */
	public void fillJSTable(Student student3) 
	{   JsRecord jsRecord1=new JsRecord();
		jsRecord1.setStuId(student3.getStuId());
		DefaultTableModel dtm=(DefaultTableModel) table.getModel();
		dtm.setRowCount(0);//�������
		Connection con = null;
		try {
				con=dbUtil.getCon();
				ResultSet rs= JsDao.list(con,jsRecord1);//��ͼ�����Ͳ�����ȡ�Ľ�� ����
				while (rs.next())
					{Vector v=new Vector();
					v.add(rs.getString("js_b_id"));
					v.add(rs.getString("js_b_name"));
					v.add(rs.getString("js_s_name"));
					v.add(rs.getString("js_sj"));
					dtm.addRow(v);
					}
		}catch   (Exception e) {e.printStackTrace();}
		finally {try {dbUtil.closeCon(con);} 
		catch (Exception e){e.printStackTrace();}}
	}	
	/**
	 * ˢ�±���
	 * @param e
	 */
	private void flashtable(ActionEvent e,Student student3) {
		table.removeAll();
		Booktable.removeAll();
		fillJSTable(student3);
		fillTable(new Book());
		s_bookTypeJcb.setSelectedIndex(0);
		
	}



	/**
	 * 
	 *	�����¼��������޸�ͼ����Ϣ����¼��Ϣ���޸�ѧ��������Ŀ
	 * 
	 * @param evt
	 * @param jsStudent
	 */

	private void returnbookActionPeform(ActionEvent evt, Student jsStudent) {
		
		Book book3=new Book();
		
		int row=this.table.getSelectedRow();
		if (row==-1) {
			JOptionPane.showMessageDialog(this, "��ѡ��Ҫ����ͼ��");
		}
		book3.setBookid((String) table.getValueAt(row, 0));
		book3.setBookborrow("0");
		//���������¼����
		JsRecord jsRecord2=new JsRecord();
		jsRecord2.setBookId((String) table.getValueAt(row, 0));
		jsRecord2.setStuId(jsStudent.getStuId());
		int jsNum=jsStudent.getStujNum();
		jsNum--;
		jsStudent.setStujNum(jsNum);
		
		/**
		 * ���ݿ����
		 */
        Connection con=null;
		try {
			con=dbUtil.getCon();
			BookDao bookDao=new BookDao();
			JsDao  jsDao=new JsDao();
			StudentDao studentDao=new StudentDao();
			int daoNum=bookDao.returnbook(con, book3);//����ͼ��� ���õ����շ���ֵ
			int jsdaoNum=jsDao.deletjsRecord(con, jsRecord2);//����������������ܷ���ֵ
			int studentjsNum=studentDao.Studentreturbook(con, jsStudent);//��ѧ��������Ŀ-1
			
			if (daoNum==1&&jsdaoNum==1&&studentjsNum==1) {
				JOptionPane.showMessageDialog(this, "����ɹ�");
				Booktable.removeAll();             //���ɹ����±���
				this.fillTable(new Book());
				lblNewLabel.setText("��ǰ����ͼ��"+jsStudent.getStujNum()+"��");
			      table.removeAll();             //���ɹ����±���
				this.fillJSTable(jsStudent);   //���뵱ǰ�û����������Ľ����¼��
				
			}
			
			
		} catch (Exception e) {
			JOptionPane.showMessageDialog(this, "��¼ʧ��");
			e.printStackTrace();
		}finally {
			try {
				dbUtil.closeCon(con);
			} catch (Exception e) {
				
				e.printStackTrace();
			}
		}
		
	
	
	
	}


	 private void jDGmethod(ActionEvent evt, Student jsStudent) {
		 
		 AtlerpasswJDG JDG =new AtlerpasswJDG (jsStudent);
		 JDG.setVisible(true);
	 }
}
 
	
	

