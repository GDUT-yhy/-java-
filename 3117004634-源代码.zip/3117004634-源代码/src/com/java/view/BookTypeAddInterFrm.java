package com.java.view;

import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.sql.Connection;

import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JInternalFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;

import com.java.dao.BookTypeDao;
import com.java.model.BookType;
import com.java.util.DbUtil;
import com.java.util.StringUtil;
import com.java.util.TxtUtil;

public class BookTypeAddInterFrm extends JInternalFrame {
	TxtUtil txtUtil=new TxtUtil();
	JTextArea bookTypeDescTxt = null;
	JTextField bookTypeNameTxt=null;
	JTextField bookTypeidTxt =null;
	private DbUtil dbUtil=new DbUtil();
	private BookTypeDao bookTypeDao=new BookTypeDao();
	
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					BookTypeAddInterFrm frame = new BookTypeAddInterFrm();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	
	
	/**
	 * Create the frame.
	 */
	
	public BookTypeAddInterFrm() {
		setResizable(true);
		setClosable(true);
		setIconifiable(true);
		setTitle("\u56FE\u4E66\u7C7B\u522B\u6DFB\u52A0");
		setBounds(100, 100, 502, 420);
		
		JLabel lblNewLabel = new JLabel("\u56FE\u4E66\u7C7B\u522B\u540D\u79F0\uFF1A");
		
		JLabel lblNewLabel_1 = new JLabel("\u56FE\u4E66\u7C7B\u522B\u63CF\u8FF0:");
		
		JLabel lblNewLabel_2 = new JLabel("\u56FE \u4E66 \u7C7B \u53F7 :");
		
		 bookTypeNameTxt = new JTextField();
		 bookTypeNameTxt.addKeyListener(new KeyAdapter() {
			  /**
			   	* �����ı�������ĳ��Ⱥ����ͺ�Ĭ����ʾ
			 *		
			 */
					public void keyTyped(KeyEvent e) {
						txtUtil.limtLong(e, bookTypeNameTxt);
						
					}
				});
		 bookTypeDescTxt = new JTextArea();
		 bookTypeDescTxt.addKeyListener(new KeyAdapter() {
			  /**
			   	* �����ı�������ĳ��Ⱥ����ͺ�Ĭ����ʾ
			 *		
			 */
					public void keyTyped(KeyEvent e) {
						txtUtil.limtLong100(e, bookTypeDescTxt);
						
					}
				});
		JLabel lblNewLabel_3 = new JLabel("");
		lblNewLabel_3.setIcon(new ImageIcon("C:\\Users\\14352\\Pictures\\logo-2.png"));
		
		 bookTypeidTxt = new JTextField();
		 bookTypeidTxt.addKeyListener(new KeyAdapter() {
			  /**
			   	* �����ı�������ĳ��Ⱥ����ͺ�Ĭ����ʾ
			 *		
			 */
					public void keyTyped(KeyEvent e) {
						txtUtil.limtLong(e, bookTypeidTxt);
						txtUtil.limtNum(e);
					}
				});
		JButton btnNewButton = new JButton("\u6DFB\u52A0");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				bookTypeAddActionpreformed(e);
			}
		});
		
			
		//���ð�ť
		
		JButton btnNewButton_1 = new JButton("\u91CD\u7F6E");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				resetValueActionPerform(e);
			}
		});
		
		
		GroupLayout groupLayout = new GroupLayout(getContentPane());
		groupLayout.setHorizontalGroup(
			groupLayout.createParallelGroup(Alignment.LEADING)
				.addGroup(groupLayout.createSequentialGroup()
					.addGroup(groupLayout.createParallelGroup(Alignment.LEADING)
						.addGroup(groupLayout.createSequentialGroup()
							.addGap(68)
							.addGroup(groupLayout.createParallelGroup(Alignment.LEADING)
								.addComponent(lblNewLabel)
								.addComponent(lblNewLabel_2)
								.addGroup(groupLayout.createParallelGroup(Alignment.TRAILING, false)
									.addGroup(Alignment.LEADING, groupLayout.createSequentialGroup()
										.addGap(16)
										.addComponent(btnNewButton, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
									.addComponent(lblNewLabel_1, Alignment.LEADING)))
							.addGap(18)
							.addGroup(groupLayout.createParallelGroup(Alignment.LEADING, false)
								.addComponent(bookTypeDescTxt)
								.addComponent(bookTypeNameTxt, GroupLayout.DEFAULT_SIZE, 184, Short.MAX_VALUE)
								.addComponent(bookTypeidTxt)))
						.addGroup(groupLayout.createSequentialGroup()
							.addContainerGap()
							.addComponent(lblNewLabel_3, GroupLayout.PREFERRED_SIZE, 338, GroupLayout.PREFERRED_SIZE))
						.addGroup(Alignment.TRAILING, groupLayout.createSequentialGroup()
							.addContainerGap()
							.addComponent(btnNewButton_1, GroupLayout.PREFERRED_SIZE, 84, GroupLayout.PREFERRED_SIZE)))
					.addContainerGap(104, Short.MAX_VALUE))
		);
		groupLayout.setVerticalGroup(
			groupLayout.createParallelGroup(Alignment.TRAILING)
				.addGroup(groupLayout.createSequentialGroup()
					.addContainerGap(GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
					.addComponent(lblNewLabel_3, GroupLayout.PREFERRED_SIZE, 75, GroupLayout.PREFERRED_SIZE)
					.addGap(28)
					.addGroup(groupLayout.createParallelGroup(Alignment.BASELINE)
						.addComponent(lblNewLabel_2)
						.addComponent(bookTypeidTxt, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
					.addGap(18)
					.addGroup(groupLayout.createParallelGroup(Alignment.BASELINE)
						.addComponent(lblNewLabel)
						.addComponent(bookTypeNameTxt, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
					.addGap(49)
					.addGroup(groupLayout.createParallelGroup(Alignment.BASELINE)
						.addComponent(lblNewLabel_1)
						.addComponent(bookTypeDescTxt, GroupLayout.PREFERRED_SIZE, 69, GroupLayout.PREFERRED_SIZE))
					.addGap(28)
					.addGroup(groupLayout.createParallelGroup(Alignment.BASELINE)
						.addComponent(btnNewButton_1)
						.addComponent(btnNewButton))
					.addGap(27))
		);
		getContentPane().setLayout(groupLayout);

	}
	
	
	private void bookTypeAddActionpreformed(ActionEvent evt) {
		String bookTypeName= this.bookTypeNameTxt.getText();
		String bookTypeDesc=this.bookTypeDescTxt.getText();
		String bookTypeid=this.bookTypeidTxt.getText();
		
		if (StringUtil.isEmpty(bookTypeName)||StringUtil.isEmpty(bookTypeid)){
			JOptionPane.showMessageDialog(null, "ͼ���������id����Ϊ��");
			return;
		}
		//����������������booktypeʵ��
		BookType bookType=new BookType(bookTypeid,bookTypeName,bookTypeDesc);
		
		
		Connection con=null;
		try {
			con=dbUtil.getCon();
			int n=bookTypeDao.add(con, bookType);
			if (n==1) {JOptionPane.showMessageDialog(null, "ͼ��������ӳɹ�"); resetValue();}
			else {JOptionPane.showMessageDialog(null, "ͼ���������ʧ��1");}
			}
		
		catch (Exception e) {JOptionPane.showMessageDialog(null, "����ʧ�ܣ���ȷ�ϱ���Ƿ�Ψһ");}
		finally 
				{try{dbUtil.closeCon(con);} 
				 catch (Exception e) {e.printStackTrace();}
				}
			
		
	}



	// ��д �����¼�����
	private void resetValueActionPerform(ActionEvent evt) {
		this.resetValue();
		}



	
	/**
	 * ��װһ�����÷��� ���ڱ��ʹ��
	 */
	private void resetValue() {
		
		this.bookTypeNameTxt.setText("");
		this.bookTypeDescTxt.setText("");
		this.bookTypeidTxt.setText("");
	}
	
}
