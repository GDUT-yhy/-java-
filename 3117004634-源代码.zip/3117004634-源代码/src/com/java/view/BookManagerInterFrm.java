package com.java.view;

import java.awt.EventQueue;

import javax.swing.JInternalFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.SystemColor;
import java.sql.Connection;
import java.sql.ResultSet;
import java.util.Vector;

import javax.swing.UIManager;
import javax.swing.ImageIcon;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

import com.java.dao.BookDao;
import com.java.dao.BookTypeDao;
import com.java.model.Book;
import com.java.model.BookType;
import com.java.model.Student;
import com.java.util.DbUtil;
import com.java.util.StringUtil;
import com.java.util.TxtUtil;

import javax.swing.border.LineBorder;
import javax.swing.border.TitledBorder;
import javax.swing.JPanel;
import javax.swing.LayoutStyle.ComponentPlacement;
import javax.swing.JTextField;
import javax.swing.JComboBox;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.ActionEvent;
import javax.swing.JRadioButton;
import javax.swing.ButtonGroup;
import javax.swing.JTextArea;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class BookManagerInterFrm extends JInternalFrame {
	TxtUtil txtUtil=new TxtUtil();
	private JTextField s_bookNametxt;
	private JTextField s_authortxt;
	private DbUtil dbUtil=new DbUtil();
	private BookTypeDao bookTypeDao=new BookTypeDao();
	private BookType bookType =new BookType();
	private JComboBox s_bookTypeJcb;
	private JTable Booktable;
	private JTextField up_bookidtxt;
	private JTextField up_booknametxt;
	private JTextField up_bookauthortxt;
	private JTextField up_booklocationtxt;
	private final ButtonGroup buttonGroup = new ButtonGroup();
	JTextArea up_bookDesc;
	JRadioButton Yes ;
	JRadioButton No;
	private JComboBox<BookType> up_booktypeJcb;
	JLabel lblNewLabel_11;
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					BookManagerInterFrm frame = new BookManagerInterFrm();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	
	

	/**
	 * Create the frame.
	 */
	public BookManagerInterFrm() {
		setBackground(UIManager.getColor("Button.light"));
		setTitle("\u56FE\u4E66\u7BA1\u7406");
		setClosable(true);
		setIconifiable(true);
		setBounds(100, 100, 912, 763);
		
		JLabel lblNewLabel = new JLabel("");
		lblNewLabel.setIcon(new ImageIcon("C:\\Users\\14352\\Pictures\\logo-2.png"));
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setViewportBorder(new LineBorder(Color.YELLOW));
		scrollPane.setToolTipText("");
		
		JPanel panel = new JPanel();
		panel.setBorder(new TitledBorder(null, "\u641C\u7D22\u6761\u4EF6", TitledBorder.LEADING, TitledBorder.TOP, null, null));
		
		JPanel panel_1 = new JPanel();
		panel_1.setBorder(new TitledBorder(null, "\u56FE\u4E66\u64CD\u4F5C", TitledBorder.LEADING, TitledBorder.TOP, null, null));
		
		JButton btnNewButton_4 = new JButton("");
		
		btnNewButton_4.setBorder(null);
		btnNewButton_4.setIcon(new ImageIcon("C:\\Users\\14352\\Desktop\\\u8BFE\u8BBE\u5B66\u4E60\\\u56FE\u6807\\refresh_reload_repeat_rotate_sync_16px_1225490_easyicon.net.png"));
		btnNewButton_4.setContentAreaFilled(false);
		btnNewButton_4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				flashtable(e);
				
			}
		});
		
		 lblNewLabel_11 = new JLabel("\u5171\u8BA1\u56FE\u4E66 \u672C");
		
		lblNewLabel_11.setText("");
	
		GroupLayout groupLayout = new GroupLayout(getContentPane());
		groupLayout.setHorizontalGroup(
			groupLayout.createParallelGroup(Alignment.TRAILING)
				.addGroup(groupLayout.createSequentialGroup()
					.addComponent(lblNewLabel, GroupLayout.PREFERRED_SIZE, 595, GroupLayout.PREFERRED_SIZE)
					.addGap(110))
				.addGroup(groupLayout.createSequentialGroup()
					.addContainerGap()
					.addComponent(panel, GroupLayout.DEFAULT_SIZE, 868, Short.MAX_VALUE)
					.addContainerGap())
				.addGroup(groupLayout.createSequentialGroup()
					.addContainerGap()
					.addComponent(panel_1, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
					.addGap(23))
				.addGroup(groupLayout.createSequentialGroup()
					.addContainerGap()
					.addGroup(groupLayout.createParallelGroup(Alignment.TRAILING)
						.addGroup(groupLayout.createSequentialGroup()
							.addComponent(lblNewLabel_11)
							.addPreferredGap(ComponentPlacement.RELATED, 770, Short.MAX_VALUE)
							.addComponent(btnNewButton_4))
						.addComponent(scrollPane, GroupLayout.DEFAULT_SIZE, 859, Short.MAX_VALUE))
					.addGap(23))
		);
		groupLayout.setVerticalGroup(
			groupLayout.createParallelGroup(Alignment.LEADING)
				.addGroup(groupLayout.createSequentialGroup()
					.addComponent(lblNewLabel)
					.addGap(18)
					.addComponent(panel, GroupLayout.PREFERRED_SIZE, 73, GroupLayout.PREFERRED_SIZE)
					.addPreferredGap(ComponentPlacement.RELATED)
					.addGroup(groupLayout.createParallelGroup(Alignment.TRAILING)
						.addComponent(btnNewButton_4)
						.addComponent(lblNewLabel_11))
					.addPreferredGap(ComponentPlacement.RELATED)
					.addComponent(scrollPane, GroupLayout.DEFAULT_SIZE, 254, Short.MAX_VALUE)
					.addGap(18)
					.addComponent(panel_1, GroupLayout.PREFERRED_SIZE, 229, GroupLayout.PREFERRED_SIZE)
					.addGap(34))
		);
		
		JLabel lblNewLabel_4 = new JLabel("\u7F16  \u53F7\uFF1A");
		
		up_bookidtxt = new JTextField();
		up_bookidtxt.addKeyListener(new KeyAdapter() {
			  /**
			   	* �����ı�������ĳ��Ⱥ����ͺ�Ĭ����ʾ
			 *		
			 */
					public void keyTyped(KeyEvent e) {
						txtUtil.limtLong(e, up_bookidtxt);
						txtUtil.limtNum(e);
						
					}
				});
		up_bookidtxt.setColumns(10);
		
		JLabel lblNewLabel_5 = new JLabel("\u56FE\u4E66\u540D\u79F0\uFF1A");
		
		up_booknametxt = new JTextField();
		up_booknametxt.addKeyListener(new KeyAdapter() {
			  /**
			   	* �����ı�������ĳ��Ⱥ����ͺ�Ĭ����ʾ
			 *		
			 */
					public void keyTyped(KeyEvent e) {
						txtUtil.limtLong10(e, up_booknametxt);
						
					}
				});
		up_booknametxt.setColumns(10);
		
		JLabel lblNewLabel_6 = new JLabel("\u4F5C  \u8005\uFF1A");
		
		up_bookauthortxt = new JTextField();
		up_bookauthortxt.addKeyListener(new KeyAdapter() {
			  /**
			   	* �����ı�������ĳ��Ⱥ����ͺ�Ĭ����ʾ
			 *		
			 */
					public void keyTyped(KeyEvent e) {
						txtUtil.limtLong10(e, up_bookauthortxt);
						
					}
				});
		up_bookauthortxt.setColumns(10);
		
		JLabel lblNewLabel_7 = new JLabel("\u4F4D  \u7F6E\uFF1A");
		
		up_booklocationtxt = new JTextField();
		up_booklocationtxt.addKeyListener(new KeyAdapter() {
			  /**
			   	* �����ı�������ĳ��Ⱥ����ͺ�Ĭ����ʾ
			 *		
			 */
					public void keyTyped(KeyEvent e) {
						txtUtil.limtLong30(e, up_booklocationtxt);
						
					}
				});
		up_booklocationtxt.setColumns(10);
		
		JLabel lblNewLabel_8 = new JLabel("\u56FE\u4E66\u7C7B\u522B\uFF1A");
		
	     up_booktypeJcb = new JComboBox<BookType>();
		
		JLabel lblNewLabel_9 = new JLabel("\u662F\u5426\u5728\u9986\uFF1A");
		
		 Yes = new JRadioButton("\u662F");
		buttonGroup.add(Yes);
		Yes.setSelected(true);
		
		No = new JRadioButton("\u5426");
		buttonGroup.add(No);
		
		JLabel lblNewLabel_10 = new JLabel("\u56FE\u4E66\u63CF\u8FF0\uFF1A");
		
		 up_bookDesc = new JTextArea();
		 up_bookDesc.addKeyListener(new KeyAdapter() {
			  /**
			   	* �����ı�������ĳ��Ⱥ����ͺ�Ĭ����ʾ
			 *		
			 */
					public void keyTyped(KeyEvent e) {
						txtUtil.limtLong100(e, up_bookDesc);
						
					}
				});
		up_bookDesc.setToolTipText("");
		
		JButton btnNewButton_1 = new JButton("\u4FEE   \u6539");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent event) {
				bookUpDateActionPerformed(event);
			}
		});
		
		JButton btnNewButton_2 = new JButton("\u5220  \u9664");
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				bookDeletActionPerformed(e);
			}
		});
		GroupLayout gl_panel_1 = new GroupLayout(panel_1);
		gl_panel_1.setHorizontalGroup(
			gl_panel_1.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_panel_1.createSequentialGroup()
					.addContainerGap()
					.addGroup(gl_panel_1.createParallelGroup(Alignment.LEADING, false)
						.addGroup(gl_panel_1.createSequentialGroup()
							.addGroup(gl_panel_1.createParallelGroup(Alignment.LEADING)
								.addComponent(lblNewLabel_4)
								.addComponent(lblNewLabel_8))
							.addPreferredGap(ComponentPlacement.RELATED)
							.addGroup(gl_panel_1.createParallelGroup(Alignment.LEADING, false)
								.addComponent(up_booktypeJcb, 0, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
								.addComponent(up_bookidtxt))
							.addGroup(gl_panel_1.createParallelGroup(Alignment.LEADING, false)
								.addGroup(gl_panel_1.createSequentialGroup()
									.addPreferredGap(ComponentPlacement.UNRELATED)
									.addComponent(lblNewLabel_9)
									.addPreferredGap(ComponentPlacement.UNRELATED)
									.addComponent(Yes)
									.addPreferredGap(ComponentPlacement.RELATED)
									.addComponent(No))
								.addGroup(gl_panel_1.createSequentialGroup()
									.addGap(18)
									.addComponent(lblNewLabel_5)
									.addPreferredGap(ComponentPlacement.RELATED)
									.addComponent(up_booknametxt, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
									.addGap(40)
									.addComponent(lblNewLabel_6)
									.addPreferredGap(ComponentPlacement.RELATED)
									.addComponent(up_bookauthortxt, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
									.addGap(18)
									.addComponent(lblNewLabel_7)
									.addPreferredGap(ComponentPlacement.RELATED)
									.addComponent(up_booklocationtxt, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))))
						.addGroup(gl_panel_1.createSequentialGroup()
							.addComponent(lblNewLabel_10)
							.addGap(10)
							.addComponent(up_bookDesc))
						.addGroup(gl_panel_1.createSequentialGroup()
							.addComponent(btnNewButton_1)
							.addGap(34)
							.addComponent(btnNewButton_2)))
					.addContainerGap(117, Short.MAX_VALUE))
		);
		gl_panel_1.setVerticalGroup(
			gl_panel_1.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_panel_1.createSequentialGroup()
					.addContainerGap()
					.addGroup(gl_panel_1.createParallelGroup(Alignment.BASELINE)
						.addComponent(lblNewLabel_4)
						.addComponent(up_bookidtxt, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
						.addComponent(lblNewLabel_5)
						.addComponent(up_booknametxt, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
						.addComponent(lblNewLabel_6)
						.addComponent(up_bookauthortxt, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
						.addComponent(lblNewLabel_7)
						.addComponent(up_booklocationtxt, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
					.addGap(18)
					.addGroup(gl_panel_1.createParallelGroup(Alignment.BASELINE)
						.addComponent(lblNewLabel_8)
						.addComponent(up_booktypeJcb, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
						.addComponent(lblNewLabel_9)
						.addComponent(Yes)
						.addComponent(No))
					.addPreferredGap(ComponentPlacement.RELATED)
					.addGroup(gl_panel_1.createParallelGroup(Alignment.BASELINE)
						.addComponent(lblNewLabel_10)
						.addComponent(up_bookDesc, GroupLayout.PREFERRED_SIZE, 55, GroupLayout.PREFERRED_SIZE))
					.addPreferredGap(ComponentPlacement.RELATED, 20, Short.MAX_VALUE)
					.addGroup(gl_panel_1.createParallelGroup(Alignment.BASELINE)
						.addComponent(btnNewButton_1)
						.addComponent(btnNewButton_2))
					.addContainerGap())
		);
		panel_1.setLayout(gl_panel_1);
		/**
		 * �������¼�
		 */
		Booktable = new JTable();
		Booktable.getTableHeader().setReorderingAllowed(false);
		Booktable.addMouseListener(new MouseAdapter() {
			@Override
			public void mousePressed(MouseEvent met) {
				bookTableMousePressd(met);
				
				
			}
		});
		Booktable.setModel(new DefaultTableModel(
			new Object[][] {
			},
			new String[] {
				"\u56FE\u4E66\u7F16\u53F7", "\u56FE\u4E66\u540D\u79F0", "\u4F5C\u8005", "\u56FE\u4E66\u7B80\u4ECB", "\u56FE\u4E66\u4F4D\u7F6E", "\u56FE\u4E66\u7C7B\u522B", "\u662F\u5426\u5728\u9986"
			}
		) {
			boolean[] columnEditables = new boolean[] {
				false, false, false, false, false, false, false
			};
			public boolean isCellEditable(int row, int column) {
				return columnEditables[column];
			}
		});
		Booktable.getColumnModel().getColumn(6).setResizable(false);
		scrollPane.setViewportView(Booktable);
		
		JLabel lblNewLabel_1 = new JLabel("\u56FE\u4E66\u540D\u79F0\uFF1A");
		
		s_bookNametxt = new JTextField();
		s_bookNametxt.addKeyListener(new KeyAdapter() {
			  /**
			   	* �����ı�������ĳ��Ⱥ����ͺ�Ĭ����ʾ
			 *		
			 */
					public void keyTyped(KeyEvent e) {
						txtUtil.limtLong30(e, s_bookNametxt);
						
					}
				});
		s_bookNametxt.setColumns(10);
		
		JLabel lblNewLabel_2 = new JLabel("\u4F5C  \u8005\uFF1A");
		
		s_authortxt = new JTextField();
		s_authortxt.addKeyListener(new KeyAdapter() {
			  /**
			   	* �����ı�������ĳ��Ⱥ����ͺ�Ĭ����ʾ
			 *		
			 */
					public void keyTyped(KeyEvent e) {
						txtUtil.limtLong20(e, s_authortxt);
						
					}
				});
		s_authortxt.setColumns(10);
		
		 s_bookTypeJcb = new JComboBox();
		
		JLabel lblNewLabel_3 = new JLabel("\u56FE\u4E66\u7C7B\u522B\uFF1A");
		
		JButton btnNewButton = new JButton("\u67E5   \u8BE2");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				bookSearchActinonPerformed(e);
			}
		});
		GroupLayout gl_panel = new GroupLayout(panel);
		gl_panel.setHorizontalGroup(
			gl_panel.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_panel.createSequentialGroup()
					.addContainerGap()
					.addComponent(lblNewLabel_1)
					.addPreferredGap(ComponentPlacement.RELATED)
					.addComponent(s_bookNametxt, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
					.addGap(18)
					.addComponent(lblNewLabel_2)
					.addGap(18)
					.addComponent(s_authortxt, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
					.addPreferredGap(ComponentPlacement.UNRELATED)
					.addComponent(lblNewLabel_3)
					.addGap(18)
					.addComponent(s_bookTypeJcb, GroupLayout.PREFERRED_SIZE, 128, GroupLayout.PREFERRED_SIZE)
					.addPreferredGap(ComponentPlacement.RELATED, 56, Short.MAX_VALUE)
					.addComponent(btnNewButton, GroupLayout.PREFERRED_SIZE, 119, GroupLayout.PREFERRED_SIZE)
					.addGap(31))
		);
		gl_panel.setVerticalGroup(
			gl_panel.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_panel.createSequentialGroup()
					.addGroup(gl_panel.createParallelGroup(Alignment.BASELINE)
						.addComponent(lblNewLabel_1)
						.addComponent(s_bookNametxt, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
						.addComponent(lblNewLabel_2)
						.addComponent(s_authortxt, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
						.addComponent(lblNewLabel_3)
						.addComponent(s_bookTypeJcb, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
						.addComponent(btnNewButton))
					.addContainerGap(22, Short.MAX_VALUE))
		);
		
		panel.setLayout(gl_panel);
		getContentPane().setLayout(groupLayout);
		fillBookType("search");
		fillTable(new Book());
		fillBookType("modify");
        int borrownum=countborrowednum();
		lblNewLabel_11.setText("����ͼ��"+Booktable.getRowCount()+"��"+"    �ڹ�ͼ�鹲��"+borrownum+"��"+"    ���ͼ�鹲��"+(Booktable.getRowCount()-borrownum)+"��");
	}
	
	private int countborrowednum() {
		int num=Booktable.getRowCount();
		int i = 0;int n=0;
		for (; n < num; n++) {
			
			if (Booktable.getValueAt(n,6).equals("�ڹ�")) {
				i++;
			}
			
		}
	  return i;
	}
	/**
	 * ͼ��ɾ������
	 * 
	 * @param e
	 */
	protected void bookDeletActionPerformed(ActionEvent evt) 
	{
		
		int row=Booktable.getSelectedRow();
		String id=(String) Booktable.getValueAt(row, 0);
		String id2=up_bookidtxt.getText();
		Connection con=null;
		try {
				con=dbUtil.getCon();
				if (StringUtil.isEmpty(id)||StringUtil.isEmpty(id2))
				{JOptionPane.showMessageDialog(this, "��ѡ��Ҫɾ��������");	}
				else 
				{int m=JOptionPane.showConfirmDialog(this, "ȷ��ɾ����");
				  if (m==0) {   int n=BookDao.delete(con, id);
								if (n==1){JOptionPane.showMessageDialog(this, "ɾ���ɹ�!");
											fillTable(new Book()); 
											ResetValue(evt); 
											int borrownum=countborrowednum();
											lblNewLabel_11.setText("����ͼ��"+Booktable.getRowCount()+"��"+"    �ڹ�ͼ�鹲��"+borrownum+"��"+"    ���ͼ�鹲��"+(Booktable.getRowCount()-borrownum)+"��");
											}
								else {JOptionPane.showMessageDialog(this, "ɾ��ʧ��!");}
								}
		        }
				}
	
	catch (Exception e) {e.printStackTrace();}
	finally {try {dbUtil.closeCon(con);} 
			 catch (Exception e) {e.printStackTrace();}
		     }
				
							
	}

	/***
	 * �޸��¼�����
	 * 
	 * @param event
	 */
	protected void bookUpDateActionPerformed(ActionEvent event) {
		/**
		 * ��ȡ�������Ϣ
		 */
		String id =this.up_bookidtxt.getText();
		if (StringUtil.isEmpty(id)) {
			JOptionPane.showMessageDialog(this, "������ͼ����");
			return;}
		String name=this.up_booknametxt.getText();
		String author=this.up_bookauthortxt.getText();
		String location =this.up_booklocationtxt.getText();
		String typename=this.up_booktypeJcb.getSelectedItem().toString();
		String borrow="";
		
	   
	    /**
	              * ��ʾ����Ϊ��
	     */
		if (StringUtil.isEmpty(id))  {JOptionPane.showMessageDialog(this, "ͼ���Ų���Ϊ��");}
		if (StringUtil.isEmpty(name))  {JOptionPane.showMessageDialog(this, "ͼ�����Ʋ���Ϊ��");}
		if (StringUtil.isEmpty(location))  {JOptionPane.showMessageDialog(this, "ͼ��λ�ò���Ϊ��");}
       
        
        if (Yes.isSelected()) {borrow="0";}
        if (No.isSelected()) {borrow="1";}
        BookType bookType=(BookType)up_booktypeJcb.getSelectedItem();
        String booktypeName=bookType.getBookTypeName();
        String  booktypeid=bookType.getId();
	    String bookdesc=this.up_bookDesc.getText();
        
        Book book=new Book(id, name,  author,  booktypeid, location,borrow,booktypeName,bookdesc);//����Ϣ��װ������
		/**
		 * ���ݿ����
		 */
        Connection con=null;
		try {
			con=dbUtil.getCon();
			BookDao bookDao=new BookDao();
			int dao=bookDao.update(con, book);//�������ݿ� ���õ����շ���ֵ
			if (dao==1) {
				JOptionPane.showMessageDialog(this, "�޸ĳɹ�");
				ResetValue(event);             //���ɹ����ñ���
				this.fillTable(new Book());
				int borrownum=countborrowednum();
				lblNewLabel_11.setText("����ͼ��"+Booktable.getRowCount()+"��"+"    �ڹ�ͼ�鹲��"+borrownum+"��"+"    ���ͼ�鹲��"+(Booktable.getRowCount()-borrownum)+"��");
				
			}else {
				JOptionPane.showMessageDialog(this, "�޸�ʧ��");
			}
		} catch (Exception e) {
			JOptionPane.showMessageDialog(this, "�޸�ʧ��");
			e.printStackTrace();
		}finally {
			try {
				dbUtil.closeCon(con);
			} catch (Exception e) {
				
				e.printStackTrace();
			}
		}
		
	}

	/**
	 * ������¼�����
	 * @param met
	 */
	private void bookTableMousePressd(MouseEvent met)
	{
		int row=this.Booktable.getSelectedRow();
		this.up_bookidtxt.setText((String)Booktable.getValueAt(row, 0));
		this.up_booknametxt.setText((String)Booktable.getValueAt(row, 1));
		this.up_bookauthortxt.setText((String)Booktable.getValueAt(row,2 ));
		this.up_bookDesc.setText((String)Booktable.getValueAt(row, 3));
		this.up_booklocationtxt.setText((String)Booktable.getValueAt(row, 4));
		String borrow=(String) Booktable.getValueAt(row,6 );
		/**
		 * �жϱ��ϵ������Զ�ѡ���Ƿ��ڹ�
		 */
		if ("�ڹ�".equals(borrow)) {
			this.Yes.setSelected(true);
		}else if("�����".equals(borrow)) {
			this.No.setSelected(true);
		}
		/**
		 *���������� ֱ���鵽����һ���������� 
		 */
	  String booktypename= (String)this.Booktable.getValueAt(row, 5);
	  
	    int n=this.up_booktypeJcb.getItemCount();
	    
	    
	  for(int i=0;i<n;i++) {
		  BookType item=(BookType)this.up_booktypeJcb.getItemAt(i);
		
		  if (item.getBookTypeName().equals(booktypename)) {
			 
			this.up_booktypeJcb.setSelectedIndex(i);
		}
		  
	  }
		
		
	}

	/**
	 * ͼ���ѯ�¼�����
	 * @param e
	 */
	protected void bookSearchActinonPerformed(ActionEvent evt) {
		String bookName=this.s_bookNametxt.getText();
		String author=this.s_authortxt.getText();
		BookType bookType=(BookType)this.s_bookTypeJcb.getSelectedItem();
		String  booktypeId=bookType.getId();
		Book book=new Book(bookName,author,booktypeId);
		this.fillTable(book);
		
		
		
	}

	
	/**
	 * ��ʼ�������� 
	 * @param type
	 */
	private void fillBookType(String type) {
		Connection con=null;
		try {
				con=dbUtil.getCon();
				BookType bookType=null;
				ResultSet rs= bookTypeDao.List(con, new BookType());
				
				if ("search".equals(type)) {
					bookType=new BookType();
					
					bookType.setBookTypeName("��ѡ��...");
					bookType.setId("-1");
					this.s_bookTypeJcb.addItem(bookType);
					
				}
				
				while (rs.next())
				{
					bookType=new BookType();
					bookType.setBookTypeName(rs.getString("bookTypeName"));
					bookType.setId(rs.getString("t_bookid"));
					if ("search".equals(type)) {
						
						this.s_bookTypeJcb.addItem(bookType);
						
					}else if ("modify".equals(type)) {
						this.up_booktypeJcb.addItem(bookType);
						//equals�������ж�ֵ�Ƿ���ȵ�
					}
				
				}
			
		} catch (Exception e) {e.printStackTrace();}finally 
		{
			try {dbUtil.closeCon(con);}
			catch (Exception e) {e.printStackTrace();}
		}
	}
	
	
	/**
	 * �����ʼ��
	 * @param book
	 */
	
	public void fillTable(Book book) 
	{

		DefaultTableModel dtm=(DefaultTableModel) Booktable.getModel();
		dtm.setRowCount(0);//�������
		Connection con = null;
		try {
				con=dbUtil.getCon();
				ResultSet rs= BookDao.list(con,book);//��ͼ�����Ͳ�����ȡ�Ľ�� ����
				while (rs.next())
					{Vector v=new Vector();
					v.add(rs.getString("b_id"));
					v.add(rs.getString("b_name"));
					v.add(rs.getString("b_author"));
					v.add(rs.getString("b_desc"));
					v.add(rs.getString("b_location"));
					v.add(rs.getString("b_typeName"));
				if ("0".equals(rs.getString("b_borrow"))) {
					v.add("�ڹ�");
					
				}else if ("1".equals(rs.getString("b_borrow"))) {
					v.add("�����");
				}
					dtm.addRow(v);}
			} 
		catch   (Exception e) {e.printStackTrace();}
		finally {try {dbUtil.closeCon(con);} 
				catch (Exception e){e.printStackTrace();}
				}
			}
/**
 * ��ձ���	
 * @param e
 */
	private void ResetValue(ActionEvent e) {
        this.up_bookauthortxt.setText("");
        this.up_bookDesc.setText("");
        this.up_bookidtxt.setText("");
        this.up_booknametxt.setText("");
         this.up_booklocationtxt.setText("");
         if (up_booktypeJcb.getItemCount()>0) {
        	 this.up_booktypeJcb.setSelectedIndex(0);
		 }
         Yes.isSelected();
         
         
         
}
	private void flashtable(ActionEvent e) {
		Booktable.removeAll();
		fillTable(new Book());
		  int borrownum=countborrowednum();
			lblNewLabel_11.setText("����ͼ��"+Booktable.getRowCount()+"��"+"    �ڹ�ͼ�鹲��"+borrownum+"��"+"    ���ͼ�鹲��"+(Booktable.getRowCount()-borrownum)+"��");
		
	}
}

