package com.java.view;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.SQLException;

import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.LayoutStyle.ComponentPlacement;
import javax.swing.border.EmptyBorder;

import com.java.dao.StudentDao;
import com.java.model.Student;
import com.java.util.DbUtil;
import com.java.util.StringUtil;


public class AtlerpasswJDG extends JDialog {

	private final JPanel contentPanel = new JPanel();
	private JPasswordField oldpasswordtxt;
	private JPasswordField newpassword1;
	private JPasswordField newpassword2;
	static Student student;
	DbUtil dbUtil=new DbUtil();
	StudentDao studentDao=new StudentDao();
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		try {
			AtlerpasswJDG dialog = new AtlerpasswJDG(student);
			dialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
			dialog.setVisible(true);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Create the dialog.
	 */
	public AtlerpasswJDG(Student mimaStu) {
		setBounds(100, 100, 560, 426);
		getContentPane().setLayout(new BorderLayout());
		contentPanel.setBorder(new EmptyBorder(5, 5, 5, 5));
		getContentPane().add(contentPanel, BorderLayout.CENTER);
		
		JLabel lblNewLabel = new JLabel("\u4FEE\u6539\u5B66\u751F\u5BC6\u7801");
		lblNewLabel.setFont(new Font("΢���ź� Light", Font.BOLD, 25));
		lblNewLabel.setIcon(new ImageIcon("C:\\Users\\14352\\Pictures\\logo-2.png"));
		
		JLabel lblNewLabel_1 = new JLabel("\u8BF7\u8F93\u5165\u65E7\u5BC6\u7801\uFF1A");
		
		JLabel lblNewLabel_2 = new JLabel("\u8BF7\u8F93\u5165\u65B0\u5BC6\u7801\uFF1A");
		
		JLabel lblNewLabel_3 = new JLabel("\u786E\u8BA4\u65B0\u5BC6\u7801 \uFF1A");
		
		oldpasswordtxt = new JPasswordField();
		
		newpassword1 = new JPasswordField();
		
		newpassword2 = new JPasswordField();
		GroupLayout gl_contentPanel = new GroupLayout(contentPanel);
		gl_contentPanel.setHorizontalGroup(
			gl_contentPanel.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_contentPanel.createSequentialGroup()
					.addGroup(gl_contentPanel.createParallelGroup(Alignment.LEADING)
						.addComponent(lblNewLabel)
						.addGroup(gl_contentPanel.createSequentialGroup()
							.addGap(31)
							.addGroup(gl_contentPanel.createParallelGroup(Alignment.LEADING, false)
								.addGroup(gl_contentPanel.createSequentialGroup()
									.addComponent(lblNewLabel_1)
									.addPreferredGap(ComponentPlacement.RELATED)
									.addComponent(oldpasswordtxt, GroupLayout.PREFERRED_SIZE, 212, GroupLayout.PREFERRED_SIZE))
								.addGroup(gl_contentPanel.createSequentialGroup()
									.addGroup(gl_contentPanel.createParallelGroup(Alignment.LEADING)
										.addComponent(lblNewLabel_2)
										.addComponent(lblNewLabel_3))
									.addPreferredGap(ComponentPlacement.RELATED)
									.addGroup(gl_contentPanel.createParallelGroup(Alignment.LEADING)
										.addComponent(newpassword2, GroupLayout.DEFAULT_SIZE, 212, Short.MAX_VALUE)
										.addComponent(newpassword1))))))
					.addGap(79))
		);
		gl_contentPanel.setVerticalGroup(
			gl_contentPanel.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_contentPanel.createSequentialGroup()
					.addComponent(lblNewLabel)
					.addGap(26)
					.addGroup(gl_contentPanel.createParallelGroup(Alignment.BASELINE)
						.addComponent(lblNewLabel_1)
						.addComponent(oldpasswordtxt, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
					.addGap(30)
					.addGroup(gl_contentPanel.createParallelGroup(Alignment.BASELINE)
						.addComponent(lblNewLabel_2)
						.addComponent(newpassword1, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
					.addGap(31)
					.addGroup(gl_contentPanel.createParallelGroup(Alignment.BASELINE)
						.addComponent(lblNewLabel_3)
						.addComponent(newpassword2, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
					.addContainerGap(109, Short.MAX_VALUE))
		);
		contentPanel.setLayout(gl_contentPanel);
		{
			JPanel buttonPane = new JPanel();
			buttonPane.setLayout(new FlowLayout(FlowLayout.RIGHT));
			getContentPane().add(buttonPane, BorderLayout.SOUTH);
			{
				JButton okButton = new JButton("\u786E  \u8BA4");
				okButton.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						atlerpasswordAction(mimaStu);
					}
				});;
				okButton.setActionCommand("OK");
				buttonPane.add(okButton);
				getRootPane().setDefaultButton(okButton);
			}
			{
				JButton cancelButton = new JButton("\u53D6  \u6D88");
				cancelButton.setActionCommand("Cancel");
				buttonPane.add(cancelButton);
			}
		}
	}

private void atlerpasswordAction(Student mimaStudent) {
		String userid=mimaStudent.getStuId();
		String oldpassword=new String(this.oldpasswordtxt.getPassword());
		String newpassword1=new String(this.newpassword1.getPassword());
		String newpassword2=new String(this.newpassword2.getPassword());
		if (StringUtil.isEmpty(oldpassword)) {
			JOptionPane.showMessageDialog(null, "�����벻��Ϊ��");
			return;
		}
		if (StringUtil.isEmpty(newpassword1)) {
			JOptionPane.showMessageDialog(null, "�����벻��Ϊ��");
			return;
		}
		if (StringUtil.isEmpty(newpassword2)) {
			JOptionPane.showMessageDialog(null, "��ȷ�����룡");
			return;
		}
		if (newpassword1.equals(newpassword2)==false) {
			JOptionPane.showMessageDialog(null, "�������벻һ�£����������룡");
			resetvalue();
			return;
		}
		
		Student trystudent = new Student(userid,oldpassword);//          ����������û��������룬ʵ��һ��user
		Student truthstudent=new Student(userid,newpassword1);
			Connection con =null;
			try {
				con=dbUtil.getCon();
				Student currentUser=StudentDao.login(con, trystudent);      //����������������Ӻ�user����ʽ����userDao���е�¼��֤ 
				if (currentUser!=null) {
					 int n= studentDao.updatePassword(con, truthstudent);  
					if (n==1) {
						JOptionPane.showMessageDialog(null, "�޸ĳɹ���");
					}
					
					
					
				}else {
					JOptionPane.showMessageDialog(null, "�û������������");
				}}
			catch (Exception e1) {
				// TODO �Զ����ɵ� catch ��
				e1.printStackTrace();
			}finally {
				try {
					dbUtil.closeCon(con);
				} catch (Exception e) {
					// TODO �Զ����ɵ� catch ��
					e.printStackTrace();
				}
			}
	
	}
		
		
		
		
		
		
	/**	
	 * ����
	 */
private void resetvalue() {
	this.newpassword1.setText("");
	this.newpassword2.setText("");
	
}









}
