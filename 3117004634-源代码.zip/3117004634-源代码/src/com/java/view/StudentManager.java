package com.java.view;

import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.Connection;
import java.sql.ResultSet;
import java.util.Vector;

import javax.swing.ButtonGroup;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JInternalFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.LayoutStyle.ComponentPlacement;
import javax.swing.border.TitledBorder;
import javax.swing.table.DefaultTableModel;

import com.java.dao.BookDao;
import com.java.dao.JsDao;
import com.java.dao.StudentDao;
import com.java.model.Book;
import com.java.model.JsRecord;
import com.java.model.Student;
import com.java.util.DbUtil;
import com.java.util.JTextFieldHintListener;
import com.java.util.TxtUtil;
import javax.swing.JPasswordField;

public class StudentManager extends JInternalFrame {
	private JTable table;
	private JTextField StudentIDtxt;
	private JTextField StudentNametxt;
	private JTextField StudentSpeciltxt;
	private final ButtonGroup buttonGroup = new ButtonGroup();
	private DbUtil dbUtil=new DbUtil();
	private StudentDao studentDao=new StudentDao(); 
	JRadioButton nan;
	JRadioButton nv;
	JComboBox JsNameJcb;
	JsRecord jsRecord=new JsRecord();
	 private JsDao jsDao=new JsDao();	
	 private TxtUtil txtUtil=new TxtUtil();
	
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					StudentManager frame = new StudentManager();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public StudentManager() {
		setClosable(true);
		setIconifiable(true);
		setBounds(100, 100, 755, 565);
		
		JLabel lblNewLabel = new JLabel("\u5B66\u751F\u7BA1\u7406\u7CFB\u7EDF");
		lblNewLabel.setFont(new Font("΢���ź� Light", Font.BOLD, 36));
		lblNewLabel.setIcon(new ImageIcon("C:\\Users\\14352\\Pictures\\logo-2.png"));
		
		JScrollPane scrollPane = new JScrollPane();
		
		JPanel panel = new JPanel();
		panel.setBorder(new TitledBorder(null, "\u64CD\u4F5C\u9762\u677F", TitledBorder.LEADING, TitledBorder.TOP, null, null));
		//ˢ�°�ť
		JButton btnNewButton_4 = new JButton("");
		btnNewButton_4.setBorder(null);
		btnNewButton_4.setIcon(new ImageIcon("C:\\Users\\14352\\Desktop\\\u8BFE\u8BBE\u5B66\u4E60\\\u56FE\u6807\\refresh_reload_repeat_rotate_sync_16px_1225490_easyicon.net.png"));
		btnNewButton_4.setContentAreaFilled(false);
		btnNewButton_4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				flashtable(e);
			}
		});
		GroupLayout groupLayout = new GroupLayout(getContentPane());
		groupLayout.setHorizontalGroup(
			groupLayout.createParallelGroup(Alignment.LEADING)
				.addGroup(groupLayout.createSequentialGroup()
					.addContainerGap()
					.addGroup(groupLayout.createParallelGroup(Alignment.LEADING)
						.addComponent(panel, Alignment.TRAILING, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
						.addComponent(scrollPane, GroupLayout.DEFAULT_SIZE, 711, Short.MAX_VALUE)
						.addGroup(groupLayout.createSequentialGroup()
							.addComponent(lblNewLabel)
							.addPreferredGap(ComponentPlacement.RELATED, 145, Short.MAX_VALUE)
							.addComponent(btnNewButton_4, GroupLayout.PREFERRED_SIZE, 41, GroupLayout.PREFERRED_SIZE)))
					.addContainerGap())
		);
		groupLayout.setVerticalGroup(
			groupLayout.createParallelGroup(Alignment.LEADING)
				.addGroup(groupLayout.createSequentialGroup()
					.addContainerGap()
					.addGroup(groupLayout.createParallelGroup(Alignment.TRAILING)
						.addComponent(lblNewLabel)
						.addComponent(btnNewButton_4))
					.addPreferredGap(ComponentPlacement.RELATED)
					.addComponent(scrollPane, GroupLayout.PREFERRED_SIZE, 207, GroupLayout.PREFERRED_SIZE)
					.addGap(33)
					.addComponent(panel, GroupLayout.PREFERRED_SIZE, 194, GroupLayout.PREFERRED_SIZE)
					.addContainerGap(GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
		);
		
		JLabel lblNewLabel_1 = new JLabel("\u5B66  \u53F7\uFF1A");
		
		
		//id �����
		StudentIDtxt = new JTextField();
		
		StudentIDtxt.addKeyListener(new KeyAdapter() {
	  /**
	   	* �����ı�������ĳ��Ⱥ����ͺ�Ĭ����ʾ
	 *		
	 */
			public void keyTyped(KeyEvent e) {
				txtUtil.limtLong(e, StudentIDtxt);
				txtUtil.limtNum(e);
			}
		});
		StudentIDtxt.setColumns(10);
	
		
		JLabel lblNewLabel_2 = new JLabel("\u59D3  \u540D\uFF1A");
		
		StudentNametxt = new JTextField();
		StudentNametxt.addKeyListener(new KeyAdapter() {
			  /**
			   	* �����ı�������ĳ��Ⱥ����ͺ�Ĭ����ʾ
			 *		
			 */
					public void keyTyped(KeyEvent e) {
						txtUtil.limtLong10(e, StudentNametxt);
						
					}
				});
		StudentNametxt.setColumns(10);
		
		JLabel lblNewLabel_3 = new JLabel("");
		
		StudentSpeciltxt = new JTextField();
		StudentSpeciltxt.addKeyListener(new KeyAdapter() {
			  /**
			   	* �����ı�������ĳ��Ⱥ����ͺ�Ĭ����ʾ
			 *		
			 */
					public void keyTyped(KeyEvent e) {
						txtUtil.limtLong20(e, StudentSpeciltxt);
						
					}
				});
		StudentSpeciltxt.setColumns(10);
		
		 nan = new JRadioButton("\u7537");
		buttonGroup.add(nan);
		nan.setSelected(true);
		
		 nv = new JRadioButton("\u5973");
		buttonGroup.add(nv);
		
		JLabel lblNewLabel_4 = new JLabel("\u4E13  \u4E1A\uFF1A");
		
		 JsNameJcb = new JComboBox();
		
		JLabel lblNewLabel_5 = new JLabel("\u5728\u501F\u4E66\u76EE\uFF1A");
		
		
		//���Ӱ�ť
		//����ѧ����ť
		JButton btnNewButton = new JButton("\u6DFB\u52A0\u5B66\u751F");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				AddstudentAction(e);
				
			}
		});
		//���°�ť
		JButton button = new JButton("\u4FEE\u6539\u57FA\u672C\u4FE1\u606F");
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				UpdateStuAction(e);
			}
		});
		//ɾ��ѧ��
		JButton btnNewButton_1 = new JButton("\u5220\u9664\u5B66\u751F");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				StudentDeletActionPeform(e);
				
			}
		});
		//ɾ��������¼��ť
		JButton btnNewButton_2 = new JButton("\u5220\u9664\u5728\u501F\u4E66\u76EE");
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				DeletBorrowBookActionEvent(e);
			}
		});
		//������ť
		JButton btnNewButton_3 = new JButton("\u67E5  \u8BE2");
		btnNewButton_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				searcStudentAction(e);
			}
		});
		GroupLayout gl_panel = new GroupLayout(panel);
		gl_panel.setHorizontalGroup(
			gl_panel.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_panel.createSequentialGroup()
					.addContainerGap()
					.addGroup(gl_panel.createParallelGroup(Alignment.TRAILING)
						.addComponent(lblNewLabel_3)
						.addGroup(gl_panel.createSequentialGroup()
							.addGroup(gl_panel.createParallelGroup(Alignment.TRAILING)
								.addGroup(gl_panel.createSequentialGroup()
									.addGroup(gl_panel.createParallelGroup(Alignment.LEADING)
										.addComponent(lblNewLabel_5)
										.addComponent(lblNewLabel_1))
									.addPreferredGap(ComponentPlacement.UNRELATED)
									.addGroup(gl_panel.createParallelGroup(Alignment.LEADING)
										.addGroup(gl_panel.createSequentialGroup()
											.addComponent(StudentIDtxt)
											.addGap(28)
											.addComponent(lblNewLabel_2)
											.addPreferredGap(ComponentPlacement.RELATED)
											.addComponent(StudentNametxt, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
											.addGap(18)
											.addComponent(nan)
											.addPreferredGap(ComponentPlacement.RELATED)
											.addComponent(nv)
											.addGap(18)
											.addComponent(lblNewLabel_4)
											.addGap(14))
										.addGroup(gl_panel.createSequentialGroup()
											.addComponent(JsNameJcb, GroupLayout.PREFERRED_SIZE, 202, GroupLayout.PREFERRED_SIZE)
											.addPreferredGap(ComponentPlacement.RELATED))))
								.addGroup(gl_panel.createSequentialGroup()
									.addComponent(btnNewButton_2)
									.addPreferredGap(ComponentPlacement.UNRELATED)
									.addComponent(btnNewButton_3)
									.addPreferredGap(ComponentPlacement.RELATED)
									.addComponent(btnNewButton)
									.addPreferredGap(ComponentPlacement.UNRELATED)
									.addComponent(button)
									.addPreferredGap(ComponentPlacement.RELATED)))
							.addGroup(gl_panel.createParallelGroup(Alignment.TRAILING, false)
								.addComponent(btnNewButton_1, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
								.addComponent(StudentSpeciltxt, Alignment.LEADING, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))))
					.addGap(39))
		);
		gl_panel.setVerticalGroup(
			gl_panel.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_panel.createSequentialGroup()
					.addContainerGap()
					.addGroup(gl_panel.createParallelGroup(Alignment.BASELINE)
						.addComponent(lblNewLabel_2)
						.addComponent(StudentNametxt, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
						.addComponent(nan)
						.addComponent(nv)
						.addComponent(lblNewLabel_4)
						.addComponent(StudentSpeciltxt, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
						.addComponent(StudentIDtxt, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
						.addComponent(lblNewLabel_1))
					.addGap(18)
					.addComponent(lblNewLabel_3)
					.addPreferredGap(ComponentPlacement.RELATED)
					.addGroup(gl_panel.createParallelGroup(Alignment.BASELINE)
						.addComponent(JsNameJcb, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
						.addComponent(lblNewLabel_5))
					.addGap(18)
					.addGroup(gl_panel.createParallelGroup(Alignment.BASELINE)
						.addComponent(btnNewButton_1)
						.addComponent(button)
						.addComponent(btnNewButton)
						.addComponent(btnNewButton_3)
						.addComponent(btnNewButton_2))
					.addContainerGap(34, Short.MAX_VALUE))
		);
		panel.setLayout(gl_panel);
		
		table = new JTable();
		table.addMouseListener(new MouseAdapter() {
			@Override
			public void mousePressed(MouseEvent e) {
				mousePressedAction(e);
			}
		});
		table.setModel(new DefaultTableModel(
			new Object[][] {
			},
			new String[] {
				"\u5B66\u53F7", "\u59D3\u540D", "\u6027\u522B", "\u4E13\u4E1A", "\u5F53\u524D\u501F\u9605\u6570\u76EE"
			}
		) {
			boolean[] columnEditables = new boolean[] {
				false, false, false, false, false
			};
			public boolean isCellEditable(int row, int column) {
				return columnEditables[column];
			}
		});
		table.getColumnModel().getColumn(4).setPreferredWidth(164);
		scrollPane.setViewportView(table);
		getContentPane().setLayout(groupLayout);
		fillStuTable(new Student());
	}
	/**
	 * ˢ�±���
	 * @param e
	 */
	private void flashtable(ActionEvent e) {
		table.removeAll();
		fillStuTable(new Student());
		
	}

	/**
	 * ɾ�������¼
	 * @param evt
	 */
	private void DeletBorrowBookActionEvent(ActionEvent evt) {
		 JsRecord getjs=(JsRecord) this.JsNameJcb.getSelectedItem();//��ȡѡ�еĽ����¼ʵ��
		 int row=this.table.getSelectedRow();
		 Connection con=null;
		 try {
						con=dbUtil.getCon();
						JsDao jsDao=new JsDao();
						int m=JOptionPane.showConfirmDialog(this, "ȷ��ɾ�������¼:"+getjs.getStuName()+":"+getjs.getBookName()+"?");
						if (m==0)
						{int n=jsDao.deletjsRecord(con, getjs);
						if (n==1) 
						{	JOptionPane.showMessageDialog(this, "ɾ���ɹ�!");
							
							this.JsNameJcb.removeAllItems();//�ÿ������� ��ֹ��������ʱ������
							filljsJcb(row);}
						else{JOptionPane.showMessageDialog(this, "ɾ��ʧ��!");}}}
					
		 catch (Exception e) {
						JOptionPane.showMessageDialog(this, "ɾ��ʧ��!");
						e.printStackTrace();}
		 finally {
						try {dbUtil.closeCon(con);} 
						catch (Exception e) {e.printStackTrace();}}
			
			
			
		
		
	}

	/**
	 * ��ѯѧ��
	 * @param e
	 */
	protected void searcStudentAction(ActionEvent evt) {
		
		String id=this.StudentIDtxt.getText();
		String name=this.StudentNametxt.getText();
		String specil=this.StudentSpeciltxt.getText();
		String Sex="0";//Ĭ��Ϊ��
		if (nv.isSelected()){Sex="1";}//ѡŮ��Ů
		Student student=new Student( name, specil,Sex, id);
		this.fillStuTable(student);
		
	}

	
	/**
	 * ���»�����Ϣ����
	 * @param e
	 */
	private void UpdateStuAction(ActionEvent evt)
	{
		Connection con=null;
		String id=this.StudentIDtxt.getText();
		String name=this.StudentNametxt.getText();
		String specil=this.StudentSpeciltxt.getText();
		String Sex="0";//Ĭ��Ϊ��
		if (nv.isSelected()){Sex="1";}//ѡŮ��Ů
		Student student=new Student( name, specil,Sex, id);
		try 
			{
					con=dbUtil.getCon();
					int n=studentDao.updateStudent(con, student);
					if (n==1)
					 {	JOptionPane.showMessageDialog(this, "���³ɹ�!"+name+"("+id+")"+specil);
						fillStuTable(new Student()); 
						resetValue(); }
					else {JOptionPane.showMessageDialog(this, "����ʧ��!");}
			}  
		
	 catch (Exception e) 
				{JOptionPane.showMessageDialog(this, "����ʧ��!");
				e.printStackTrace();}
	finally {try {dbUtil.closeCon(con);} 
			 catch (Exception e) {e.printStackTrace();}
		    }
	}
	
		

	/**
	 * ɾ��ѧ���¼�(ע����ʾ���ڽ�ͼ��)
	 * @param e
	 */
	private void StudentDeletActionPeform(ActionEvent evt) {
		Connection con=null;
		String name=this.StudentNametxt.getText();
		String id=this.StudentIDtxt.getText();	
		try 
		{
			con=dbUtil.getCon();
			if (this.JsNameJcb.getItemCount()!=0) {JOptionPane.showMessageDialog(this, "��ǰѧ����ͼ��δ����ɾ��ʧ�ܣ�");}
			else if (this.JsNameJcb.getItemCount()==0)
				{
				   int m=JOptionPane.showConfirmDialog(this, "ȷ��ɾ��"+name+"("+id+")?");
				
					if (m==0)
					{  
						int n=studentDao.deletStudent(con, id);
						if (n==1)
							 {	JOptionPane.showMessageDialog(this, "ɾ���ɹ�!");
								fillStuTable(new Student()); 
								resetValue(); }
						else {JOptionPane.showMessageDialog(this, "ɾ��ʧ��!");}
				
					}
				}
		}
				   catch (Exception e) {
			
			e.printStackTrace();
		}
		
		
	}

	
	/**
	 * ������������Ϊ�ı�
	 * @param e 
	 */
	private void limtNum(KeyEvent e) 
		{
		char keyCh = e.getKeyChar();
		if ((keyCh < '0') || (keyCh > '9')) {
			if (keyCh !='\r') // �س��ַ�
				e.setKeyChar('\0');}
		}


	
	
	/**
	 * ���ѡ���Զ�����ı���
	 * @param e
	 */
private  void mousePressedAction(MouseEvent e) {
	 	resetValue();
		int row=table.getSelectedRow();
		this.StudentIDtxt.setText((String) table.getValueAt(row, 0));
		this.StudentNametxt.setText((String) table.getValueAt(row, 1));
		this.StudentSpeciltxt.setText((String) table.getValueAt(row,3 ));
		if ( table.getValueAt(row,2).equals("��")) {this.nan.setSelected(true);}
		if ( table.getValueAt(row,2).equals("Ů")) {this.nv.setSelected(true);}
		filljsJcb(row);
	

}




/**
 * ����ѧ��  �����ж�ѧ���Ƿ�Ψһ
 * @param e 
 * @throws Exception
 */
	private void AddstudentAction(ActionEvent e){
		
		String id=this.StudentIDtxt.getText();
		String name=this.StudentNametxt.getText();
		String specil=this.StudentSpeciltxt.getText();
		String password =this.StudentIDtxt.getText();
		int  jNum=0;
		String Sex="0";//Ĭ��Ϊ��
		
		if (nv.isSelected()) {
			Sex="1";//ѡŮ��Ů
		}
		int exNum=orexitStuID(id);
		if (exNum==1) {
			JOptionPane.showMessageDialog(this, "ѧ���Ѵ��ڣ�����ѧ��");
			return;
		}
		if ("".equals(id)||"".equals(name)||"".equals(specil)) {
			JOptionPane.showMessageDialog(this, "ѧ�ţ�������רҵ������Ϊ��");
			return;
		}
		Student student=new Student(name, password, specil, Sex, jNum, id);
		
		Connection con=null;
		try {
			con=dbUtil.getCon();
		
			
			int n=studentDao.addStudent(con, student);
			if (n==1) {
				JOptionPane.showMessageDialog(this, "���ӳɹ���");
				fillStuTable(new Student());
			}else {
				JOptionPane.showMessageDialog(this, "����ʧ�ܣ�");
			}
		} catch (Exception e1) {
			JOptionPane.showMessageDialog(this, "����ʧ�ܣ�");
			e1.printStackTrace();
		}finally {
			try {
				dbUtil.closeCon(con);
			} catch (Exception e1) {
				
				e1.printStackTrace();
			}
		}
		
		
		
	
	}


	
	/**
 
* ��ʼ������
 * @param student
 */
    private void fillStuTable(Student student) {
    	DefaultTableModel dtm=(DefaultTableModel) table.getModel();
		dtm.setRowCount(0);//�������
    	
    	Connection con=null;
    	
    	try {
			con=dbUtil.getCon();
			ResultSet rs=studentDao.list(con, student);
			while (rs.next()) {
				Vector v=new Vector();
				v.add(rs.getString("s_id"));
				v.add(rs.getString("s_name"));
				if (rs.getString("s_sex").equals("0")) {v.add("��");}
				else if (rs.getString("s_sex").equals("1")){v.add("Ů");}	
				v.add(rs.getString("s_specil"));
				v.add(rs.getString("s_jnum"));
				
				dtm.addRow(v);
				
			}
		} catch (Exception e) {
			
			e.printStackTrace();
		}finally {
			try {
				dbUtil.closeCon(con);
			} catch (Exception e) {
				
				e.printStackTrace();
			}
		}
    	
    	
    	
    }
   
    /**
     * ��ʼ��������

     * @param jsRecord
     * ����������jsrecord��������װ���ݣ�jsrecord1��������ѡ���е�ѧ����ţ�
     *  jsrecord2��������������ѯ������Ϣ��װ�������ӵ���������
     */
    private void filljsJcb( int row) {
    	Connection con=null;
    	try {
			con=dbUtil.getCon();
			JsRecord jsRecord1=new JsRecord();
			JsRecord jsRecord2=null;
			jsRecord1.setStuId((String) table.getValueAt(row, 0));
		    ResultSet rs=jsDao.list(con, jsRecord1);
		    while (rs.next()) {
		    	jsRecord2=new JsRecord();
		    	jsRecord2.setStuId(rs.getString("js_s_id"));;
		        jsRecord2.setStuName(rs.getString("js_s_name"));
		       jsRecord2.setBookName(rs.getString("js_b_name"));
		    	jsRecord2.setBookId(rs.getString("js_b_id"));
		    	
		    	this.JsNameJcb.addItem(jsRecord2);
		    	
		    }		
		} catch (Exception e) {
			
			e.printStackTrace();
		}
    }
      
    /**
    
 * ���ò�����
     * 
     */
    private void resetValue() {
	this.StudentIDtxt.setText("");
	this.StudentNametxt.setText("");
    this.StudentSpeciltxt.setText("");
    nan.setSelected(true);
    this.JsNameJcb.removeAllItems();
    }
  
    
    
    /**
     * �ж�ѧ���Ƿ�Ψһ  �Ƿ���0  �񷵻�1
     */
    private int orexitStuID(String newid) {
    	String oldid;
    	int n=this.table.getRowCount();//��ȡ����
    	for(int i=0;i<n;i++) 
    	{
    		oldid=(String)table.getValueAt(i, 0);
    		if (oldid.equals(newid)) {
    			return 1;
			}
    		
    	}
    		return 0;
		}
}






    



