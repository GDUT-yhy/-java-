package com.java.view;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import com.java.model.BookType;

import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JMenu;
import javax.swing.JDesktopPane;
import java.awt.Color;
import javax.swing.UIManager;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JLabel;
import javax.swing.ImageIcon;

public class MainFrm extends JFrame {

	private JPanel contentPane;
	private JDesktopPane table=null; 
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					MainFrm frame = new MainFrm();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public MainFrm() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 1287, 972);
		
		JMenuBar menuBar = new JMenuBar();
		menuBar.setToolTipText("\u57FA\u672C\u6570\u636E\u7EF4\u62A4");
		setJMenuBar(menuBar);
		
		JMenu mnNewMenu = new JMenu("\u57FA\u672C\u6570\u636E\u7EF4\u62A4");
		menuBar.add(mnNewMenu);
		
		JMenu mnNewMenu_2 = new JMenu("\u56FE\u4E66\u7C7B\u522B\u7BA1\u7406");
		mnNewMenu.add(mnNewMenu_2);
		
		
		// ͼ�����Ӱ�ť
		JMenuItem mntmNewMenuItem = new JMenuItem("\u56FE\u4E66\u7C7B\u522B\u6DFB\u52A0");
		mntmNewMenuItem.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				BookTypeAddInterFrm bookTypeAddInterFrm=new BookTypeAddInterFrm();
				bookTypeAddInterFrm.setVisible(true);
				table.add(bookTypeAddInterFrm);
	
			}
		});
		mnNewMenu_2.add(mntmNewMenuItem);
		
		
		
		//�༭��ť
		JMenuItem mntmNewMenuItem_1 = new JMenuItem("\u56FE\u4E66\u7C7B\u522B\u7EF4\u62A4");
		mntmNewMenuItem_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				BookTypeManagerIntrFrm bookTypeManagerIntrFrm=new BookTypeManagerIntrFrm();
				bookTypeManagerIntrFrm.setVisible(true);
				table.add(bookTypeManagerIntrFrm);
				
			}
		});
		mnNewMenu_2.add(mntmNewMenuItem_1);
		
		JMenu mnNewMenu_3 = new JMenu("\u56FE\u4E66\u7BA1\u7406");
		mnNewMenu.add(mnNewMenu_3);
		
		JMenuItem mntmNewMenuItem_2 = new JMenuItem("\u6DFB\u52A0\u56FE\u4E66");
		mntmNewMenuItem_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				BookAddInterFrm bookAddInterFrm=new BookAddInterFrm();
				bookAddInterFrm.setVisible(true);
				table.add(bookAddInterFrm);
			}
		});
		mnNewMenu_3.add(mntmNewMenuItem_2);
		
		JMenuItem menuItem = new JMenuItem("\u56FE\u4E66\u7EF4\u62A4");
		menuItem.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				BookManagerInterFrm bookManagerInterFrm =new BookManagerInterFrm();
				bookManagerInterFrm.setVisible(true);
				table.add(bookManagerInterFrm);
			}
		});
		mnNewMenu_3.add(menuItem);
		  
		
		//��ȫ�˳�
		JMenuItem mntmNewMenuItem_3 = new JMenuItem("\u5B89\u5168\u9000\u51FA");
		mntmNewMenuItem_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				int result=JOptionPane.showConfirmDialog(null, "�Ƿ��˳�ϵͳ��");//����ѡ��� ��ѡ�������ظ�result
				if(result==0) 
				{
					dispose();//ɾ������
				}
			}
		});
		mnNewMenu.add(mntmNewMenuItem_3);
		
		JMenu mnNewMenu_1 = new JMenu("\u7528\u6237\u7BA1\u7406");
		menuBar.add(mnNewMenu_1);
		
		JMenuItem StudentManagerItem= new JMenuItem("\u5B66\u751F\u7BA1\u7406");
		mnNewMenu_1.add(StudentManagerItem);
		StudentManagerItem.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				StudentManager studentManager= new StudentManager();
				studentManager.setVisible(true);
				table.add(studentManager);
				
			}
		});
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPane.setLayout(new BorderLayout(0, 0));
		setContentPane(contentPane);
		
		table = new JDesktopPane();
		table.setBackground(UIManager.getColor("ComboBox.selectionBackground"));
		contentPane.add(table, BorderLayout.CENTER);
		
		JLabel lblNewLabel = new JLabel("");
		lblNewLabel.setIcon(new ImageIcon("C:\\Users\\14352\\Pictures\\logo-2.png"));
		lblNewLabel.setBounds(14, 13, 369, 103);
		table.add(lblNewLabel);
		//this.setExtendedState(JFrame.MAXIMIZED_BOTH);//����jfrem���
	}

	
}
