package com.java.view;

import java.awt.EventQueue;

import javax.swing.JInternalFrame;
import javax.swing.UIManager;
import javax.swing.JLabel;
import java.awt.BorderLayout;
import javax.swing.ImageIcon;

public class InterFrm extends JInternalFrame {

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					InterFrm frame = new InterFrm();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public InterFrm() {
		
		getContentPane().setBackground(UIManager.getColor("ToggleButton.light"));
		
		JLabel lblNewLabel = new JLabel("");
		lblNewLabel.setAutoscrolls(true);
		lblNewLabel.setIcon(new ImageIcon("C:\\Users\\14352\\Desktop\\\u56FE\u6807\\timg.jpg"));
		getContentPane().add(lblNewLabel, BorderLayout.NORTH);
		setIconifiable(true);
		setClosable(true);
		
		setTitle("\u5173\u4E8E\u5E7F\u4E1C\u5DE5\u4E1A\u5927\u5B66");
		setBounds(100, 100, 873, 522);

	}

}
