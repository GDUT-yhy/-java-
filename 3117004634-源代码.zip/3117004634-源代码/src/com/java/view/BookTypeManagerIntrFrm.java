package com.java.view;

import java.awt.EventQueue;
import java.sql.Connection;
import java.sql.ResultSet;
import java.util.Vector;

import javax.swing.JInternalFrame;
import javax.swing.JScrollPane;
import java.awt.BorderLayout;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

import com.java.dao.BookDao;
import com.java.dao.BookTypeDao;
import com.java.model.BookType;
import com.java.util.DbUtil;
import com.java.util.StringUtil;
import com.java.util.TxtUtil;
import com.sun.corba.se.impl.orb.ParserTable.TestAcceptor1;
import com.sun.istack.internal.localization.NullLocalizable;
import com.sun.xml.internal.bind.v2.model.core.ID;

import javax.swing.JTextField;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JButton;
import javax.swing.LayoutStyle.ComponentPlacement;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.ActionEvent;
import javax.swing.ImageIcon;
import javax.swing.JPanel;
import javax.swing.border.LineBorder;
import javax.swing.border.TitledBorder;
import javax.swing.JTextArea;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class BookTypeManagerIntrFrm extends JInternalFrame {
	TxtUtil txtUtil=new TxtUtil();
	private JTable BookTypeTable;
	private DbUtil dbUtil=new DbUtil();
	private BookTypeDao bookTypeDao=new BookTypeDao();
	private JTextField s_bookTypeNameTxt;
	private JTextField Typeidtext;
	private JTextField TypeNametext;
	private JTextArea TypeDesctext;
 BookDao bookDao=new BookDao();
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					BookTypeManagerIntrFrm frame = new BookTypeManagerIntrFrm();
					frame.setVisible(true);
					
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public BookTypeManagerIntrFrm() {
		setTitle("\u56FE\u4E66\u7C7B\u522B\u7BA1\u7406");
		setResizable(true);
		setClosable(true);
		setIconifiable(true);
		setBounds(100, 100, 599, 648);
		
		JScrollPane scrollPane = new JScrollPane();
		
		
		s_bookTypeNameTxt = new JTextField();
		s_bookTypeNameTxt.addKeyListener(new KeyAdapter() {
			  /**
			   	* �����ı�������ĳ��Ⱥ����ͺ�Ĭ����ʾ
			 *		
			 */
					public void keyTyped(KeyEvent e) {
						txtUtil.limtLong20(e, s_bookTypeNameTxt);
						
					}
				});
		s_bookTypeNameTxt.setColumns(10);
		
		JLabel lblNewLabel = new JLabel("\u56FE\u4E66\u7C7B\u522B\u540D\u79F0\uFF1A");
		
		//���Ұ�ť
		JButton btnNewButton = new JButton("\u67E5\u8BE2");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			        
				bookTypeSearchActionPerformed(e);
			         
			}
		});
		
		
		JLabel lblNewLabel_1 = new JLabel("");
		lblNewLabel_1.setIcon(new ImageIcon("C:\\Users\\14352\\Pictures\\logo-2.png"));
		
		JPanel panel = new JPanel();
		panel.setBorder(new TitledBorder(null, "\u56FE\u4E66\u7C7B\u522B\u64CD\u4F5C", TitledBorder.LEADING, TitledBorder.TOP, null, null));
		panel.setToolTipText("");
		
		
		/***
		 * �޸İ�ť
		 */
		JButton btnNewButton_1 = new JButton("\u4FEE\u6539");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				bookTypeUpdateActionEvent(e);
				
			}
		});
		
		/**
		 * ɾ����ť
		 */
		JButton btnNewButton_2 = new JButton("\u5220\u9664");
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				bookTypeDeletActionEvent(e);
			}
		});
		GroupLayout groupLayout = new GroupLayout(getContentPane());
		groupLayout.setHorizontalGroup(
			groupLayout.createParallelGroup(Alignment.LEADING)
				.addGroup(groupLayout.createSequentialGroup()
					.addGroup(groupLayout.createParallelGroup(Alignment.TRAILING)
						.addComponent(lblNewLabel_1, Alignment.LEADING, GroupLayout.PREFERRED_SIZE, 386, GroupLayout.PREFERRED_SIZE)
						.addGroup(Alignment.LEADING, groupLayout.createSequentialGroup()
							.addGap(91)
							.addGroup(groupLayout.createParallelGroup(Alignment.LEADING)
								.addComponent(scrollPane, 0, 0, Short.MAX_VALUE)
								.addGroup(groupLayout.createSequentialGroup()
									.addComponent(lblNewLabel)
									.addPreferredGap(ComponentPlacement.RELATED)
									.addComponent(s_bookTypeNameTxt, GroupLayout.PREFERRED_SIZE, 180, GroupLayout.PREFERRED_SIZE)
									.addPreferredGap(ComponentPlacement.UNRELATED)
									.addComponent(btnNewButton))
								.addComponent(panel, Alignment.TRAILING, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
								.addGroup(groupLayout.createSequentialGroup()
									.addGap(10)
									.addComponent(btnNewButton_1, GroupLayout.PREFERRED_SIZE, 179, GroupLayout.PREFERRED_SIZE)
									.addPreferredGap(ComponentPlacement.RELATED, 43, Short.MAX_VALUE)
									.addComponent(btnNewButton_2, GroupLayout.PREFERRED_SIZE, 142, GroupLayout.PREFERRED_SIZE)
									.addGap(11)))))
					.addContainerGap(124, Short.MAX_VALUE))
		);
		groupLayout.setVerticalGroup(
			groupLayout.createParallelGroup(Alignment.LEADING)
				.addGroup(groupLayout.createSequentialGroup()
					.addContainerGap()
					.addComponent(lblNewLabel_1, GroupLayout.PREFERRED_SIZE, 101, GroupLayout.PREFERRED_SIZE)
					.addGap(18)
					.addGroup(groupLayout.createParallelGroup(Alignment.BASELINE)
						.addComponent(lblNewLabel)
						.addComponent(s_bookTypeNameTxt, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
						.addComponent(btnNewButton))
					.addGap(38)
					.addComponent(scrollPane, GroupLayout.PREFERRED_SIZE, 141, GroupLayout.PREFERRED_SIZE)
					.addGap(32)
					.addComponent(panel, GroupLayout.PREFERRED_SIZE, 191, GroupLayout.PREFERRED_SIZE)
					.addPreferredGap(ComponentPlacement.UNRELATED)
					.addGroup(groupLayout.createParallelGroup(Alignment.BASELINE)
						.addComponent(btnNewButton_1)
						.addComponent(btnNewButton_2))
					.addContainerGap(GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
		);
		
		JLabel lblNewLabel_2 = new JLabel("\u7F16\u53F7:");
		
		Typeidtext = new JTextField();
		Typeidtext.addKeyListener(new KeyAdapter() {
			  /**
			   	* �����ı�������ĳ��Ⱥ����ͺ�Ĭ����ʾ
			 *		
			 */
					public void keyTyped(KeyEvent e) {
						txtUtil.limtLong(e, Typeidtext);
						txtUtil.limtNum(e);
					}
				});
		Typeidtext.setColumns(10);
		
		JLabel lblNewLabel_3 = new JLabel("\u56FE\u4E66\u7C7B\u522B\u540D\u79F0\uFF1A");
		
		TypeNametext = new JTextField();
		TypeNametext.addKeyListener(new KeyAdapter() {
			  /**
			   	* �����ı�������ĳ��Ⱥ����ͺ�Ĭ����ʾ
			 *		
			 */
					public void keyTyped(KeyEvent e) {
						txtUtil.limtLong10(e, TypeNametext);
						
					}
				});
		TypeNametext.setColumns(10);
		
		JLabel lblNewLabel_4 = new JLabel("\u63CF\u8FF0\uFF1A");
		
		TypeDesctext = new JTextArea();
		TypeDesctext.addKeyListener(new KeyAdapter() {
			  /**
			   	* �����ı�������ĳ��Ⱥ����ͺ�Ĭ����ʾ
			 *		
			 */
					public void keyTyped(KeyEvent e) {
						txtUtil.limtLong100(e, TypeDesctext);
						
					}
				});
		GroupLayout gl_panel = new GroupLayout(panel);
		gl_panel.setHorizontalGroup(
			gl_panel.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_panel.createSequentialGroup()
					.addContainerGap()
					.addGroup(gl_panel.createParallelGroup(Alignment.LEADING, false)
						.addGroup(gl_panel.createSequentialGroup()
							.addComponent(lblNewLabel_2)
							.addPreferredGap(ComponentPlacement.UNRELATED)
							.addComponent(Typeidtext, GroupLayout.PREFERRED_SIZE, 72, GroupLayout.PREFERRED_SIZE)
							.addGap(10)
							.addComponent(lblNewLabel_3)
							.addGap(18)
							.addComponent(TypeNametext, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
						.addGroup(gl_panel.createSequentialGroup()
							.addComponent(lblNewLabel_4)
							.addPreferredGap(ComponentPlacement.RELATED)
							.addComponent(TypeDesctext)))
					.addContainerGap(32, Short.MAX_VALUE))
		);
		gl_panel.setVerticalGroup(
			gl_panel.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_panel.createSequentialGroup()
					.addGroup(gl_panel.createParallelGroup(Alignment.BASELINE)
						.addComponent(lblNewLabel_2)
						.addComponent(lblNewLabel_3)
						.addComponent(TypeNametext, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
						.addComponent(Typeidtext, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
					.addGap(18)
					.addGroup(gl_panel.createParallelGroup(Alignment.LEADING)
						.addComponent(lblNewLabel_4)
						.addComponent(TypeDesctext, GroupLayout.PREFERRED_SIZE, 109, GroupLayout.PREFERRED_SIZE))
					.addContainerGap(GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
		);
		panel.setLayout(gl_panel);
		
		
		//������ʾ�� ������¼�
		
		BookTypeTable = new JTable();
		BookTypeTable.getTableHeader().setReorderingAllowed(false);
		BookTypeTable.addMouseListener(new MouseAdapter() {
			@Override
			public void mousePressed(MouseEvent e) {
				bookTypeTableMousePressed(e);
			}
		});
		BookTypeTable.setModel(new DefaultTableModel(
			new Object[][] {
			},
			new String[] {
				"\u7F16\u53F7", "\u56FE\u4E66\u7C7B\u522B\u540D\u79F0", "\u56FE\u4E66\u7C7B\u522B\u63CF\u8FF0"
			}
		) {
			boolean[] columnEditables = new boolean[] {
				false, false, false
			};
			public boolean isCellEditable(int row, int column) {
				return columnEditables[column];
			}
		});
		BookTypeTable.getColumnModel().getColumn(1).setPreferredWidth(173);
		BookTypeTable.getColumnModel().getColumn(2).setPreferredWidth(156);
		scrollPane.setViewportView(BookTypeTable);
		getContentPane().setLayout(groupLayout);
		
		//test
		
		this.fillTable(new BookType());
		 TypeDesctext.setBorder(new LineBorder(new java.awt.Color(127,157,185), 1, false));
	}
	
	
	/**
	 * 
	 *ɾ���¼�����
	 *
	 * @param e
	 */
	
	private void bookTypeDeletActionEvent(ActionEvent evt) {
		// TODO �Զ����ɵķ������
		int row=BookTypeTable.getSelectedRow();
		String id=(String) BookTypeTable.getValueAt(row, 0);
		String id2=Typeidtext.getText();
		Connection con=null;
			try {
					con=dbUtil.getCon();
					boolean flag=bookDao.existBookByBookTypeId(con,id);// �ж������Ƿ������������
					if (flag) {
						JOptionPane.showMessageDialog(this, "��ǰ�������ͼ�飬����ɾ����");
						return;//��ִ�е�����ִ�������
					}
				
					if (StringUtil.isEmpty(id)||StringUtil.isEmpty(id2))
					{
						JOptionPane.showMessageDialog(this, "��ѡ��Ҫɾ��������");
						}
						
					
					int m=JOptionPane.showConfirmDialog(this, "ȷ��ɾ����");
					if (m==0) 
					{         int n=bookTypeDao.delete(con, id);
						if (n==1){
									JOptionPane.showMessageDialog(this, "ɾ���ɹ�!");
									fillTable(new BookType());                         //���±�
									resetvalue(); }
						else {
							JOptionPane.showMessageDialog(this, "ɾ��ʧ��!");
						}
					}
			    } 
			catch (Exception e) {e.printStackTrace();}
			finally 
			{
				try {dbUtil.closeCon(con);} 
				catch (Exception e) {e.printStackTrace();}
			}
					
		
					
		
	}

	/**
	 * �����¼�����
	 * 
	 * @param e
	 */
	  private void bookTypeUpdateActionEvent(ActionEvent e) {
		String id= Typeidtext.getText();
		String Name=TypeNametext.getText();
		String Desc= TypeDesctext.getText();
		if (StringUtil.isEmpty(id)) {
			JOptionPane.showMessageDialog(this, "��������ѡ��Ҫ�޸ĵ���");
		}
		if (StringUtil.isEmpty(Name)) {
			JOptionPane.showMessageDialog(this, "������ͼ�������");
		}
		BookType bookType=new BookType(id,Name,Desc);
		Connection con=null;
		try {
			con=dbUtil.getCon();
			
			int modifyNum=bookTypeDao.update(con, bookType);
			if (modifyNum==1) {
				JOptionPane.showMessageDialog(this, "�޸ĳɹ�!");
				this.resetvalue();
				this.fillTable(new BookType());
			} else {
				JOptionPane.showMessageDialog(this, "���޴���޸�ʧ��!");

			}
		} catch (Exception e1) {
			
			e1.printStackTrace();
		}finally {
			try {
				dbUtil.closeCon(con);
			} catch (Exception e1) {
				// TODO �Զ����ɵ� catch ��
				e1.printStackTrace();
			}
		}
		
		
	}

	/**
	 * �����е���¼�����
	 * 
	 * @param e
	 */

	private void bookTypeTableMousePressed(MouseEvent e) {
		int row=BookTypeTable.getSelectedRow();
		Typeidtext.setText((String) BookTypeTable.getValueAt(row, 0));
		TypeNametext.setText((String) BookTypeTable.getValueAt(row, 1));
		TypeDesctext.setText((String) BookTypeTable.getValueAt(row, 2));
	}

	/**
	 * ͼ����������¼�
	 * @param evt
	 */
	protected void bookTypeSearchActionPerformed(ActionEvent evt) {
		
		String s_bookTypeName=this.s_bookTypeNameTxt.getText();
		
		BookType bookType=new BookType();
		
		bookType.setBookTypeName(s_bookTypeName);
		
		this.fillTable(bookType);
		
		
		
		
	}

	/**
	 * ��ʼ������
	 * @param bookType
	 */
	private void fillTable(BookType bookType)
	{
		//BookType bType=new BookType();
		
		DefaultTableModel dtm=(DefaultTableModel) BookTypeTable.getModel();
		dtm.setRowCount(0);//�������
		Connection con = null;
		try {
				con=dbUtil.getCon();
				ResultSet rs= bookTypeDao.List(con,bookType);//��ͼ�����Ͳ�����ȡ�Ľ�� ����
				while (rs.next())
					{Vector v=new Vector();
					v.add(rs.getString("t_bookid"));
					v.add(rs.getString("bookTypeName"));
					v.add(rs.getString("bookTypeDesc"));
					dtm.addRow(v);}
			} 
		catch   (Exception e) {e.printStackTrace();}
		finally {try {dbUtil.closeCon(con);} 
				catch (Exception e){e.printStackTrace();}
				}
		
	}
	
	
	/**
	 * ���ñ���
	 */
   private void resetvalue() {
	    this.Typeidtext.setText("");
	    this.TypeNametext.setText("");
	    this.TypeDesctext.setText("");
	
}






























}
