package com.java.view;

import java.awt.EventQueue;

import javax.swing.JInternalFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import com.java.dao.BookDao;
import com.java.dao.BookTypeDao;
import com.java.model.Book;
import com.java.model.BookType;
import com.java.util.DbUtil;
import com.java.util.StringUtil;
import com.java.util.TxtUtil;
import com.jgoodies.forms.factories.DefaultComponentFactory;
import java.awt.BorderLayout;
import javax.swing.ImageIcon;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.JTextField;
import javax.swing.LayoutStyle.ComponentPlacement;
import java.awt.Label;
import javax.swing.JButton;
import javax.swing.JDesktopPane;

import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.sql.Connection;
import java.sql.ResultSet;
import java.util.function.ToLongFunction;
import java.awt.event.ActionEvent;
import java.awt.TextArea;
import javax.swing.JTextArea;
import javax.swing.JPanel;
import javax.swing.JComboBox;

public class BookAddInterFrm extends JInternalFrame {
	TxtUtil txtUtil=new TxtUtil();
	private JTextField bookNametxt;
	private JTextField bookLocationtxt;
	private JTextField bookIdtxt;
	
	private JTextField bookAuthortxt
	;
	private JDesktopPane table=null; 
	private  DbUtil dbUtil=new DbUtil();
	BookDao bookDao=new BookDao();
	private BookTypeDao bookTypeDao=new BookTypeDao();
	JComboBox<BookType> bookTypeJcb;
	JTextArea bookDesctxt;
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					BookAddInterFrm frame = new BookAddInterFrm();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public BookAddInterFrm() {
		setClosable(true);
		setIconifiable(true);
		setTitle("\u56FE\u4E66\u6DFB\u52A0");
		setBounds(100, 100, 700, 529);
		
		JLabel lblNewLabel = new JLabel("");
		lblNewLabel.setIcon(new ImageIcon("C:\\Users\\14352\\Pictures\\logo-2.png"));
		
		bookNametxt = new JTextField();
		bookNametxt.addKeyListener(new KeyAdapter() {
			  /**
			   	* �����ı�������ĳ��Ⱥ����ͺ�Ĭ����ʾ
			 *		
			 */
					public void keyTyped(KeyEvent e) {
						txtUtil.limtLong30(e, bookNametxt);
					
					}
				});
		bookNametxt.setColumns(10);
		
		JLabel lblNewLabel_1 = new JLabel("\u4E66    \u540D\uFF1A");
		
		JLabel lblNewLabel_2 = new JLabel("\u4F4D    \u7F6E\uFF1A");
		
		bookLocationtxt = new JTextField();
		bookLocationtxt.addKeyListener(new KeyAdapter() {
			  /**
			   	* �����ı�������ĳ��Ⱥ����ͺ�Ĭ����ʾ
			 *		
			 */
					public void keyTyped(KeyEvent e) {
						txtUtil.limtLong30(e, bookLocationtxt);
					
					}
				});
		bookLocationtxt.setColumns(10);
		
		JLabel lblNewLabel_3 = new JLabel("\u7F16     \u53F7\uFF1A");
		
		bookIdtxt = new JTextField();
		bookIdtxt.addKeyListener(new KeyAdapter() {
			  /**
			   	* �����ı�������ĳ��Ⱥ����ͺ�Ĭ����ʾ
			 *		
			 */
					public void keyTyped(KeyEvent e) {
						txtUtil.limtLong(e, bookIdtxt);
						txtUtil.limtNum(e);
					}
				});
		bookIdtxt.setColumns(10);
		
		JLabel lblNewLabel_5 = new JLabel("\u56FE\u4E66\u7B80\u4ECB\uFF1A");
		
		
		//���Ӱ�ť
		JButton btnNewButton = new JButton("\u6DFB    \u52A0");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				bookAddActionPerformed(e);
			
				
			}
		});
		 //���ð�ť
		JButton btnNewButton_1 = new JButton("\u91CD   \u7F6E");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			     bookresetActionEvent(e);
			}
		});
		
		JLabel lblNewLabel_6 = new JLabel("\u4F5C   \u8005\uFF1A");
		
		bookAuthortxt = new JTextField();
		bookAuthortxt.addKeyListener(new KeyAdapter() {
			  /**
			   	* �����ı�������ĳ��Ⱥ����ͺ�Ĭ����ʾ
			 *		
			 */
					public void keyTyped(KeyEvent e) {
						txtUtil.limtLong20(e, bookAuthortxt);
					
					}
				});
		bookAuthortxt.setColumns(10);
		
		JPanel panel = new JPanel();
		
		 bookTypeJcb = new JComboBox<BookType>();
		
		JLabel lblNewLabel_4 = new JLabel("\u56FE\u4E66\u7C7B\u522B\uFF1A");
		
		 bookDesctxt = new JTextArea();
		 bookDesctxt.addKeyListener(new KeyAdapter() {
			  /**
			   	* �����ı�������ĳ��Ⱥ����ͺ�Ĭ����ʾ
			 *		
			 */
					public void keyTyped(KeyEvent e) {
						txtUtil.limtLong100(e, bookDesctxt);
					
					}
				});
		GroupLayout groupLayout = new GroupLayout(getContentPane());
		groupLayout.setHorizontalGroup(
			groupLayout.createParallelGroup(Alignment.TRAILING)
				.addGroup(groupLayout.createSequentialGroup()
					.addGroup(groupLayout.createParallelGroup(Alignment.LEADING)
						.addGroup(groupLayout.createSequentialGroup()
							.addComponent(lblNewLabel, GroupLayout.PREFERRED_SIZE, 684, GroupLayout.PREFERRED_SIZE)
							.addPreferredGap(ComponentPlacement.RELATED)
							.addComponent(panel, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
						.addGroup(groupLayout.createSequentialGroup()
							.addGap(75)
							.addGroup(groupLayout.createParallelGroup(Alignment.LEADING, false)
								.addGroup(groupLayout.createSequentialGroup()
									.addComponent(btnNewButton, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
									.addGap(103)
									.addComponent(btnNewButton_1, GroupLayout.PREFERRED_SIZE, 174, GroupLayout.PREFERRED_SIZE)
									.addGap(39))
								.addGroup(groupLayout.createSequentialGroup()
									.addGroup(groupLayout.createParallelGroup(Alignment.LEADING)
										.addComponent(lblNewLabel_1)
										.addGroup(groupLayout.createParallelGroup(Alignment.TRAILING, false)
											.addComponent(lblNewLabel_6, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
											.addComponent(lblNewLabel_4, Alignment.LEADING)
											.addComponent(lblNewLabel_5, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
									.addGap(69)
									.addGroup(groupLayout.createParallelGroup(Alignment.LEADING, false)
										.addGroup(groupLayout.createSequentialGroup()
											.addGroup(groupLayout.createParallelGroup(Alignment.LEADING, false)
												.addComponent(bookNametxt)
												.addComponent(bookAuthortxt)
												.addComponent(bookTypeJcb, 0, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
											.addGap(82)
											.addGroup(groupLayout.createParallelGroup(Alignment.LEADING)
												.addComponent(lblNewLabel_3)
												.addComponent(lblNewLabel_2))
											.addGap(38)
											.addGroup(groupLayout.createParallelGroup(Alignment.LEADING, false)
												.addComponent(bookLocationtxt)
												.addComponent(bookIdtxt)))
										.addComponent(bookDesctxt))))))
					.addContainerGap(GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
		);
		groupLayout.setVerticalGroup(
			groupLayout.createParallelGroup(Alignment.LEADING)
				.addGroup(groupLayout.createSequentialGroup()
					.addComponent(lblNewLabel)
					.addGap(30)
					.addGroup(groupLayout.createParallelGroup(Alignment.BASELINE)
						.addComponent(lblNewLabel_1)
						.addComponent(bookNametxt, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
						.addComponent(lblNewLabel_3)
						.addComponent(bookIdtxt, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
					.addGap(26)
					.addGroup(groupLayout.createParallelGroup(Alignment.BASELINE)
						.addComponent(lblNewLabel_6)
						.addComponent(bookAuthortxt, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
						.addComponent(lblNewLabel_2)
						.addComponent(bookLocationtxt, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
					.addGap(18)
					.addGroup(groupLayout.createParallelGroup(Alignment.BASELINE)
						.addComponent(bookTypeJcb, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
						.addComponent(lblNewLabel_4))
					.addGap(15)
					.addGroup(groupLayout.createParallelGroup(Alignment.LEADING)
						.addComponent(lblNewLabel_5)
						.addComponent(bookDesctxt, GroupLayout.PREFERRED_SIZE, 132, GroupLayout.PREFERRED_SIZE))
					.addPreferredGap(ComponentPlacement.RELATED, 36, Short.MAX_VALUE)
					.addGroup(groupLayout.createParallelGroup(Alignment.BASELINE)
						.addComponent(btnNewButton)
						.addComponent(btnNewButton_1))
					.addGap(67))
				.addGroup(groupLayout.createSequentialGroup()
					.addGap(36)
					.addComponent(panel, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
					.addContainerGap())
		);
		getContentPane().setLayout(groupLayout);
		fillBookType();
	}

	
	
	private  void bookAddActionPerformed(ActionEvent evt) {
		
		String desc=bookDesctxt.getText();
		String bookAuthor=bookAuthortxt.getText();
		String bookborrow=("0");          //0û�� 1���
		String bookName=bookNametxt.getText();
		String bookid=bookIdtxt.getText();
		String booklocation=bookLocationtxt.getText();
		
		 
		BookType bookType=(BookType) bookTypeJcb.getSelectedItem();
		String bookTypeId=bookType.getId();
		String bookTypeName=bookType.getBookTypeName();
		
		if (StringUtil.isEmpty(bookIdtxt.getText()))  {JOptionPane.showMessageDialog(this, "ͼ���Ų���Ϊ��");}
		if (StringUtil.isEmpty(bookNametxt.getText()))  {JOptionPane.showMessageDialog(this, "ͼ�����Ʋ���Ϊ��");}
		if (StringUtil.isEmpty(bookLocationtxt.getText()))  {JOptionPane.showMessageDialog(this, "ͼ��λ�ò���Ϊ��");}
		
		Book book=new Book(bookid, bookName, bookAuthor, bookTypeId,booklocation,bookborrow,bookTypeName,desc);
		Connection con=null;
		try {
			
			con=dbUtil.getCon();
			int addNum=bookDao.add(con, book);
			
			if (addNum==1) {
				JOptionPane.showMessageDialog(this, "���ӳɹ�");
				bookresetActionEvent(evt);
			}else {JOptionPane.showMessageDialog(this, "����ʧ��");}
			
			
			
		} catch (Exception e) {
			// TODO �Զ����ɵ� catch ��
			e.printStackTrace();
		}finally {
			try {
				dbUtil.closeCon(con);
			} catch (Exception e) {
				// TODO �Զ����ɵ� catch ��
				e.printStackTrace();
			}
		}
				
	
	
	}

	/**
	 * �����¼�����
	 * @param e
	 */
	private void bookresetActionEvent(ActionEvent e) {
	        this.bookDesctxt.setText("");
	        this.bookIdtxt.setText("");
	        this.bookLocationtxt.setText("");
	        this.bookNametxt.setText("");
	         this.bookAuthortxt.setText("");
	         if (bookTypeJcb.getItemCount()>0) {
	        	 this.bookTypeJcb.setSelectedIndex(0);
				
			}
	}

	
	
	
	/**
	 * ��ʼ��ͼ�����������
	 * 
	 */
	
	private void fillBookType()
	{
		Connection con=null;
		BookType bookType=null;
		try {
			con=dbUtil.getCon();
			
			ResultSet rs=bookTypeDao.List(con,new BookType());
			while (rs.next()) {
				bookType=new BookType();
				bookType.setId(rs.getString("t_bookid"));
				bookType.setBookTypeName(rs.getString("bookTypeName"));
				
				this.bookTypeJcb.addItem(bookType);
			}
			
			
		} catch (Exception e) {e.printStackTrace();
		}finally {
			try {
				dbUtil.closeCon(con);
			} catch (Exception e) {
				// TODO �Զ����ɵ� catch ��
				e.printStackTrace();
			}
		}
		
		
		
		
	}
}
