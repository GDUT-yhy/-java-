package com.java.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.java.model.Student;
import com.java.model.User;
import com.java.util.StringUtil;
import com.sun.javafx.css.PseudoClassState;

public class StudentDao {
/**
 * ѧ����¼
 * @param con
 * @param student
 * @return
 * @throws Exception
 */
	public static Student login(Connection con, Student student)throws Exception{
		Student resultUser=null;         
		String sql="select*from [student] where s_id=? and s_password=?";//ע�������ʺŵ�����ں�������
		PreparedStatement pstmt=con.prepareStatement(sql); //��sql���Ԥ���벢����
		pstmt.setString(1, student.getStuId());//����һ���ʺŵĵط���λuser.id
		pstmt.setString(2, student.getStuPassword());//���ڶ����ʺŵĵط���λuser.password
	
		//executeQuery()����������ݿ���Ӧ�Ĳ�ѯ��������ResultSet������й�����ʹ�á�
		ResultSet rs=pstmt.executeQuery();
		if (rs.next()) {                          //rs.next��ʾ������Ϣ��
			resultUser=new Student();                //����һ���µ��û�ʵ��
			/**
			 * ���鵽����Ϣ��ʵ�����ĵ�user
			 */
			resultUser.setStuId(rs.getString("s_id"));
			resultUser.setStuName(rs.getString("s_name"));
			resultUser.setStujNum(rs.getInt("s_jnum"));
			
			resultUser.setStuSex(rs.getString("s_sex"));
			resultUser.setStuSpecil(rs.getString("s_specil"));
			resultUser.setStuPassword(rs.getString("s_password"));
		}
		
		return resultUser;              //�����Ӻ��ȡ���û���ʵ�巵��
	}

	
	/**
	 * ��ѯѧ�������������
	 * @param con
	 * @param student
	 * @return ResultSet
	 * @throws SQLException
	 */
	 public static ResultSet list(Connection con ,Student student) throws SQLException {
		 StringBuffer sb=new StringBuffer("select * from [student] as b");
		 
		 if (StringUtil.isNotEmpty(student.getStuName())) {
			 sb.append(" and b.s_name like '%"+student.getStuName()+"%'");
		}
		 if (StringUtil.isNotEmpty(student.getStuId())) {
			 sb.append(" and b.s_id like '%"+student.getStuId()+"%'");
		}
		if (StringUtil.isNotEmpty(student.getStuSpecil())) {
			 sb.append(" and b.s_specil like '%"+student.getStuSpecil()+"%'");
		}
		if (StringUtil.isNotEmpty(student.getStuSex())) {
			 sb.append(" and b.s_sex like '%"+student.getStuSex()+"%'");
		}
		PreparedStatement pstmt=con.prepareStatement(sb.toString().replaceFirst("and", "where"));
		
		return pstmt.executeQuery();
	 }
	 
	 
	 /**
	  *  ѧ�����ӳ�ʼ����Ϊѧ��
	  * @param con
	  * @param student
	  * @throws SQLException
	  */
	 public int addStudent(Connection con,Student student) throws SQLException {
		 String sql="insert into [student] values(?,?,?,?,?,?)";//������Ϣ��sql���
		 PreparedStatement pstmt=con.prepareStatement(sql);
		 pstmt.setString(1,student.getStuId() );
		 pstmt.setString(2,student.getStuName());
		 pstmt.setString(3,student.getStuSex());
		 pstmt.setString(4,student.getStuSpecil());
		 pstmt.setInt(5,student.getStujNum());
		 pstmt.setString(6,student.getStuId());
		 
		 return pstmt.executeUpdate();
	 
	 }
/**
 * ɾ��ѧ��
 * @param con
 * @param id
 * @return
 * @throws SQLException
 */
     public int deletStudent(Connection con,String id) throws SQLException{
    	 
    	 String sql ="delete from [student] where s_id=?";
 		PreparedStatement pstm=con.prepareStatement(sql);
 		pstm.setString(1,id );
 		
 		return pstm.executeUpdate();
    	 
     }

     
     /**
            ����ѧ����Ϣ
      * @param con
      * @param student
      * @return
      * @throws SQLException
      */
      public int updateStudent(Connection con, Student student) throws SQLException {
    	  String sql="update [student] set s_name=?,s_sex=?,s_specil=? where s_id=?";
    	 PreparedStatement pstm =con.prepareStatement(sql);
  		
  		pstm.setString(1, student.getStuName());
  		pstm.setString(2, student.getStuSex());
  		pstm.setString(3, student.getStuSpecil());
  		pstm.setString(4, student.getStuId());
  		
  		return pstm.executeUpdate();
 	 
	}
      
      /**
      ����ѧ����Ϣ
* @param con
* @param student
* @return
* @throws SQLException
*/
public int updatePassword(Connection con, Student student) throws SQLException {
	  String sql="update [student] set s_password=? where s_id=?";
	 PreparedStatement pstm =con.prepareStatement(sql);
	
	pstm.setString(1, student.getStuPassword());
	
	pstm.setString(2, student.getStuId());
	
	return pstm.executeUpdate();

}
      
      
      /**
       	* ѧ�������¼��Ŀ
       * @param con
       * @param student
       * @return
       * @throws SQLException
       */
      public int Studentborrw(Connection con, Student student) throws SQLException {
    	  String sql="update [student] set s_jnum=? where s_id=?";
    	 PreparedStatement pstm =con.prepareStatement(sql);
  		
  		pstm.setLong(1, student.getStujNum());
  		pstm.setString(2, student.getStuId());
  		return pstm.executeUpdate();
 	 
	}
      /**
     	* ѧ�������¼��Ŀ
     * @param con
     * @param student
     * @return
     * @throws SQLException
     */
    public int Studentreturbook(Connection con, Student student) throws SQLException {
  	  String sql="update [student] set s_jnum=? where s_id=?";
  	 PreparedStatement pstm =con.prepareStatement(sql);
		
		pstm.setLong(1, student.getStujNum());
		pstm.setString(2, student.getStuId());
		return pstm.executeUpdate();
	 
	}












}
  
 
