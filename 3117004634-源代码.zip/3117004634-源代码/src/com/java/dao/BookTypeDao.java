package com.java.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.swing.JOptionPane;

import com.java.model.BookType;
import com.java.util.StringUtil;

/**
 * ͼ�����Dao��
 * @author 14352
 *
 */
public class BookTypeDao {
	/**
	 * ͼ���������
	 * @param cno
	 * @param bookType
	 * @return
	 */

	public int add(Connection con,BookType bookType)throws Exception
	{
		String sql="insert into [bookType] values(?,?,?)";//������Ϣ��sql���
		PreparedStatement pstmt=con.prepareStatement(sql);
		/**
		 * ��booktype����Ϣд��sql���
		 */
		pstmt.setString(1,bookType.getBookTypeDesc() );
		pstmt.setString(2, bookType.getBookTypeName());
		pstmt.setString(3, bookType.getId());
		//ִ�г���
		return pstmt.executeUpdate();
	}
	
	/**
	 * ��ѯͼ����𼯺�
	 * @param con
	 * @param bookType
	 * @return
	 * @throws Exception
	 */
	public  ResultSet List(Connection con,BookType bookType)throws Exception
		{
		StringBuffer sb=new StringBuffer("select * from [bookType]");
		
		
		
		if(StringUtil.isNotEmpty(bookType.getBookTypeName())){
			
			sb.append(" and bookTypeName like '%"+bookType.getBookTypeName()+"%'");
		}
		
		PreparedStatement pstmt=con.prepareStatement(sb.toString().replaceFirst("and", "where"));
		
		return pstmt.executeQuery();
	}
	
	
	/**
	 * ����ͼ���������
	 * @param con
	 * @param bookType
	 * @return
	 * @throws Exception
	 */
	public int update(Connection con,BookType bookType)throws Exception{
		String sql ="update bookType set bookTypeName=?,bookTypeDesc=? where t_bookid=?";
		PreparedStatement pstm=con.prepareStatement(sql);
		pstm.setString(1, bookType.getBookTypeName());
		pstm.setString(2, bookType.getBookTypeDesc());
		pstm.setString(3,bookType.getId());
		
		return pstm.executeUpdate();
	}
	
	
	
	
	
	
	/**
	 * ɾ��ͼ�����
	 * @param con
	 * @param id
	 * @return
	 * @throws Exception
	 */

		public int delete(Connection con,String id) throws Exception{
			
			String sql="delete from [bookType] where t_bookid=?";
			PreparedStatement pstmt=con.prepareStatement(sql);
			
			pstmt.setString(1,id);
			return pstmt.executeUpdate();
		}











}
