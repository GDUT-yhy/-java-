package com.java.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.java.model.BookType;
import com.java.model.JsRecord;
import com.java.util.StringUtil;

public class JsDao {
	
	/**
	 * ��ѯȫ�������¼
	 * @param con
	 * @param jsRecord
	 * @return
	 * @throws Exception
	 */
	public static  ResultSet list(Connection con,JsRecord jsRecord)throws Exception
	{
	StringBuffer sb=new StringBuffer("select j.js_sj, j.js_s_id, j.js_b_id, j.js_b_name, j.js_s_name from [jsrecord] as j ,[student] as s where j.js_s_id=s.s_id");
	
	
	
	if(StringUtil.isNotEmpty(jsRecord.getStuName())){
		
		sb.append(" and js_s_name like '%"+jsRecord.getStuName()+"%'");
	}
	if(StringUtil.isNotEmpty(jsRecord.getStuId())){
		
		sb.append(" and js_s_id like '%"+jsRecord.getStuId()+"%'");
	}
    if(StringUtil.isNotEmpty(jsRecord.getBookId())){
		
		sb.append(" and js_b_id like '%"+jsRecord.getBookId()+"%'");
	}
    if(StringUtil.isNotEmpty(jsRecord.getBookName())){
		
		sb.append(" and js_b_name like '%"+jsRecord.getBookName()+"%'");
	}
    
	PreparedStatement pstmt=con.prepareStatement(sb.toString());
	
	return pstmt.executeQuery();
}

	
	/**
	 * ɾ�������¼
	 * @param con
	 * @param jsRecord
	 * @return
	 * @throws SQLException
	 */
   public int deletjsRecord(Connection con, JsRecord jsRecord11) throws SQLException {
	 String sql="delete from [jsrecord] where js_s_id="+jsRecord11.getStuId()+" and js_b_id="+jsRecord11.getBookId();
	
	 PreparedStatement pstm =con.prepareStatement(sql);
	
	
	 return  pstm.executeUpdate();
	
}

   public int AddjsRecord(Connection con, JsRecord jsRecord2) throws SQLException {
		String sql="insert into [jsrecord] values(?,?,?,?,?)";
		PreparedStatement pstm =con.prepareStatement(sql);
		
		pstm.setString(1, jsRecord2.getNowTime());
		pstm.setString(2,jsRecord2.getStuId());
		pstm.setString(3,jsRecord2.getBookId());
		pstm.setString(4, jsRecord2.getStuName());
		pstm.setString(5,jsRecord2.getBookName());
		return pstm.executeUpdate();
}





}
