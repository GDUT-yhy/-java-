package com.java.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.java.model.Book;
import com.java.util.StringUtil;
import com.sun.org.apache.xpath.internal.operations.And;

import jdk.nashorn.internal.objects.annotations.Where;

public class BookDao {

	/**
	 * ͼ������
	 * @param con
	 * @param bookType
	 * @return
	 * @throws Exception
	 */

	public int add(Connection con,Book book)throws Exception
	{
	    
		String sql="insert into [book] values(?,?,?,?,?,?,?,?)";//������Ϣ��sql���
		PreparedStatement pstmt=con.prepareStatement(sql);
		/**
		 * ��booktype����Ϣд��sql���
		 */
		pstmt.setString(1,book.getBookborrow() );
		pstmt.setString(2, book.getBooklocation());
		pstmt.setString(3, book.getAuthor());
		pstmt.setString(4, book.getBookName());
		pstmt.setString(5, book.getBookid());
		pstmt.setString(6, book.getBookTyprId());
		pstmt.setString(7, book.getBookDesc());
		pstmt.setString(8, book.getBookTypeName());
		
		
		
		return pstmt.executeUpdate();
	}
	
	/**
	    * ���ͼ�����
	 * @param con
	 * @param book
	 * @return
	 * @throws Exception
	 */

	public static  ResultSet list(Connection con, Book book) throws Exception {
			StringBuffer sb=new StringBuffer("select * from [book] as b,[bookType] bt where b.b_tid=bt.t_bookid " );
			
		
			if (StringUtil.isNotEmpty(book.getBookName())) {
				sb.append(" and b.b_name like '%"+book.getBookName()+"%'");
			}
			if (StringUtil.isNotEmpty(book.getAuthor())) {
				sb.append(" and b.b_author like '%"+book.getAuthor()+"%'");
			}
			if (StringUtil.isNotEmpty(book.getBookTyprId())) {
				sb.append(" and b.b_tid="+book.getBookTyprId());
				}
				
			PreparedStatement pstmt=con.prepareStatement(sb.toString());
			
			return pstmt.executeQuery();
		
	}
	
	/**
	 * ͼ��ɾ������
	 * @param con
	 * @param id
	 * @return
	 * @throws Exception
	 */
	public static int delete (Connection con,String id)throws Exception
	{
		String sql ="delete from [book] where b_id=?";
		PreparedStatement pstm=con.prepareStatement(sql);
		pstm.setString(1, id);
		
		return pstm.executeUpdate();
	 }
	/**
	 * ͼ����·���
	 * 
	 * @param con
	 * @param book
	 * @return
	 * @throws Exception
	 */
	public int update (Connection con,Book book)throws Exception{
		
		String sql="update [book] set b_name=?,b_borrow=?,b_location=?,b_tid=?,b_desc=?,b_author=?,b_typeName=? where b_id=?";
		PreparedStatement pstm =con.prepareStatement(sql);
		pstm.setString(1, book.getBookName());
		pstm.setString(2, book.getBookborrow());
		pstm.setString(3, book.getBooklocation());
		pstm.setString(4, book.getBookTyprId());
		pstm.setString(5, book.getBookDesc());
		pstm.setString(6,book.getAuthor());
		pstm.setString(7, book.getBookTypeName());
		pstm.setString(8, book.getBookid());
		
		return pstm.executeUpdate();
		
		
	}
	/**
	 * ͼ��ָ��ͼ��������Ƿ����ͼ��
	 * @param con
	 * @param bookTypeId
	 * @return
	 * @throws Exception
	 */
	public boolean existBookByBookTypeId(Connection con,String bookTypeId)throws Exception{
		String sql="select * from book where b_tid=?";
		PreparedStatement pstmt=con.prepareStatement(sql);
		pstmt.setString(1, bookTypeId);
		ResultSet rs=pstmt.executeQuery();
		return rs.next();
	}
	
	
	
	
	/**
	 * �������
	 * @param con
	 * @param book
	 * @return
	 * @throws Exception
	 */
	public int returnbook (Connection con,Book book)throws Exception{
		
		String sql="update [book] set b_borrow=? where b_id=?";
		PreparedStatement pstm =con.prepareStatement(sql);
		pstm.setString(1, book.getBookborrow());
		pstm.setString(2, book.getBookid());
		
		return pstm.executeUpdate();
		
		
	}
	
	
	
	
	
	
	
	
	
	
	
}
