package com.java.util;

import java.awt.event.KeyEvent;

import javax.swing.JPasswordField;
import javax.swing.JTextArea;
import javax.swing.JTextField;
/**
 * ������������Ϊ����
 * @author 14352
 *
 */
public class TxtUtil {

	public void limtNum(KeyEvent e) 
	{
	char keyCh = e.getKeyChar();
	if ((keyCh < '0') || (keyCh > '9')) {
		if (keyCh !='\r') // �س��ַ�
			e.setKeyChar('\0');}
	}
/**
 * �������볤��6
 * @param e
 * @param textField
 */
	public void limtLong(KeyEvent e,JTextField textField) {
		String s = textField.getText();
		if(s.length() >= 6) e.consume();}

	public void limtLong10(KeyEvent e,JTextField textField) {
		String s = textField.getText();
		if(s.length() >= 10) e.consume();}
	public void limtLong20(KeyEvent e,JTextField textField) {
		String s = textField.getText();
		if(s.length() >= 20) e.consume();}
	
	public void limtLong8(KeyEvent e,JTextField textField) {
		String s = textField.getText();
		if(s.length() >= 8) e.consume();}
	
	public void limtLong100(KeyEvent e,JTextArea up_bookDesc) {
		String s = up_bookDesc.getText();
		if(s.length() >= 100) e.consume();}
	public void limtLong30(KeyEvent e,JTextField up_bookDesc) {
		String s = up_bookDesc.getText();
		if(s.length() >= 30) e.consume();}



}
