package com.java.util;

import java.sql.*;

public class DbUtil {
	 private String dburl="jdbc:sqlserver://localhost:1433;DatabaseName=KS_4634";
	 private String dbUsername="sa";
     private String dbPassword="123456";
	 private String jdbcName="com.microsoft.sqlserver.jdbc.SQLServerDriver";
     /**
      * ��ȡ���ݿ�����
      * @return
      * @throws Exception
      */
	 public Connection getCon()throws Exception{
    	 Class.forName(jdbcName);
    	 Connection cno = DriverManager.getConnection(dburl, dbUsername, dbPassword);
		 return cno;}
		 /**
	  *���� 
	  */
	 public void closeCon(Connection con)throws Exception{
		 if (con!=null) {con.close();}
	 		}

public static void main(String[] args) {
	DbUtil dbUtil=new DbUtil();
	try {
		dbUtil.getCon();
		System.out.println("���ݿ����ӳɹ�");
	} catch (Exception e) {
		// TODO �Զ����ɵ� catch ��
		e.printStackTrace();
		System.out.println("���ݿ�����ʧ��");
	}
}




}
